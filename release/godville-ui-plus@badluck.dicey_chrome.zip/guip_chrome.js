window.GUIp_browser = 'Chrome';
window.GUIp_getResource = function(res) {
	return localStorage.GUIp_prefix + res;
};