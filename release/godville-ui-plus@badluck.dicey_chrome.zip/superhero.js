(function() {
'use strict';

// data
window.GUIp = window.GUIp || {};

GUIp.data = {};

// base variables initialization
GUIp.data.init = function() {
	GUIp.data._initVariables();
	GUIp.data._initForumData();
	GUIp.data._clearOldDungeonData();

	// init mobile cookies
	if (navigator.userAgent.match(/Android/)) {
		document.cookie = 'm_f=1';
		document.cookie = 'm_pp=1';
		document.cookie = 'm_fl=1';
	}

	/* [E] desktop notifications - asking user for a permission */
	if ((GUIp.storage.get('Option:enableInformerAlerts') || GUIp.storage.get('Option:enablePmAlerts')) && GUIp.browser !== 'Opera' && Notification.permission !== "granted") {
		Notification.requestPermission();
	}

	GUIp.data._getLEMRestrictions();
	setInterval(function() { GUIp.data._getLEMRestrictions(); }, 60*60*1000);

	GUIp.data._getWantedMonster();
	setInterval(function() { GUIp.data._getWantedMonster(); }, 5*60*1000);
};
GUIp.data._initVariables = function() {
	this.currentVersion = '0.40.158.9';
	this.isFight = GUIp.stats.isFight();
	this.isDungeon = GUIp.stats.isDungeon();
	document.body.classList.add(this.isDungeon ? 'dungeon' : this.isFight ? 'fight' : 'field');
	this.god_name = GUIp.stats.godName();
	this.char_name = GUIp.stats.charName();
	this.char_sex = GUIp.stats.isMale() ? GUIp.i18n.hero : GUIp.i18n.heroine;
	GUIp.storage.set('ui_s', '');
	GUIp.storage.set('charIsMale', GUIp.stats.isMale());

	if (GUIp.storage.isNewProfile(this.god_name)) {
		GUIp.storage.addToNames(this.god_name);
	}
	localStorage.setItem('GUIp:lastGodname', this.god_name);

	if (GUIp.stats.Bricks() === 1000) {
		document.body.classList.add('has_temple');
		this.hasTemple = true;
	}
	GUIp.utils.voiceInput = document.getElementById('god_phrase');
};
GUIp.data._initForumData = function() {
	if (!GUIp.storage.get('Forum1')) {
		GUIp.storage.set('Forum1', '{}');
		GUIp.storage.set('Forum2', '{}');
		GUIp.storage.set('Forum3', '{}');
		GUIp.storage.set('Forum4', '{}');
		GUIp.storage.set('ForumInformers', '{}');

		if (GUIp.locale === 'ru') {
			//GUIp.storage.set('Forum2', '{"2812": {"posts": 0, "date": 0}}');
			GUIp.storage.set('Forum5', '{}');
			GUIp.storage.set('Forum6', '{}');
		} else {
			//GUIp.storage.set('Forum1', '{"2800": {"posts": 0, "date": 0}}');
		}
	}
};
GUIp.data._clearOldDungeonData = function() {
	if (!this.isFight && !this.isDungeon) {
		for (var key in localStorage) {
			if (key.match(/:Dungeon:/)) {
				localStorage.removeItem(key);
			}
		}
	}
};
GUIp.data._getLEMRestrictions = function() {
	if (isNaN(GUIp.storage.get('LEMRestrictions:Date')) || Date.now() - GUIp.storage.get('LEMRestrictions:Date') > 24*60*60*1000) {
		GUIp.utils.getXHR({
			url: '//www.godalert.info/Dungeons/guip.cgi',
			onSuccess: GUIp.data._parseLEMRestrictions
		});
	}
};
GUIp.data._parseLEMRestrictions = function(xhr) {
	var restrictions = JSON.parse(xhr.responseText);
	GUIp.storage.set('LEMRestrictions:Date', Date.now());
	GUIp.storage.set('LEMRestrictions:FirstRequest', restrictions.first_request);
	GUIp.storage.set('LEMRestrictions:TimeFrame', restrictions.time_frame);
	GUIp.storage.set('LEMRestrictions:RequestLimit', restrictions.request_limit);
};
GUIp.data._getWantedMonster = function() {
	if (isNaN(GUIp.storage.get('WantedMonster:Date')) ||
		GUIp.utils.dateToMoscowTimeZone(+GUIp.storage.get('WantedMonster:Date')) < GUIp.utils.dateToMoscowTimeZone(Date.now())) {
		GUIp.utils.getXHR({
			url: '/news',
			onSuccess: GUIp.data._parseWantedMonster
		});
	} else {
		GUIp.improver.wantedMonsters = new RegExp(GUIp.storage.get('WantedMonster:Value'));
	}
};
GUIp.data._parseWantedMonster = function(xhr) {
	var temp = xhr.responseText.match(/(?:Разыскиваются|Wanted)[\s\S]+?>([^<]+?)<\/a>[\s\S]+?>([^<]+?)<\/a>/),
		newWantedMonster = temp ? temp[1] + '|' + temp[2] : '';
	if (newWantedMonster && newWantedMonster !== GUIp.storage.get('WantedMonster:Value')) {
		GUIp.storage.set('WantedMonster:Date', Date.now());
		GUIp.storage.set('WantedMonster:Value', newWantedMonster);
		GUIp.improver.wantedMonsters = new RegExp(newWantedMonster);
	}
};

// utils
window.GUIp = window.GUIp || {};

GUIp.utils = {};

GUIp.utils.notiLaunch = 0;
GUIp.utils.messagesShown = [];
// base phrase say algorythm
GUIp.utils.setVoice = function(voice) {
	this.voiceInput.value = voice;
	GUIp.utils.triggerChangeOnVoiceInput();
};
GUIp.utils.triggerChangeOnVoiceInput = function() {
	$(this.voiceInput).change();
};
// finds a label with given name
GUIp.utils.findLabel = function($base_elem, label_name) {
	return $('.l_capt', $base_elem).filter(function(index) {
		return this.textContent === label_name;
	});
};
// checks if $elem already improved
GUIp.utils.isAlreadyImproved = function(elem) {
	if (elem.classList.contains('improved')) {
		return true;
	} else {
		elem.classList.add('improved');
		return false;
	}
};
// generic voice generator
GUIp.utils.getGenericVoicegenButton = function(text, section, title) {
	var voicegen = document.createElement('a');
	voicegen.title = title;
	voicegen.textContent = text;
	voicegen.className = 'voice_generator ' + (GUIp.data.isDungeon ? 'dungeon' : GUIp.data.isFight ? 'battle' : 'field') + ' ' + section;
	voicegen.onclick = function() {
		if (document.getElementById('god_phrase').getAttribute('disabled') !== 'disabled') {
			GUIp.utils.setVoice(GUIp.words.longPhrase(section));
			GUIp.words.currentPhrase = "";
		}
		return false;
	};
	return voicegen;
};
GUIp.utils.addVoicegen = function(elem, voicegen_name, section, title) {
	elem.parentNode.insertBefore(GUIp.utils.getGenericVoicegenButton(voicegen_name, section, title), elem.nextSibling);
};
// Случайный индекс в массиве
GUIp.utils.getRandomIndex = function(arr) {
	return Math.floor(Math.random()*arr.length);
};
// Форматирование времени
GUIp.utils.formatClock = function(godvilleTime) {
	return ('0' + godvilleTime.getUTCHours()).slice(-2) + ':' + ('0' + godvilleTime.getUTCMinutes()).slice(-2) + ':' + ('0' + godvilleTime.getUTCSeconds()).slice(-2);
};
// Случайный элемент массива
GUIp.utils.getRandomItem = function(arr) {
	return arr[GUIp.utils.getRandomIndex(arr)];
};
// Вытаскивает случайный элемент из массива
GUIp.utils.popRandomItem = function(arr) {
	var ind = GUIp.utils.getRandomIndex(arr);
	var res = arr[ind];
	arr.splice(ind, 1);
	return res;
};
// Escapes HTML symbols
GUIp.utils.escapeHTML = function(str) {
	return String(str).replace(/&/g, "&amp;")
	                  .replace(/"/g, "&quot;")
	                  .replace(/</g, "&lt;")
	                  .replace(/>/g, "&gt;");
};
GUIp.utils.addCSS = function () {
	if (GUIp.browser !== 'Opera' && !document.getElementById('ui_css')) {
		GUIp.addCSSFromURL(GUIp.getResource('superhero.css'), 'guip_css');
	}
};
/* aParams: {
	url:       string,
	type:      'GET'|'POST',
	postData:  string   [optional],
	onSuccess: function [optional],
	onFail:    function [optional]
}*/
GUIp.utils.sendXHR = function(aParams) {
	var xhr = new XMLHttpRequest();
	xhr.onreadystatechange = function() {
		if (this.readyState < 4) {
			return;
		} else if (this.status === 200) {
			if (aParams.onSuccess) {
				aParams.onSuccess(this);
			}
		} else if (aParams.onFail) {
			aParams.onFail(this);
		}
	};

	xhr.open(aParams.type, aParams.url, true);
	if (aParams.type === 'GET') {
		xhr.send();
	} else {
		//Send the proper header information along with the request
		xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xhr.send(aParams.postData);
	}
};
GUIp.utils.getXHR = function(aParams) {
	aParams.type = 'GET';
	GUIp.utils.sendXHR(aParams);
};
GUIp.utils.postXHR = function(aParams) {
	aParams.type = 'POST';
	GUIp.utils.sendXHR(aParams);
};
GUIp.utils.showMessage = function(msg_no, msg) {
	var id = 'msg' + msg_no;
	if (isNaN(msg_no)) {
		GUIp.utils.messagesShown.push(msg_no);
	}
	document.getElementById('menu_bar').insertAdjacentHTML('afterend',
		'<div id="' + id + '" class="hint_bar ui_msg">'+
			'<div class="hint_bar_capt"><b>' + msg.title + '</b></div>'+
			'<div class="hint_bar_content">' + msg.content + '</div>'+
			'<div class="hint_bar_close"><a id="' + id + '_close">' + GUIp.i18n.close + '</a></div>' +
		'</div>'
	);
	var msg_elem = document.getElementById(id);
	document.getElementById(id + '_close').onclick = function() {
		$(msg_elem).fadeToggle(function() {
			msg_elem.parentNode.removeChild(msg_elem);
			if (!isNaN(msg_no)) {
				GUIp.storage.set('lastShownMessage', msg_no);
			}
		});
		return false;
	};

	setTimeout(function() {
		$(msg_elem).fadeToggle(1500, msg.callback);
	}, 1000);
};
GUIp.utils.inform = function() {
	var last_shown = !isNaN(GUIp.storage.get('lastShownMessage')) ? +GUIp.storage.get('lastShownMessage') : -1;
	for (var i = 0, len = this.messages[GUIp.locale].length; i < len; i++) {
		if (this.messages[GUIp.locale][i].msg_no > last_shown) {
			GUIp.utils.showMessage(this.messages[GUIp.locale][i].msg_no, this.messages[GUIp.locale][i]);
		}
	}
};
GUIp.utils.messages = {
	ru: [{
		msg_no: 0,
		title: 'Приветственное сообщение Godville UI+',
		get content() { return '<div>Приветствую бог' + (document.title.match('её') ? 'иню' : 'а') + ', использующ' + (document.title.match('её') ? 'ую' : 'его') +
			' дополнение <b>Godville UI+</b>.</div>'+

			'<div style="text-align: justify; margin: 0.2em 0 0.3em;">&emsp;Нажмите на кнопку <b>настройки ui+</b> в верхнем меню или ' +
			'откройте вкладку <b>Настройки UI+</b> в <b>профиле</b> героя и ознакомьтесь с настройками дополнения, если еще этого не сделали.<br>' +

			'&emsp;Касательно форумных информеров: по умолчанию, вы подписаны только на тему дополнения и, скорее всего, видите ее <i>форумный информер</i> в левом верхнем углу.<br>' +

			'&emsp;Если с каким-то функционалом дополнения не удалось интуитивно разобраться — прочтите <b>статью дополнения в богии</b> ' +
			'или в соответствующей <b>теме на форуме</b>.<br>' +

			'&emsp;Инструкции на случай проблем можно прочесть в <i>диалоговом окне помощи</i> (оно сейчас открыто), которое открывается/закрывается ' +
			'по щелчку на кнопке <b style="text-decoration: underline;">help</b> в верхнем меню. Ссылки на все ранее упомянутое находятся там же.<br>' +

			'<div style="text-align: right;">Приятной игры!<br>~~Бэдлак</div>';
		},
		callback: function() {
			if (!GUIp.storage.get('helpDialogVisible')) {
				GUIp.help.toggleDialog();
			}
		}
	},
	/*{
		msg_no: 10, // 0..9 are used
		title: 'Godville UI+: Заголовок',
		content: '<div style="text-align: justify;">&emsp;Текст.</div>' +
				 '<div style="text-align: right;">Подпись.<br>~~Бэдлак</div>'
	}*/],
	en: [{
		msg_no: 0,
		title: 'Godville UI+ greeting message',
		get content() { return '<div>Greetings to a god' + (document.title.match('his') ? '' : 'dess') + ', using <b>Godville UI+</b> ' + (GUIp.browser === 'Firefox' ? 'add-on' : 'extension') + '.</div>' +
			'<div style="text-align: justify; margin: 0.2em 0 0.3em;">&emsp;Please click <b>ui+ settings</b> button at the top of a page, or ' +
			'open <b>UI+ settings</b> tab in the hero <b>profile</b> and familiarize yourself with the settings available in this ' + (GUIp.browser === 'Firefox' ? 'add-on' : 'extension') + ', if you haven\'t done so yet.<br>' +

			'&emsp;In respect to forum informers, by default you are only subscribed to the topic for this addon, and most likely you can see it <i>in the upper left corner</i> right now.<br>' +

			'&emsp;If you can\'t figure out some functions of the ' + (GUIp.browser === 'Firefox' ? 'add-on' : 'extension') + ' - feel free to ask in the forums.<br>' +

			'&emsp;Guides for handling errors can be found in the <i>help dialog</i> (which is open now), that can be shown or hidden by clicking <b style="text-decoration: underline;">ui+ help</b> in the top menu. ' +
			'Links to everything mentioned above can also be found there.<br>' +

			'<div style="text-align: right;">Enjoy the game!<br>~~Bad Luck</div>';
		},
		callback: function() {
			if (!GUIp.storage.get('helpDialogVisible')) {
				GUIp.help.toggleDialog();
			}
		}
	},
	/*{
		msg_no: 5, // 0..4 are used
		title: 'Godville UI+: Title',
		content: '<div style="text-align: justify;">&emsp;Text.</div>' +
				 '<div style="text-align: right;">Signature.<br>~~Bad Luck</div>'
	}*/]
};
GUIp.utils.getNodeIndex = function(node) {
	var i = 0;
	while ((node = node.previousElementSibling)) {
		i++;
	}
	return i;
};
GUIp.utils.openChatWith = function(friend, e) {
	if (e) {
		e.preventDefault();
		e.stopPropagation();
	}
	/*so.nm.bindings.show_friend[0].update(friend); -- fixme: this doesn't mark incoming messages as read */
	var current, friends = document.querySelectorAll('.msgDockPopupW .frline');
	for (var i = 0, len = friends.length; i < len; i++) {
		current = friends[i].querySelector('.frname');
		if (current.textContent === friend) {
			current.click();
			break;
		}
	}
};
GUIp.utils.dateToMoscowTimeZone = function(date) {
	var temp = new Date(date);
	temp.setTime(temp.getTime() + (temp.getTimezoneOffset() + (GUIp.locale === 'en' ? 115 : 175))*60*1000);
	return temp.getFullYear() + '/' +
		  (temp.getMonth() + 1 < 10 ? '0' : '') + (temp.getMonth() + 1) + '/' +
		  (temp.getDate() < 10 ? '0' : '') + temp.getDate();
};
GUIp.utils.setVoiceSubmitState = function(condition, disable) {
	if (!GUIp.data.isFight && condition) {
		var voice_submit = document.getElementById('voice_submit');
		if (disable) {
			voice_submit.setAttribute('disabled', 'disabled');
		} else {
			voice_submit.removeAttribute('disabled');
		}
		return true;
	}
	return false;
};
GUIp.utils.hideElem = function(elem, hide) {
	if (hide) {
		elem.classList.add('hidden');
	} else {
		elem.classList.remove('hidden');
	}
};
GUIp.utils._parseVersion = function(isNewestCallback, isNotNewestCallback, failCallback, xhr) {
	var match = xhr.responseText.match(/Godville UI\+ (\d+)\.(\d+)\.(\d+)\.(\d+)/);
	if (match) {
		var currentVersion = GUIp.data.currentVersion.split('.'),
		    lastVersion = [+match[1], +match[2], +match[3], +match[4]],
		    isNewest = +currentVersion[0] < lastVersion[0] ? false :
		               +currentVersion[0] > lastVersion[0] ? true  :
		               +currentVersion[1] < lastVersion[1] ? false :
		               +currentVersion[1] > lastVersion[1] ? true  :
		               +currentVersion[2] < lastVersion[2] ? false :
		               +currentVersion[2] > lastVersion[2] ? true  :
		               +currentVersion[3] < lastVersion[3] ? false : true;
		if (isNewest) {
			if (isNewestCallback) {
				isNewestCallback();
			}
		} else if (isNotNewestCallback) {
			isNotNewestCallback();
		}
	} else if (failCallback) {
		failCallback();
	}
};
GUIp.utils.checkVersion = function(isNewestCallback, isNotNewestCallback, failCallback) {
	GUIp.utils.postXHR({
		url: '/forums/last_in_topics',
		postData: 'topic_ids[]=' + (GUIp.locale === 'ru' ? '2812' : '2800'),
		onSuccess: GUIp.utils._parseVersion.bind(null, isNewestCallback, isNotNewestCallback, failCallback),
		onFail: failCallback
	});
};

GUIp.utils.processError = function(error, isDebugMode) {
	if (isDebugMode) {
		console.warn(GUIp.i18n.debug_mode_warning);
	}
	var name_message = error.name + ': ' + error.message,
		stack = error.stack && error.stack.replace(/(?:chrome-extension|@resource).*?:(\d+:\d+)/g, '@$1').split('\n').filter(function(step) {return !step.match(/GUIp\.trycatcher\.wrap/);}).join('\n') || 'no stacktrace';
	console.dir(error);
	console.log(error.stack);
	console.log(error.stack && error.stack);
	console.log(error.stack && error.stack.replace(/(?:chrome-extension|@resource).*?:(\d+:\d+)/g, '@$1').split('\n').filter(function(step) {return !step.match(/GUIp\.trycatcher\.wrap/);}).join('\n'));
	console.error('Godville UI+ error log:\n' +
						  name_message + '\n' +
						  GUIp.i18n.error_message_stack_trace + ': ' + stack);
	if (!~GUIp.utils.messagesShown.indexOf('error')) {
		GUIp.utils.showMessage('error', {
			title: GUIp.i18n.error_message_title,
			content: (isDebugMode ? '<div><b class="debug_mode_warning">' + GUIp.i18n.debug_mode_warning + '</b></div>' : '') +
					 '<div id="possible_actions">' +
						'<div>' + GUIp.i18n.error_message_text + ' <b>' + name_message + '</b>.</div>' +
						'<div>' + GUIp.i18n.possible_actions + '</div>' +
						'<ol>' +
							'<li>' + GUIp.i18n.if_first_time + '<a id="press_here_to_reload">' + GUIp.i18n.press_here_to_reload + '</a></li>' +
							'<li>' + GUIp.i18n.if_repeats + '<a id="press_here_to_show_details">' + GUIp.i18n.press_here_to_show_details + '</a></li>' +
						'</ol>' +
					 '</div>' +
					 '<div id="error_details" class="hidden">' +
						'<div>' + GUIp.i18n.error_message_subtitle + '</div>' +
						'<div>' + GUIp.i18n.browser + ' <b>' + GUIp.browser + ' ' + navigator.userAgent.match(GUIp.browser + '\/([\\d.]+)')[1] +'</b>.</div>' +
						'<div>' + GUIp.i18n.version + ' <b>' + GUIp.data.currentVersion + '</b>.</div>' +
						'<div>' + GUIp.i18n.error_message_text + ' <b>' + name_message + '</b>.</div>' +
						'<div>' + GUIp.i18n.error_message_stack_trace + ': <b>' + stack.replace(/\n/g, '<br>') + '</b></div>' +
					 '</div>',
			callback: function() {
				document.getElementById('press_here_to_reload').onclick = location.reload.bind(location);
				document.getElementById('press_here_to_show_details').onclick = function() {
					GUIp.utils.hideElem(document.getElementById('possible_actions'), true);
					GUIp.utils.hideElem(document.getElementById('error_details'), false);
					if (!GUIp.storage.get('helpDialogVisible')) {
						GUIp.help.toggleDialog();
					}
				};
			}
		});
	}
};

GUIp.utils.informAboutOldVersion = function() {
	if (!~GUIp.utils.messagesShown.indexOf('update_required')) {
		GUIp.utils.showMessage('update_required', {
			title: GUIp.i18n.error_message_title,
			content: '<div>' + GUIp.i18n.error_message_in_old_version + '</div>',
			callback: function() {
				if (!GUIp.storage.get('helpDialogVisible')) {
					GUIp.help.toggleDialog();
				}
			}
		});
	}
};

GUIp.utils.showNotification = function(title,text,callback) {
	setTimeout(function() {
		var notification = new Notification(title, {
			icon: GUIp.getResource('icon64.png'),
			body: text,
		});
		notification.onclick = callback;
		var notificationTimeout = 5, customTimeout = GUIp.storage.get('Option:informerAlertsTimeout');
		if (parseInt(customTimeout) >= 0) {
			notificationTimeout = parseInt(customTimeout);
		}
		if (notificationTimeout > 0) {
			setTimeout(function() { notification.close(); }, notificationTimeout * 1000);
		}
		setTimeout(function() { if (GUIp.utils.notiLaunch) { GUIp.utils.notiLaunch--; } }, 500);
	}, 500 * this.notiLaunch++);
};

GUIp.utils.getCurrentChat = function() {
	// not that nice but working way to get current contact name without searching for matches in HTML
	for (var obj in so.messages.nm.bindings.messages[0]) {
		if (obj.indexOf('fc_') === 0) {
			var msgBinding = so.messages.nm.bindings.messages[0][obj];
			if (msgBinding && msgBinding[0].classList.contains('frbutton_pressed')) {
				return obj.substring(3);
			}
		}
	}
	return null;
	// there should definitely be a better way to detect this, probably via so.<whatever>
	/*var docktitle = $('.frbutton_pressed .dockfrname_w .dockfrname').text().replace(/\.+/g,''),
		headtitle = $('.frbutton_pressed .frMsgBlock .fr_chat_header').text().match('^(.*?)(\ и\ е|\ and\ h)');
	if (docktitle && headtitle && headtitle[1].indexOf(docktitle) === 0) {
		return headtitle[1];
	} else {
		return null;
	}*/
};

// timeout
window.GUIp = window.GUIp || {};

GUIp.timeout = {};

GUIp.timeout.bar = null;
GUIp.timeout.timeout = 0;
GUIp.timeout._finishtDate = 0;
GUIp.timeout._tickInt = 0;
GUIp.timeout._tick = function() {
	if (Date.now() > this._finishDate) {
		clearInterval(this._tickInt);
		if (this.bar.style.transitionDuration) {
			this.bar.style.transitionDuration = '';
		}
		this.bar.classList.remove('running');
		GUIp.utils.setVoiceSubmitState(!GUIp.improver.freezeVoiceButton.match('when_empty') || document.querySelector('#god_phrase').value, false);
	}
};
// creates timeout bar element
GUIp.timeout.create = function() {
	this.bar = document.createElement('div');
	this.bar.id = 'timeout_bar';
	document.body.insertBefore(this.bar, document.body.firstChild);
};
// starts timeout bar
GUIp.timeout.start = function() {
	clearInterval(this._tickInt);
	this.bar.style.transitionDuration = '';
	this.bar.classList.remove('running');
	setTimeout(function() { GUIp.timeout._delayedStart(); }, 10);
	this._finishtDate = Date.now() + this.timeout*1000;
	this._tickInt = setInterval(function() { GUIp.timeout._tick(); }, 100);
	GUIp.utils.setVoiceSubmitState(GUIp.improver.freezeVoiceButton.match('after_voice'), true);
};
GUIp.timeout._delayedStart = function() {
	var customTimeout = GUIp.storage.get('Option:voiceTimeout');
	if (parseInt(customTimeout) > 0) {
		GUIp.timeout.timeout = customTimeout;
		GUIp.timeout.bar.style.transitionDuration = customTimeout + 's';
	} else {
		GUIp.timeout.timeout = 20;
	}
	GUIp.timeout.bar.classList.add('running');
};

// help
window.GUIp = window.GUIp || {};

GUIp.help = {};

GUIp.help.init = function() {
	GUIp.help._createHelpDialog();
	GUIp.help._createButtons();
};
// creates ui dialog
GUIp.help._createHelpDialog = function() {
	document.getElementById('menu_bar').insertAdjacentHTML('afterend',
		'<div id="guip_help" class="hint_bar" style="padding-bottom: 0.7em; display: none;">' +
		'<div class="hint_bar_capt"><b>Godville UI+ (v' + GUIp.data.currentVersion + ')</b>, ' + GUIp.i18n.help_dialog_capt + '</div>' +
		'<div class="hint_bar_content" style="padding: 0.5em 0.8em;">'+
			'<div style="text-align: left;">' +
				'<div>' + GUIp.i18n.how_to_update + '</div>' +
				'<ol>' +
					GUIp.i18n['help_update_' + GUIp.browser] +
				'</ol>' +
				'<div>' + GUIp.i18n.help_useful_links + '</div>' +
			'</div>' +
		'</div>' +
		'<div class="hint_bar_close"></div></div>'
	);

	if (GUIp.storage.get('helpDialogVisible')) { document.getElementById('guip_help').style.display = 'block'; }
};
GUIp.help._createButtons = function() {
	var menu_bar = document.querySelector('#menu_bar ul');
	menu_bar.insertAdjacentHTML('beforeend', '| <li><a href="user/profile#guip_settings">' + GUIp.i18n.guip_settings_top_menu + '</a></li> | <li></li>');
	GUIp.help._addToggleButton(menu_bar.lastElementChild, '<strong>' + GUIp.i18n.guip_help + '</strong>');
	if (GUIp.storage.get('Option:enableDebugMode')) {
		GUIp.help._addDumpButton('<span>dump: </span>', 'all');
		GUIp.help._addDumpButton('<span>, </span>', 'options', 'Option');
		GUIp.help._addDumpButton('<span>, </span>', 'logger', 'Logger');
		GUIp.help._addDumpButton('<span>, </span>', 'forum', 'Forum');
		GUIp.help._addDumpButton('<span>, </span>', 'log', 'Log:');

		document.querySelector('#guip_help .hint_bar_content').insertAdjacentHTML('beforeend', '<div><a class="devel_link" id="force_forum_check">force forum check</a></div>');
		document.getElementById('force_forum_check').onclick = GUIp.forum._check;
	}
	GUIp.help._addToggleButton(document.querySelector('#guip_help .hint_bar_close'), GUIp.i18n.close);
};
// gets toggle button
GUIp.help._addToggleButton = function(elem, text) {
	elem.insertAdjacentHTML('beforeend', '<a class="close_button">' + text + '</a>');
	elem.getElementsByClassName('close_button')[0].onclick = function() {
		GUIp.help.toggleDialog();
		return false;
	};
};
// gets dump button with a given label and selector
GUIp.help._addDumpButton = function(text, label, selector) {
	var hint_bar_content = document.querySelector('#guip_help .hint_bar_content');
	hint_bar_content.insertAdjacentHTML('beforeend', text + '<a class="devel_link" id="dump_' + label + '">' + label + '</a>');
	document.getElementById('dump_' + label).onclick = function() {
		GUIp.storage.dump(selector);
	};
};
GUIp.help.toggleDialog = function(visible) {
	GUIp.storage.set('helpDialogVisible', !GUIp.storage.get('helpDialogVisible'));
	$('#guip_help').slideToggle('slow');
};

// storage
window.GUIp = window.GUIp || {};

GUIp.storage = {};

GUIp.storage._get_key = function(key) {
	return 'GUIp_' + GUIp.data.god_name + ':' + key;
};
// gets diff with a value
GUIp.storage._diff = function(id, value) {
	var diff = null;
	var old = GUIp.storage.get(id);
	if (old !== null) {
		diff = value - old;
	}
	return diff;
};
// stores a value
GUIp.storage.set = function(id, value) {
	localStorage.setItem(GUIp.storage._get_key(id), value);
	return value;
};
// reads a value
GUIp.storage.get = function(id) {
	var val = localStorage.getItem(GUIp.storage._get_key(id));
	if (val === 'true') { return true; }
	if (val === 'false') { return false; }
	return val;
};
// deletes single item from storage
GUIp.storage.remove = function(id) {
	return localStorage.removeItem(GUIp.storage._get_key(id));
};
// stores value and gets diff with old
GUIp.storage.set_with_diff = function(id, value) {
	var diff = GUIp.storage._diff(id, value);
	GUIp.storage.set(id, value);
	return diff;
};
// dumps all values related to current god_name
GUIp.storage.dump = function(selector) {
	var lines = [],
		regexp = '^GUIp[_:]' + (selector ? (GUIp.data.god_name + ':' + selector) : '');
	for (var key in localStorage) {
		if (key.match(regexp)) {
			lines.push(key + ' = ' + localStorage.getItem(key));
		}
	}
	lines.sort();
	console.info('Godville UI+ log: Storage:\n' + lines.join('\n'));
};
// resets saved options
GUIp.storage.clear = function(what) {
	if (!what || !what.match(/^(?:GUIp|Godville|All)$/)) {
		if (GUIp.locale === 'ru') {
			console.log('Godville UI+: использование storage.clear:\n' +
							   'storage.clear("GUIp") для удаление только настроек Godville UI+\n' +
							   'storage.clear("Godville") для удаления настроек Годвилля, сохранив настройки Godville UI+\n' +
							   'storage.clear("All") для удаления всех настроек');
		} else {
			console.log('Godville UI+: storage.clear usage:\n' +
							   'storage.clear("GUIp") to remove Godville UI+ setting only\n' +
							   'storage.clear("Godville") to remove Godville setting and keep Godville UI+ settings\n' +
							   'storage.clear("All") to remove all setting');
		}
		return;
	}
	for (var key in localStorage) {
		if (what === 'GUIp' && key.match(/^GUIp_/) ||
			what === 'Godville' && !key.match(/^GUIp_/) ||
			what === 'All') {
			localStorage.removeItem(key);
		}
	}
	location.reload();
};
GUIp.storage._rename = function(from, to) {
	for (var key in localStorage) {
		if (key.match(from)) {
			localStorage.setItem(key.replace(from, to), localStorage.getItem(key));
			localStorage.removeItem(key);
		}
	}
};
GUIp.storage._delete = function(regexp) {
	for (var key in localStorage) {
		if (key.match(/^GUIp/) && key.match(regexp)) {
			localStorage.removeItem(key);
		}
	}
};
GUIp.storage.migrate = function() {
	if (!GUIp.storage._migratedAt('151009')) {
		localStorage.removeItem('GUIp_migrated');
		localStorage.removeItem('GUIp_CurrentUser');

		var godnames = [],
		    godname;
		for(var key in localStorage) {
			if (key.match(/^GUIp_([^:]+)/)) {
				godname = key.match(/^GUIp_([^:]+)/)[1];
				if (godname && !~godnames.indexOf(godname)) {
					godnames.push(godname);
				}
			}
		}
		localStorage.setItem('GUIp:godnames', godnames.join('|'));
	}
};
GUIp.storage._migratedAt = function(date) {
	var lastMigratedAt = localStorage.getItem('GUIp:lastMigratedAt');
	if (lastMigratedAt && lastMigratedAt < date) {
		localStorage.setItem('GUIp:lastMigratedAt', date);
		return true;
	} else {
		return false;
	}
};
GUIp.storage.isNewProfile = function(godname) {
	return !~(localStorage.getItem('GUIp:godnames') || '').split('|').indexOf(godname);
};
GUIp.storage.addToNames = function(godname) {
	var godnames = localStorage.getItem('GUIp:godnames');
	localStorage.setItem('GUIp:godnames', (godnames ? godnames + '|' : '') + godname);
};
// words
window.GUIp = window.GUIp || {};

GUIp.words = {};

GUIp.words.currentPhrase = '';
// gets words from phrases.js file and splits them into sections
GUIp.words.init = function() {
	var sect, text, customSects = ['pets','chosen_monsters','special_monsters'];
	this.base = GUIp.getPhrases();
	for (sect in this.base.phrases) {
		text = GUIp.storage.get('CustomPhrases:' + sect);
		if (text && text !== "") {
			this.base.phrases[sect] = text.split("||");
		}
	}
	for (sect in customSects) {
		text = GUIp.storage.get('CustomWords:' + customSects[sect]);
		if (text && text !== "") {
			try {
				this.base[customSects[sect]] = JSON.parse(text);
			} catch (error) {
				console.log('Error while parsing custom words section "'+customSects[sect]+'", resetting...');
				GUIp.storage.remove('CustomWords:' + customSects[sect]);
			}
		}
	}
};
GUIp.words._changeFirstLetter = function(text) {
	return text.charAt(0).toLowerCase() + text.slice(1);
};
GUIp.words._addHeroName = function(text) {
	if (!GUIp.storage.get('Option:useHeroName')) { return text; }
	return GUIp.data.char_name + ', ' + GUIp.words._changeFirstLetter(text);
};
GUIp.words._addExclamation = function(text) {
	if (!GUIp.storage.get('Option:useExclamations')) { return text; }
	return GUIp.utils.getRandomItem(this.base.phrases.exclamation) + ', ' + GUIp.words._changeFirstLetter(text);
};
// single phrase gen
GUIp.words._randomPhrase = function(sect) {
	return GUIp.utils.getRandomItem(this.base.phrases[sect]);
};
GUIp.words._longPhrase_recursion = function(source, len) {
	while (source.length) {
		var next = GUIp.utils.popRandomItem(source);
		var remainder = len - next.length - 2; // 2 for ', '
		if (remainder > 0) {
			return [next].concat(GUIp.words._longPhrase_recursion(source, remainder));
		}
	}
	return [];
};
// main phrase constructor
GUIp.words.longPhrase = function(sect, item_name, len) {
	if (GUIp.storage.get('phrasesChanged')) {
		GUIp.words.init();
		GUIp.storage.set('phrasesChanged', 'false');
	}
	if (!GUIp.data.isFight && ['heal', 'pray', 'hit'].indexOf(sect) >= 0) {
		sect += '_field';
	}
	var prefix = GUIp.words._addHeroName(GUIp.words._addExclamation(''));
	var phrases;
	if (item_name) {
		phrases = [GUIp.words._randomPhrase(sect) + ' ' + item_name + '!'];
	} else if (GUIp.storage.get('Option:useShortPhrases') || sect.match(/go_/)) {
		phrases = [GUIp.words._randomPhrase(sect)];
	} else {
		phrases = GUIp.words._longPhrase_recursion(this.base.phrases[sect].slice(), (len || 100) - prefix.length);
	}
	this.currentPhrase = prefix ? prefix + GUIp.words._changeFirstLetter(phrases.join(' ')) : phrases.join(' ');
	return this.currentPhrase;
};
// inspect button phrase gen
GUIp.words.inspectPhrase = function(item_name) {
	return GUIp.words.longPhrase('inspect_prefix', item_name);
};
// craft button phrase gen
GUIp.words.craftPhrase = function(items) {
	return GUIp.words.longPhrase('craft_prefix', items);
};
// Checkers
GUIp.words.usableItemType = function(desc) {
	return this.base.usable_items.descriptions.indexOf(desc);
};

// stats
window.GUIp = window.GUIp || {};

GUIp.stats = {};

GUIp.stats.Bricks = function() {
	return so.state.stats.bricks_cnt.value;
};
GUIp.stats.Charges =
GUIp.stats.Map_Charges =
GUIp.stats.Hero_Charges = function() {
	return so.state.stats.accumulator.value;
};
GUIp.stats.Death = function() {
	return so.state.stats.death_count.value;
};
GUIp.stats.Females = function() {
	return so.state.stats.ark_f && so.state.stats.ark_f.value || 0;
};
GUIp.stats.Enemy_Gold = function() {
	return so.state.o_stats.gold_we && so.state.o_stats.gold_we.value && +(so.state.o_stats.gold_we.value.match(/\d+/) || [0])[0] || 0;
};
GUIp.stats.Enemy_HP = function() {
	var opps_hp = 0;
	for (var opp in so.state.opps) {
		opps_hp += so.state.opps[opp].hp;
	}
	return opps_hp;
};
GUIp.stats.EnemySingle_HP = function(enemy) {
	return so.state.opps[enemy-1] && so.state.opps[enemy-1].hp || 0;
};
GUIp.stats.Enemy_Inv = function() {
	return so.state.o_stats.inventory_num && so.state.o_stats.inventory_num.value || 0;
};
GUIp.stats.Enemy_HasAbility = function(ability) {
	for (var opp in so.state.opps) {
		for (var ab in so.state.opps[opp].ab) {
			if (so.state.opps[opp].ab[ab].id === ability) {
				return true;
			}
		}
	}
	return false;
};
GUIp.stats.Enemy_Count = function() {
	var enemies_cnt = 0;
	for (var opp in so.state.opps) {
		enemies_cnt++;
	}
	return enemies_cnt;
};
GUIp.stats.Enemy_AliveCount = function() {
	var enemies_cnt = 0;
	for (var opp in so.state.opps) {
		if (so.state.opps[opp].hp > 0) {
			enemies_cnt++;
		}
	}
	return enemies_cnt;
};
GUIp.stats.Equip1 = function() {
	return +so.state.equipment.weapon.level;
};
GUIp.stats.Equip2 = function() {
	return +so.state.equipment.shield.level;
};
GUIp.stats.Equip3 = function() {
	return +so.state.equipment.head.level;
};
GUIp.stats.Equip4 = function() {
	return +so.state.equipment.body.level;
};
GUIp.stats.Equip5 = function() {
	return +so.state.equipment.arms.level;
};
GUIp.stats.Equip6 = function() {
	return +so.state.equipment.legs.level;
};
GUIp.stats.Equip7 = function() {
	return +so.state.equipment.talisman.level;
};
GUIp.stats.Exp =
GUIp.stats.Map_Exp =
GUIp.stats.Hero_Exp = function() {
	return so.state.stats.exp_progress.value;
};
GUIp.stats.Godpower = function() {
	return so.state.stats.godpower.value;
};
GUIp.stats.Gold =
GUIp.stats.Map_Gold =
GUIp.stats.Hero_Gold = function() {
	return so.state.stats.gold.value;
};
GUIp.stats.HP =
GUIp.stats.Map_HP =
GUIp.stats.Hero_HP = function() {
	return so.state.stats.health.value;
};
GUIp.stats.Inv =
GUIp.stats.Map_Inv =
GUIp.stats.Hero_Inv = function() {
	return so.state.stats.inventory_num.value;
};
GUIp.stats.Level = function() {
	return so.state.stats.level.value;
};
GUIp.stats.Logs = function() {
	return parseFloat(so.state.stats.wood.value)*10;
};
GUIp.stats.Males = function() {
	return so.state.stats.ark_m && so.state.stats.ark_m.value || 0;
};
GUIp.stats.Map_Alls_HP =
GUIp.stats.Hero_Alls_HP = function() {
	var allies_hp = 0;
	for (var ally in so.state.alls) {
		allies_hp += so.state.alls[ally].hp;
	}
	return allies_hp;
};
GUIp.stats.Map_Ally_HP =
GUIp.stats.Hero_Ally_HP = function(ally) {
	return so.state.alls[ally-1] && so.state.alls[ally-1].hp || 0;
};
GUIp.stats.Hero_Alls_MaxHP = function() {
	var allies_hp = 0;
	for (var ally in so.state.alls) {
		allies_hp += so.state.alls[ally].hpm;
	}
	return allies_hp;
};
GUIp.stats.Hero_Alls_Count = function() {
	var allies_cnt = 0;
	for (var ally in so.state.alls) {
		allies_cnt++;
	}
	return allies_cnt;
};
GUIp.stats.Max_Godpower = function() {
	return so.state.stats.max_gp.value;
};
GUIp.stats.Max_HP = function() {
	return so.state.stats.max_health.value;
};
GUIp.stats.Monster = function() {
	return so.state.stats.monsters_killed.value;
};
GUIp.stats.Pet_Level = function() {
	return so.state.pet.pet_level && so.state.pet.pet_level.value;
};
GUIp.stats.Pet_NameType = function() {
	var pName = so.state.pet.pet_name && so.state.pet.pet_name.value.match(/^(.*?)(\ «.*»)?$/) || '',
		pType = so.state.pet.pet_class && so.state.pet.pet_class.value || '';
	return pName[1] + ':' + pType;
};
GUIp.stats.Task = function() {
	return so.state.stats.quest_progress.value;
};
GUIp.stats.Task_Name = function() {
	return so.state.stats.quest.value;
};
GUIp.stats.Savings = function() {
	if (so.state.stats.retirement) {
		var savingsValue = so.state.stats.retirement.value.match(/^((\d+)M, )?(\d+)k$/i);
		if (savingsValue) {
			return 1000 * savingsValue[2] + 1 * savingsValue[3];
		} else {
			return parseInt(so.state.stats.retirement.value);
		}
	}
	return null;
};
GUIp.stats.petIsKnockedOut = function() {
	return so.state.pet.pet_is_dead && so.state.pet.pet_is_dead.value;
};
GUIp.stats.charName = function() {
	return so.state.stats.name.value;
};
GUIp.stats.godName = function() {
	return so.state.stats.godname.value;
};
GUIp.stats.guildName = function() {
	return so.state.stats.clan && so.state.stats.clan.value;
};
GUIp.stats.goldTextLength = function() {
	return so.state.stats.gold_we.value.length;
};
GUIp.stats.heroHasPet = function() {
	return so.state.has_pet;
};
GUIp.stats.isArenaAvailable = function() {
	return so.state.arena_available();
};
GUIp.stats.isDungeon = function() {
	return so.state.fight_type() === 'dungeon';
};
GUIp.stats.isDungeonAvailable = function() {
	return so.state.dungeon_available();
};
GUIp.stats.isFight = function() {
	return so.state.is_fighting();
};
GUIp.stats.isMale = function() {
	return so.state.stats.gender.value === 'male';
};
GUIp.stats.monsterName = function() {
	return so.state.stats.monster_name && so.state.stats.monster_name.value;
};
GUIp.stats.logId = function() {
	return so.state.stats.perm_link.value;
};
GUIp.stats.townName = function() {
	return so.state.stats.town_name && so.state.stats.town_name.value;
};

// logger
window.GUIp = window.GUIp || {};

GUIp.logger = {};

GUIp.logger.create = function() {
	this.updating = false;
	this.bar = $('<ul id="logger" style="mask: url(#fader_masking);"/>');
	$('#menu_bar').after(this.bar);
	this.need_separator = false;
	this.dungeonWatchers = [
		['Map_HP', 'hp', GUIp.i18n.hero_health, 'hp'],
		['Map_Exp', 'exp', GUIp.i18n.exp, 'exp'],
		['Map_Inv', 'inv', GUIp.i18n.inventory, 'inv'],
		['Map_Gold', 'gld', GUIp.i18n.gold, 'gold'],
		['Map_Charges', 'ch', GUIp.i18n.charges, 'charges'],
		['Map_Alls_HP', 'a:hp', GUIp.i18n.allies_health, 'allies']
	];
	this.battleWatchers = [
		['Hero_HP', 'h:hp', GUIp.i18n.hero_health, 'hp'],
		['Enemy_HP', 'e:hp', GUIp.i18n.enemy_health, 'death'],
		['Hero_Alls_HP', 'a:hp', GUIp.i18n.allies_health, 'allies'],
		['Hero_Inv', 'h:inv', GUIp.i18n.inventory, 'inv'],
		['Hero_Gold', 'h:gld', GUIp.i18n.gold, 'gold'],
		['Hero_Charges', 'ch', GUIp.i18n.charges, 'charges'],
		['Enemy_Gold', 'e:gld', GUIp.i18n.gold, 'monster'],
		['Enemy_Inv', 'e:inv', GUIp.i18n.inventory, 'monster']
	];
	this.fieldWatchers = [
		['Exp', 'exp', GUIp.i18n.exp],
		['Level', 'lvl', GUIp.i18n.level],
		['HP', 'hp', GUIp.i18n.health],
		['Charges', 'ch', GUIp.i18n.charges],
		['Task', 'tsk', GUIp.i18n.task],
		['Monster', 'mns', GUIp.i18n.monsters],
		['Inv', 'inv', GUIp.i18n.inventory],
		['Gold', 'gld', GUIp.i18n.gold],
		['Bricks', 'br', GUIp.i18n.bricks],
		['Logs', 'wd', GUIp.i18n.logs],
		['Savings', 'rtr', GUIp.i18n.savings],
		['Equip1', 'eq1', GUIp.i18n.weapon, 'equip'],
		['Equip2', 'eq2', GUIp.i18n.shield, 'equip'],
		['Equip3', 'eq3', GUIp.i18n.head, 'equip'],
		['Equip4', 'eq4', GUIp.i18n.body, 'equip'],
		['Equip5', 'eq5', GUIp.i18n.arms, 'equip'],
		['Equip6', 'eq6', GUIp.i18n.legs, 'equip'],
		['Equip7', 'eq7', GUIp.i18n.talisman, 'equip'],
		['Death', 'death', GUIp.i18n.death_count],
		['Pet_Level', 'pet_level', GUIp.i18n.pet_level, 'monster']
	];
	this.commonWatchers = [
		['Females', 'females', GUIp.i18n.females, 'godmonster'],
		['Godpower', 'gp', GUIp.i18n.godpower],
		['Males', 'males', GUIp.i18n.males, 'godmonster']
	];
};
GUIp.logger._appendStr = function(id, klass, str, descr) {
	// append separator if needed
	if (this.need_separator) {
		this.need_separator = false;
		if (this.bar.children().length > 0) {
			this.bar.append('<li class="separator">|</li>');
		}
	}
	// append string
	this.bar.append('<li class="' + klass + '" title="' + descr + '">' + str + '</li>');
	this.bar.scrollLeft(10000); //Dirty fix
	while ($('#logger li').position().left + $('#logger li').width() < 0 || $('#logger li')[0].className === "separator") {
		$('#logger li:first').remove();
	}
};
GUIp.logger._watchStatsValue = function(id, name, descr, klass) {
	klass = (klass || id).toLowerCase();
	var i, len, diff;
	if (name === 'a:hp' && !GUIp.storage.get('Option:sumAlliesHp')) {
		var damageData = [];
		for (i = 1, len = GUIp.stats.Hero_Alls_Count(); i <= len; i++)
		{
			diff = GUIp.storage.set_with_diff('Logger:'+(id === 'Hero_Alls_HP' ? 'Hero' : 'Map')+'_Ally'+i+'_HP', GUIp.stats.Hero_Ally_HP(i));
			if (diff) {
				damageData.push({ num: i, diff: diff, cnt: 0, fuzz: 0, cntf: 0 });
			}
		}
		if (!damageData.length) {
			return;
		}
		for (i = 0, len = damageData.length; i < len; i++) {
			for (var j = (i + 1); j < damageData.length; j++) {
				if (damageData[j].processed) {
					continue;
				}
				if (damageData[i].diff === damageData[j].diff) {
					damageData[i].cnt++;
					damageData[j].processed = true;
				} else if (Math.abs(damageData[i].diff - damageData[j].diff) < 3) {
					damageData[i].cntf++;
					damageData[i].fuzz = (damageData[i].fuzz ? damageData[i].fuzz : damageData[i].diff) + damageData[j].diff;
					damageData[j].processed = true;
				}
			}
		}
		damageData.sort(function(a,b) {return a.cnt === b.cnt ? a.num - b.num : b.cnt - a.cnt;});
		for (i = 0, len = damageData.length; i < len; i++) {
			if (damageData[i].processed) {
				continue;
			}
			if (damageData[i].fuzz) {
				GUIp.logger._appendStr(id, klass, 'a:hp' + (damageData[i].fuzz > 0 ? '⨦' : '≂') + Math.abs(Math.round((damageData[i].fuzz + damageData[i].diff * damageData[i].cnt)/(damageData[i].cnt + damageData[i].cntf + 1))) + 'x' + (damageData[i].cnt + damageData[i].cntf + 1), descr);
			} else if (damageData[i].cnt > 0) {
				GUIp.logger._appendStr(id, klass, 'a:hp' + (damageData[i].diff > 0 ? '+' : '') + damageData[i].diff + 'x' + (damageData[i].cnt + 1), descr);
			} else {
				GUIp.logger._appendStr(id, klass, 'a' + damageData[i].num + ':hp' + (damageData[i].diff > 0 ? '+' : '') + damageData[i].diff, descr);
			}
		}
		return;
	}
	if (name === 'e:hp' && !GUIp.storage.get('Option:sumAlliesHp')) {
		for (i = 1, len = GUIp.stats.Enemy_Count(); i <= len; i++)
		{
			diff = GUIp.storage.set_with_diff('Logger:Enemy'+i+'_HP', GUIp.stats.EnemySingle_HP(i));
			if (diff) {
				GUIp.logger._appendStr(id, klass, 'e' + (len > 1 ? i : '') + ':hp' + (diff > 0 ? '+' : '') + diff, descr);
			}
		}
		return;
	}
	var s;
	diff = GUIp.storage.set_with_diff('Logger:' + id, GUIp.stats[id]());
	if (diff) {
		// Если нужно, то преобразовываем в число с одним знаком после запятой
		if (parseInt(diff) !== diff) { diff = diff.toFixed(1); }
		// Добавление плюcа, минуса или стрелочки
		if (diff < 0) {
			if (name === 'exp' && +GUIp.storage.get('Logger:Level') !== GUIp.stats.Level()) {
				s = '→' + GUIp.stats.Exp();
			} else if (name === 'tsk' && GUIp.storage.get('Logger:Task_Name') !== GUIp.stats.Task_Name()) {
				GUIp.storage.set('Logger:Task_Name', GUIp.stats.Task_Name());
				s = '→' + GUIp.stats.Task();
			} else {
				s = diff;
			}
		} else {
			s = '+' + diff;
		}
		// pet changing
		if (name === 'pet_level' && GUIp.storage.get('Logger:Pet_NameType') !== GUIp.stats.Pet_NameType()) {
			s = '→' + GUIp.stats.Pet_Level();
		}
		GUIp.logger._appendStr(id, klass, name + s, descr);
	}
};
GUIp.logger._updateWatchers = function(watchersList) {
	for (var i = 0, len = watchersList.length; i < len; i++) {
		GUIp.logger._watchStatsValue.apply(this, watchersList[i]);
	}
};
GUIp.logger.update = function() {
	if (GUIp.storage.get('Option:disableLogger')) {
		this.bar.hide();
		return;
	} else {
		this.bar.show();
	}
	if (GUIp.data.isDungeon) {
		GUIp.logger._updateWatchers(this.dungeonWatchers);
	} else if (GUIp.data.isFight) {
		GUIp.logger._updateWatchers(this.battleWatchers);
	} else {
		GUIp.logger._updateWatchers(this.fieldWatchers);
	}
	GUIp.logger._updateWatchers(this.commonWatchers);
	this.need_separator = true;
};

// informer
window.GUIp = window.GUIp || {};

GUIp.informer = {};

GUIp.informer.init = function() {
	//title saver
	this.title = document.title;
	//favicon saver
	this.favicon = document.querySelector('link[rel="shortcut icon"]');
	// container
	document.getElementById('main_wrapper').insertAdjacentHTML('afterbegin', '<div id="informer_bar" />');
	this.container = document.getElementById('informer_bar');
	// load
	GUIp.informer._load();
};
GUIp.informer._load = function() {
	this.flags = JSON.parse(GUIp.storage.get('informer_flags') || '{}');
	for (var flag in this.flags) {
		if (this.flags[flag]) {
			delete this.flags[flag];
		}
	}
	GUIp.informer._save();
};
GUIp.informer._save = function() {
	GUIp.storage.set('informer_flags', JSON.stringify(this.flags));
};
GUIp.informer._createLabel = function(flag) {
	var id = flag.replace(/ /g, '_');
	this.container.insertAdjacentHTML('beforeend', '<div id="' + id + '">' + flag + '</div>');
	document.getElementById(id).onclick = function(e) {
		GUIp.informer.hide(flag);
		e.stopPropagation();
	};
};
GUIp.informer._deleteLabel = function(flag) {
	var label = document.getElementById(flag.replace(/ /g, '_'));
	if (label) {
		this.container.removeChild(label);
	}
};
GUIp.informer._tick = function() {
	// пройти по всем флагам и выбрать те, которые надо показывать
	var activeFlags = [];
	for (var flag in this.flags) {
		if (this.flags[flag]) {
			activeFlags.push(flag);
		}
	}
	activeFlags.sort();

	// если есть чё, показать или вернуть стандартный заголовок
	if (activeFlags.length) {
		GUIp.informer._updateTitle(activeFlags);
		this.tref = setTimeout(function() { GUIp.informer._tick(); }, 700);
	} else {
		GUIp.informer.clearTitle();
		this.tref = 0;
	}
};
GUIp.informer.clearTitle = function() {
	for (var flag in this.flags) {
		if (this.flags[flag]) {
			return;
		}
	}
	document.title = GUIp.informer._getTitleNotices() + this.title;
	this.favicon.href = 'images/favicon.ico';
};
GUIp.informer._getTitleNotices = function() {
	var forbidden_title_notices = GUIp.storage.get('Option:forbiddenTitleNotices') || '';
	var titleNotices = (!forbidden_title_notices.match('pm') ? GUIp.informer._getPMTitleNotice() : '') +
					   (!forbidden_title_notices.match('gm') ? GUIp.informer._getGMTitleNotice() : '') +
					   (!forbidden_title_notices.match('fi') ? GUIp.informer._getFITitleNotice() : '');
	return titleNotices ? titleNotices + ' ' : '';
};
GUIp.informer._getPMTitleNotice = function() {
	var pm = 0,
		pm_badge = document.querySelector('.fr_new_badge_pos');
	if (pm_badge && pm_badge.style.display !== 'none') {
		pm = +pm_badge.textContent;
	}
	var stars = document.querySelectorAll('.msgDock .fr_new_msg');
	for (var i = 0, len = stars.length; i < len; i++) {
		if (!stars[i].parentNode.getElementsByClassName('dockfrname')[0].textContent.match(/Гильдсовет|Guild Council/)) {
			pm++;
		}
	}
	return pm ? '[' + pm + ']' : '';
};
GUIp.informer._getGMTitleNotice = function() {
	var gm = document.getElementsByClassName('gc_new_badge')[0].style.display !== 'none',
		stars = document.querySelectorAll('.msgDock .fr_new_msg');
	for (var i = 0, len = stars.length; i < len; i++) {
		if (stars[i].parentNode.getElementsByClassName('dockfrname')[0].textContent.match(/Гильдсовет|Guild Council/)) {
			gm = true;
			break;
		}
	}
	return gm ? '[g]' : '';
};
GUIp.informer._getFITitleNotice = function() {
	return document.querySelector('#forum_informer_bar a') ? '[f]' : '';
};
GUIp.informer._updateTitle = function(activeFlags) {
	this.odd_tick = !this.odd_tick;
	var sep = this.odd_tick ? '!!!' : '...';
	document.title = GUIp.informer._getTitleNotices() + sep + ' ' + activeFlags.join('! ') + ' ' + sep;
	if (GUIp.browser !== 'Opera' && !GUIp.storage.get('Option:disableFaviconFlashing')) {
		this.favicon.href = this.odd_tick ? 'images/favicon.ico'
		                                  : 'data:image/x-icon;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQEAYAAABPYyMiAAAABmJLR0T///////8JWPfcAAAACXBIWXMAAABIAAAASABGyWs+AAAAF0lEQVRIx2NgGAWjYBSMglEwCkbBSAcACBAAAeaR9cIAAAAASUVORK5CYII=';
	} else if (this.favicon.href !== 'images/favicon.ico') {
		this.favicon.href = 'images/favicon.ico';
	}
};
GUIp.informer.update = function(flag, value) {
	if (value && (flag === 'fight' || flag === 'low health' || !(GUIp.data.isFight && !GUIp.data.isDungeon)) && !(flag === 'much gold' && GUIp.data.hasTemple && GUIp.stats.townName()) &&
		!(GUIp.storage.get('Option:forbiddenInformers') && GUIp.storage.get('Option:forbiddenInformers').match(flag.replace(/ /g, '_')))) {
		if (this.flags[flag] === undefined) {
			this.flags[flag] = true;
			GUIp.informer._createLabel(flag);
			GUIp.informer._save();
			if (!this.tref) {
				GUIp.informer._tick();
			}
			/* [E] desktop notifications */
			if (GUIp.storage.get('Option:enableInformerAlerts') && GUIp.browser !== 'Opera' && Notification.permission === "granted") {
				var title = '[INFO] ' + GUIp.data.god_name,
					text = flag,
					callback = function(){GUIp.informer.hide(flag);};
				GUIp.utils.showNotification(title,text,callback);
			}
			/* [E] if flag is 'tamable' then play arena sound (as no other sounds are available). feature requested by... заядлые звероводы из Рядов Фурье ^_^ */
			if (flag === 'tamable monster') {
				if (so.play_sound_orig) {
					so.play_sound_orig('arena.mp3',false);
				}
			}
		}
	} else if (this.flags[flag] !== undefined) {
		delete this.flags[flag];
		GUIp.informer._deleteLabel(flag);
		GUIp.informer._save();
	}
};
GUIp.informer.hide = function(flag) {
	this.flags[flag] = false;
	GUIp.informer._deleteLabel(flag);
	GUIp.informer._save();
};

// forum
window.GUIp = window.GUIp || {};

GUIp.forum = {};

GUIp.forum.init = function() {
	document.body.insertAdjacentHTML('afterbegin', '<div id="forum_informer_bar" />');
	GUIp.forum._check();
	setInterval(function() { GUIp.forum._check(); }, 2.5*60*1000);
};
GUIp.forum._check = function() {
	var requests = 0;
	for (var forum_no = 1; forum_no <= (GUIp.locale === 'ru' ? 6 : 4); forum_no++) {
		var current_forum = JSON.parse(GUIp.storage.get('Forum' + forum_no)),
			topics = [];
		for (var topic in current_forum) {
			topics.push('topic_ids[]=' + topic);
		}
		for (var i = 0, len = topics.length; i < len; i += 10) {
			var postData = topics.slice(i, i + 10).join('&');
			GUIp.forum._sendPostXHR(postData, forum_no, requests++);
		}
	}
};
GUIp.forum._sendPostXHR = function(postData, forumNo, requestNo) {
	setTimeout(function() {
		GUIp.utils.postXHR({
			url: '/forums/last_in_topics',
			postData: postData,
			onSuccess: GUIp.forum._parse.bind(forumNo)
		});
	}, 500*requestNo);
};
GUIp.forum._process = function(forum_no) {
	var informers = JSON.parse(GUIp.storage.get('ForumInformers')),
		topics = JSON.parse(GUIp.storage.get('Forum' + forum_no));
	for (var topic in topics) {
		if (informers[topic]) {
			GUIp.forum._setInformer(topic, informers[topic], topics[topic].posts);
		}
	}
	GUIp.informer.clearTitle();
};
GUIp.forum._setInformer = function(topic_no, topic_data, posts_count) {
	var informer = document.getElementById('topic' + topic_no);
	if (!informer) {
		document.getElementById('forum_informer_bar').insertAdjacentHTML('beforeend',
			'<a id="topic' + topic_no + '" target="_blank"><span></span><div class="fr_new_badge"></div></a>'
		);
		informer = document.getElementById('topic' + topic_no);
		informer.onclick = function(e) {
			if (e.which === 1) {
				e.preventDefault();
			}
		};
		informer.onmouseup = function(e) {
			if (e.which === 1 || e.which === 2) {
				var informers = JSON.parse(GUIp.storage.get('ForumInformers'));
				delete informers[this.id.match(/\d+/)[0]];
				GUIp.storage.set('ForumInformers', JSON.stringify(informers));
				$(this).slideToggle("fast", function() {
					if (this.parentElement) {
						this.parentElement.removeChild(this);
						GUIp.informer.clearTitle();
					}
				});
			}
		};
	}
	var page = Math.floor((posts_count - topic_data.diff)/25) + 1;
	informer.href = '/forums/show_topic/' + topic_no + '?page=' + page + '#guip_' + (posts_count - topic_data.diff + 25 - page*25);
	informer.style.paddingRight = (16 + String(topic_data.diff).length*6) + 'px';
	informer.getElementsByTagName('span')[0].textContent = topic_data.name;
	informer.getElementsByTagName('div')[0].textContent = topic_data.diff;
};
GUIp.forum._parse = function(xhr) {
	var responseJSON = JSON.parse(xhr.responseText);
	if (responseJSON.status !== 'success' || !responseJSON.topics) {
		return;
	}

	var forum_no = this,
	    forum = JSON.parse(GUIp.storage.get('Forum' + forum_no)),
	    informers = JSON.parse(GUIp.storage.get('ForumInformers')),
	    topics = responseJSON.topics,
	    diff, topic;
	for (var topic_no in topics) {
		topic = topics[topic_no];
		diff = topic.cnt - forum[topic_no].posts;

		if (diff <= 0 && forum[topic_no].date && (Date(forum[topic_no].date) < Date(topic.last_post_at))) {
			diff = 1;
		}

		forum[topic_no].posts = topic.cnt;
		forum[topic_no].date = topic.last_post_at;

		if (diff > 0) {
			if (topic.last_post_by !== GUIp.data.god_name) {
				informers[topic_no] = {
					diff: diff + (informers[topic_no] ? informers[topic_no].diff : 0),
					name: topic.title
				};
			} else {
				delete informers[topic_no];
			}
		}
	}
	GUIp.storage.set('ForumInformers', JSON.stringify(informers));
	GUIp.storage.set('Forum' + forum_no, JSON.stringify(forum));
	GUIp.forum._process(forum_no);
};

// improver
window.GUIp = window.GUIp || {};

GUIp.improver = {};

GUIp.improver.improveTmt = 0;
GUIp.improver.isFirstTime = true;
GUIp.improver.pmParsed = false;
GUIp.improver.pmNoted = {};
GUIp.improver.voiceSubmitted = false;
GUIp.improver.wantedMonsters = null;
GUIp.improver.friendsRegExp = null;
GUIp.improver.windowResizeInt = 0;
GUIp.improver.mapColorizationTmt = 0;
// dungeon
GUIp.improver.chronicles = {};
GUIp.improver.directionlessMoveIndex = 0;
GUIp.improver.dungeonPhrases = [
	'bossHint',
	'boss',
	'bonusGodpower',
	'bonusHealth',
	'trapUnknown',
	'trapTrophy',
	'trapGold',
	'trapLowDamage',
	'trapModerateDamage',
	'trapMoveLoss',
	'jumpingDungeon',
	'pointerMarker'
];
GUIp.improver.corrections = { n: 'north', e: 'east', s: 'south', w: 'west' };
GUIp.improver.pointerRegExp = new RegExp('[^а-яa-z](северо-восток|северо-запад|юго-восток|юго-запад|' +
														'север|восток|юг|запад|' +
														'очень холодно|холодно|свежо|тепло|очень горячо|горячо|' +
														'north-east|north-west|south-east|south-west|' +
														'north|east|south|west|' +
														'freezing|very cold|cold|mild|warm|hot|burning|very hot|hot)', 'gi');
GUIp.improver.dungeonXHRCount = 0;
GUIp.improver.needLog = true;
// resresher
GUIp.improver.softRefreshInt = 0;
GUIp.improver.hardRefreshInt = 0;
GUIp.improver.softRefresh = function() {
	console.info('Godville UI+ log: Soft reloading...');
	document.getElementById('d_refresh').click();
};
GUIp.improver.hardRefresh = function() {
	console.warn('Godville UI+ log: Hard reloading...');
	location.reload();
};
GUIp.improver.improve = function() {
	this.improveInProcess = true;
	GUIp.informer.update('fight', GUIp.data.isFight && !GUIp.data.isDungeon);
	GUIp.informer.update('arena available', GUIp.stats.isArenaAvailable());
	GUIp.informer.update('dungeon available', GUIp.stats.isDungeonAvailable());

	this.optionsChanged = this.isFirstTime ? false : GUIp.storage.get('optionsChanged');
	if (this.isFirstTime) {
		if (!GUIp.data.isFight && !GUIp.data.isDungeon) {
			GUIp.improver.improveDiary();
		}
		if (GUIp.data.isDungeon) {
			GUIp.improver.getDungeonPhrases();
		}
	}
	GUIp.improver.improveStats();
	GUIp.improver.improvePet();
	GUIp.improver.improveVoiceDialog();
	if (!GUIp.data.isFight) {
		GUIp.improver.improveNews();
		GUIp.improver.improveEquip();
		GUIp.improver.improvePantheons();
	}
	if (this.isFirstTime && GUIp.data.isDungeon) {
		GUIp.improver.improveMap();
	}
	GUIp.improver.improveInterface();
	GUIp.improver.improveChat();
	if (GUIp.data.isFight || GUIp.data.isDungeon) {
		GUIp.improver.improveAllies();
	}
	GUIp.improver.calculateButtonsVisibility();
	this.isFirstTime = false;
	this.improveInProcess = false;
	GUIp.storage.set('optionsChanged', false);
};
GUIp.improver.improveVoiceDialog = function() {
	// If playing in pure ZPG mode there won't be present voice input block at all;
	if (!document.getElementById('voice_edit_wrap')) {
		return;
	}
	if (this.isFirstTime || this.optionsChanged) {
		this.freezeVoiceButton = GUIp.storage.get('Option:freezeVoiceButton') || '';
	}
	// Add voicegens and show timeout bar after saying
	if (this.isFirstTime) {
		GUIp.utils.setVoiceSubmitState(this.freezeVoiceButton.match('when_empty'), true);
		$(document).on('change keypress paste focus textInput input', '#god_phrase', function() {
			if (!GUIp.utils.setVoiceSubmitState(this.value && !(GUIp.improver.freezeVoiceButton.match('after_voice') && parseInt(GUIp.timeout.bar.style.width)), false)) {
				GUIp.utils.setVoiceSubmitState(GUIp.improver.freezeVoiceButton.match('when_empty'), true);
			}
			GUIp.utils.hideElem(document.getElementById('clear_voice_input'), !this.value);
		}).on('click', '.gv_text.div_link', function() {
			GUIp.utils.triggerChangeOnVoiceInput();
		});
		document.getElementById('voice_edit_wrap').insertAdjacentHTML('afterbegin', '<div id="clear_voice_input" class="div_link_nu gvl_popover hidden" title="' + GUIp.i18n.clear_voice_input + '">×</div>');
		document.getElementById('clear_voice_input').onclick = function() {
			GUIp.utils.setVoice('');
		};
		document.getElementById('voice_submit').onclick = function() {
			GUIp.utils.hideElem(document.getElementById('clear_voice_input'), true);
			GUIp.improver.voiceSubmitted = true;
		};

			if (!GUIp.utils.isAlreadyImproved(document.getElementById('cntrl'))) {
			var gp_label = document.getElementsByClassName('gp_label')[0];
			gp_label.classList.add('l_capt');
			document.getElementsByClassName('gp_val')[0].classList.add('l_val');
			if (GUIp.data.isDungeon && document.getElementById('map')) {
				var isContradictions = document.getElementById('map').textContent.match(/Противоречия|Disobedience/);
				GUIp.utils.addVoicegen(gp_label, GUIp.i18n.east, (isContradictions ? 'go_west' : 'go_east'), GUIp.i18n.ask3 + GUIp.data.char_sex[0] + GUIp.i18n.go_east);
				GUIp.utils.addVoicegen(gp_label, GUIp.i18n.west, (isContradictions ? 'go_east' : 'go_west'), GUIp.i18n.ask3 + GUIp.data.char_sex[0] + GUIp.i18n.go_west);
				GUIp.utils.addVoicegen(gp_label, GUIp.i18n.south, (isContradictions ? 'go_north' : 'go_south'), GUIp.i18n.ask3 + GUIp.data.char_sex[0] + GUIp.i18n.go_south);
				GUIp.utils.addVoicegen(gp_label, GUIp.i18n.north, (isContradictions ? 'go_south' : 'go_north'), GUIp.i18n.ask3 + GUIp.data.char_sex[0] + GUIp.i18n.go_north);
			} else {
				if (GUIp.data.isFight) {
					GUIp.utils.addVoicegen(gp_label, GUIp.i18n.defend, 'defend', GUIp.i18n.ask4 + GUIp.data.char_sex[0] + GUIp.i18n.to_defend);
					GUIp.utils.addVoicegen(gp_label, GUIp.i18n.pray, 'pray', GUIp.i18n.ask5 + GUIp.data.char_sex[0] + GUIp.i18n.to_pray);
					GUIp.utils.addVoicegen(gp_label, GUIp.i18n.heal, 'heal', GUIp.i18n.ask6 + GUIp.data.char_sex[1] + GUIp.i18n.to_heal);
					GUIp.utils.addVoicegen(gp_label, GUIp.i18n.hit, 'hit', GUIp.i18n.ask7 + GUIp.data.char_sex[1] + GUIp.i18n.to_hit);
				} else {
					GUIp.utils.addVoicegen(gp_label, GUIp.i18n.sacrifice, 'sacrifice', GUIp.i18n.ask8 + GUIp.data.char_sex[1] + GUIp.i18n.to_sacrifice);
					GUIp.utils.addVoicegen(gp_label, GUIp.i18n.pray, 'pray', GUIp.i18n.ask5 + GUIp.data.char_sex[0] + GUIp.i18n.to_pray);
				}
			}
		}
	}
	//hide_charge_button
	var charge_button = document.querySelector('#cntrl .hch_link');
	charge_button.style.visibility = GUIp.storage.get('Option:hideChargeButton') ? 'hidden' : '';
	GUIp.informer.update('full godpower', GUIp.stats.Godpower() === GUIp.stats.Max_Godpower() && !GUIp.data.isDungeon);
};
GUIp.improver.improveNews = function() {
	if (!GUIp.utils.isAlreadyImproved(document.getElementById('news'))) {
		GUIp.utils.addVoicegen(document.querySelector('#news .l_capt'), GUIp.i18n.hit, 'hit', GUIp.i18n.ask7 + GUIp.data.char_sex[1] + GUIp.i18n.to_hit);
	}
	var isWantedMonster = false,
		isSpecialMonster = false,
		isTamableMonster = false,
		isFavoriteMonster = false;
	// Если герой дерется с монстром
	var currentMonster = GUIp.stats.monsterName();
	if (currentMonster) {
		isWantedMonster = this.wantedMonsters && currentMonster.match(this.wantedMonsters);
		if (GUIp.words.base.special_monsters.length) {
			isSpecialMonster = currentMonster.match(new RegExp(GUIp.words.base.special_monsters.join('|'),'i'));
		}
		if (GUIp.words.base.chosen_monsters.length) {
			isFavoriteMonster = currentMonster.match(new RegExp(GUIp.words.base.chosen_monsters.join('|'),'i'));
		}
		if (!GUIp.stats.heroHasPet()) {
			var hasArk = GUIp.stats.Logs() >= 1000;
			var pet, hero_level = GUIp.stats.Level();
			for (var i = 0; i < GUIp.words.base.pets.length; i++) {
				pet = GUIp.words.base.pets[i];
				if (currentMonster.toLowerCase() === pet.name.toLowerCase() && hero_level >= pet.min_level && hero_level <= (pet.min_level + (hasArk ? 29 : 14))) {
					isTamableMonster = true;
					break;
				}
			}
		}
	}

	GUIp.informer.update('wanted monster', isWantedMonster);
	GUIp.informer.update('special monster', isSpecialMonster);
	GUIp.informer.update('tamable monster', isTamableMonster);
	GUIp.informer.update('chosen monster', isFavoriteMonster);

	if (GUIp.data.hasTemple && this.optionsChanged) {
		GUIp.timers.layingTimerIsDisabled = GUIp.storage.get('Option:disableLayingTimer');
		GUIp.utils.hideElem(GUIp.timers.layingTimer ? GUIp.timers.layingTimer : GUIp.timers.logTimer, GUIp.timers.layingTimerIsDisabled); // todo: if it's got enabled, it should also be made clickable and switchable.
		GUIp.timers.tick();
	}
};
GUIp.improver.improveMap = function() {
	if (this.isFirstTime) {
		var legendDiv = document.getElementsByClassName('map_legend')[0].nextElementSibling;
		legendDiv.style.marginLeft = 0;
		legendDiv.insertAdjacentHTML('beforeend',
			'<div class="guip_legend"><div class="dmc bossHint"></div><div> - ' + GUIp.i18n.boss_warning_hint + '</div></div>' +
			'<div class="guip_legend"><div class="dmc boss"></div><div> - ' + GUIp.i18n.boss_slay_hint + '</div></div>' +
			'<div class="guip_legend"><div class="dmc bonusGodpower"></div><div> - ' + GUIp.i18n.small_prayer_hint + '</div></div>' +
			'<div class="guip_legend"><div class="dmc bonusHealth"></div><div> - ' + GUIp.i18n.small_healing_hint + '</div></div>' +
			'<div class="guip_legend"><div class="dmc trapUnknown"></div><div> - ' + GUIp.i18n.unknown_trap_hint + '</div></div>' +
			'<div class="guip_legend"><div class="dmc trapTrophy"></div><div> - ' + GUIp.i18n.trophy_loss_trap_hint + '</div></div>' +
			'<div class="guip_legend"><div class="dmc trapLowDamage"></div><div> - ' + GUIp.i18n.low_damage_trap_hint + '</div></div>' +
			'<div class="guip_legend"><div class="dmc trapModerateDamage"></div><div> - ' + GUIp.i18n.moderate_damage_trap_hint + '</div></div>' +
			'<div class="guip_legend"><div class="dmc trapMoveLoss"></div><div> - ' + GUIp.i18n.move_loss_trap_hint + '</div></div>' +
			'<div class="guip_legend"><div class="dmc bossHint trapMoveLoss"></div><div> - ' + GUIp.i18n.boss_warning_and_trap_hint + '</div></div>' +
			'<div class="guip_legend"><div class="dmc boss trapMoveLoss"></div><div> - ' + GUIp.i18n.boss_slay_and_trap_hint + '</div></div>' +
			'<div class="guip_legend"><div class="dmc" style="color: red;">?</div><div> - ' + GUIp.i18n.treasury_hint + '</div></div>' +
			'<div class="guip_legend"><div class="dmc" style="color: darkorange;">?</div><div> - ' + GUIp.i18n.treasury_th_hint + '</div></div>'
		);
	}
	if (this.isFirstTime || this.optionsChanged) {
		var control = document.getElementById('m_control'),
			map = document.getElementById('map'),
			right_block = document.getElementById('a_right_block');
		if (GUIp.storage.get('Option:relocateMap')) {
			if (!document.querySelector('#a_central_block #map')) {
				control.parentNode.insertBefore(map, control);
				right_block.insertBefore(control, null);
				if (GUIp.locale === 'ru') {
					document.querySelector('#m_control .block_title').textContent = 'Пульт';
				}
			}
		} else {
			if (!document.querySelector('#a_right_block #map')) {
				map.parentNode.insertBefore(control, map);
				right_block.insertBefore(map, null);
				if (GUIp.locale === 'ru') {
					document.querySelector('#m_control .block_title').textContent = 'Пульт вмешательства в личную жизнь';
				}
			}
		}
	}
	if (document.querySelectorAll('#map .dml').length) {
		var i, j, ik, jk, len, chronolen = +Object.keys(this.chronicles).reverse()[0],
			$box = $('#cntrl .voice_generator'),
			$boxML = $('#map .dml'),
			$boxMC = $('#map .dmc'),
			kRow = $boxML.length,
			kColumn = $boxML[0].textContent.length,
			isJumping = document.getElementById('map').textContent.match(/Прыгучести|Jumping|Загадки|Mystery/), /* [E] allow moving almost everywhere in Mystery as it could be Jumping or Disobedience */
			MaxMap = 0,      	// count of any pointers
			MaxMapThermo = 0, // count of thermo pointers
			MapArray = [];
		for (i = 0; i < kRow; i++) {
			MapArray[i] = [];
			for (j = 0; j < kColumn; j++) {
				MapArray[i][j] = ('?!@'.indexOf($boxML[i].textContent[j]) !== - 1) ? 0 : -1;
			}
		}
		// Гласы направления делаем невидимыми
		for (i = 0; i < 4; i++) {
			$box[i].style.visibility = 'hidden';
		}
		for (var si = 0; si < kRow; si++) {
			// Ищем где мы находимся
			j = $boxML[si].textContent.indexOf('@');
			if (j !== -1) {
				var isMoveLoss = [];
				for (i = 0; i < 4; i++) {
					isMoveLoss[i] = chronolen > i && this.chronicles[chronolen - i].marks.indexOf('trapMoveLoss') !== -1;
				}
				var directionsShouldBeShown = !isMoveLoss[0] || (isMoveLoss[1] && (!isMoveLoss[2] || isMoveLoss[3]));
				if (directionsShouldBeShown) {
					//	Проверяем куда можно пройти
					if ($boxML[si - 1].textContent[j] !== '#' || isJumping && (si === 1 || si !== 1 && $boxML[si - 2].textContent[j] !== '#')) {
						$box[0].style.visibility = '';	//	Север
					}
					if ($boxML[si + 1].textContent[j] !== '#' || isJumping && (si === kRow - 2 || si !== kRow - 2 && $boxML[si + 2].textContent[j] !== '#')) {
						$box[1].style.visibility = '';	//	Юг
					}
					if ($boxML[si].textContent[j - 1] !== '#' || isJumping && $boxML[si].textContent[j - 2] !== '#') {
						$box[2].style.visibility = '';	//	Запад
					}
					if ($boxML[si].textContent[j + 1] !== '#' || isJumping && $boxML[si].textContent[j + 2] !== '#') {
						$box[3].style.visibility = '';	//	Восток
					}
				}
			}
			//	Ищем указатели
			for (var sj = 0; sj < kColumn; sj++) {
				var ij, ttl = '',
					pointer = $boxML[si].textContent[sj],
					chronopointers = chronolen > 1 ? this.chronicles[chronolen].pointers : [];
				/* [E] check if current position has some directions in chronicle */
				if (pointer === '@' && chronopointers.length) {
					for (i = 0, len = chronopointers.length; i < len; i++) {
						switch (chronopointers[i]) {
							case 'north_east': ttl += '↗'; break;
							case 'north_west': ttl += '↖'; break;
							case 'south_east': ttl += '↘'; break;
							case 'south_west': ttl += '↙'; break;
							case 'north':      ttl += '↑'; break;
							case 'east':       ttl += '→'; break;
							case 'south':      ttl += '↓'; break;
							case 'west':       ttl += '←'; break;
							case 'freezing': ttl += '✵'; break;
							case 'cold':     ttl += '❄'; break;
							case 'mild':     ttl += '☁'; break;
							case 'warm':     ttl += '♨'; break;
							case 'hot':      ttl += '☀'; break;
							case 'burning':  ttl += '✺'; break;
						}
					}
					console.log("current position has pointers: "+ttl);
				}
				if ('←→↓↑↙↘↖↗⌊⌋⌈⌉∨<∧>'.indexOf(pointer) !== -1 || ttl.length && ttl.match('←|→|↓|↑|↙|↘|↖|↗')) {
					MaxMap++;
					$boxMC[si * kColumn + sj].style.color = 'green';
					/* [E] get directions from the arrows themselves, not relying on parsed chronicles */
					if (!ttl.length) {
						switch (pointer) {
							case '⌊': ttl = '↑→'; break;
							case '⌋': ttl = '↑←'; break;
							case '⌈': ttl = '↓→'; break;
							case '⌉': ttl = '↓←'; break;
							case '∨': ttl = '↖↗'; break;
							case '<': ttl = '↗↘'; break;
							case '∧': ttl = '↙↘'; break;
							case '>': ttl = '↖↙'; break;
							default: ttl = pointer; break;
						}
					}
					for (ij = 0, len = ttl.length; ij < len; ij++){
						if ('→←↓↑↘↙↖↗'.indexOf(ttl[ij]) !== - 1){
							for (ik = 0; ik < kRow; ik++) {
								for (jk = 0; jk < kColumn; jk++) {
									var istep = parseInt((Math.abs(jk - sj) - 1) / 5),
										jstep = parseInt((Math.abs(ik - si) - 1) / 5);
									if ('←→'.indexOf(ttl[ij]) !== -1 && ik >= si - istep && ik <= si + istep ||
										ttl[ij] === '↓' && ik >= si + istep ||
										ttl[ij] === '↑' && ik <= si - istep ||
										'↙↘'.indexOf(ttl[ij]) !== -1 && ik > si + istep ||
										'↖↗'.indexOf(ttl[ij]) !== -1 && ik < si - istep) {
										if (ttl[ij] === '→' && jk >= sj + jstep ||
											ttl[ij] === '←' && jk <= sj - jstep ||
											'↓↑'.indexOf(ttl[ij]) !== -1 && jk >= sj - jstep && jk <= sj + jstep ||
											'↘↗'.indexOf(ttl[ij]) !== -1 && jk > sj + jstep ||
											'↙↖'.indexOf(ttl[ij]) !== -1 && jk < sj - jstep) {
											if (MapArray[ik][jk] >= 0) {
												MapArray[ik][jk]+=1024;
											}
										}
									}
								}
							}
						}
					}
				}
				if ('✺☀♨☁❄✵'.indexOf(pointer) !== -1 || ttl.length && '✺☀♨☁❄✵'.indexOf(ttl) !== -1) {
					MaxMapThermo++;
					$boxMC[si * kColumn + sj].style.color = 'green';
					/* [E] if we're standing on the pointer - use parsed value from chronicle */
					if (ttl.length) {
						pointer = ttl;
					}
					var ThermoMinStep = 0;	//	Минимальное количество шагов до клада
					var ThermoMaxStep = 0;	//	Максимальное количество шагов до клада
					switch(pointer) {
						case '✺': ThermoMinStep = 1; ThermoMaxStep = 2; break;	//	✺ - очень горячо(1-2)
						case '☀': ThermoMinStep = 3; ThermoMaxStep = 5; break;	//	☀ - горячо(3-5)
						case '♨': ThermoMinStep = 6; ThermoMaxStep = 9; break;	//	♨ - тепло(6-9)
						case '☁': ThermoMinStep = 10; ThermoMaxStep = 13; break;	//	☁ - свежо(10-13)
						case '❄': ThermoMinStep = 14; ThermoMaxStep = 18; break;	//	❄ - холодно(14-18)
						case '✵': ThermoMinStep = 19; ThermoMaxStep = 100; break;	//	✵ - очень холодно(19)
					}
					//	thermo map data
					var MapData = {
						kColumn: kColumn,
						kRow: kRow,
						minStep: ThermoMinStep,
						maxStep: ThermoMaxStep,
						scanList: []
					};
					for (ik = -1; ik <= kRow; ik++) {
						for (jk = -1; jk <= kColumn; jk++) {
							if (ik < 0 || jk < 0 || ik === kRow || jk === kColumn) {
								MapData[ik+':'+jk] = { explored: false, specway: false, scanned: false, wall: false, unknown: true };
								continue;
							}
							MapData[ik+':'+jk] = {
								explored: '#?!'.indexOf($boxML[ik].textContent[jk]) === -1,
								specway: false,
								scanned: false,
								wall: $boxML[ik].textContent[jk] === '#',
								unknown: $boxML[ik].textContent[jk] === '?'
							};
						}
					}
					// remove unknown marks from cells located near explored ones
					for (ik = 0; ik < kRow; ik++) {
						for (jk = 0; jk < kColumn; jk++) {
							if (MapData[ik+':'+jk].explored) {
								for (i = -1; i <= 1; i++) {
									for (j = -1; j <= 1; j++) {
										if (MapData[(ik+i)+':'+(jk+j)]) { MapData[(ik+i)+':'+(jk+j)].unknown = false; }
									}
								}
							}
						}
					}
					//
					GUIp.mapIteration(MapData, si, sj, 0, false);
					//
					for (ik = 0; ik < kRow; ik++) {
						for (jk = 0; jk < kColumn; jk++) {
							if (MapData[ik+':'+jk].step < ThermoMinStep && MapData[ik+':'+jk].explored && !MapData[ik+':'+jk].specway) {
								MapData[ik+':'+jk].scanned = true;
								MapData.scanList.push({i:ik, j:jk, lim:(ThermoMinStep - MapData[ik+':'+jk].step)});
							}
						}
					}
					while (MapData.scanList.length) {
						var scanCell = MapData.scanList.shift();
						for (var cell in MapData) {
							if (MapData[cell].substep) {
								MapData[cell].substep = 0;
							}
						}
						GUIp.mapSubIteration(MapData, scanCell.i, scanCell.j, 0, scanCell.lim, false);
					}
					//
					for (ik = ((si - ThermoMaxStep) > 0 ? si - ThermoMaxStep : 0); ik <= ((si + ThermoMaxStep) < kRow ? si + ThermoMaxStep : kRow - 1); ik++) {
						for (jk = ((sj - ThermoMaxStep) > 0 ? sj - ThermoMaxStep : 0); jk <= ((sj + ThermoMaxStep) < kColumn ? sj + ThermoMaxStep : kColumn - 1); jk++) {
							if (MapData[ik+':'+jk].step >= ThermoMinStep & MapData[ik+':'+jk].step <= ThermoMaxStep) {
								if (MapArray[ik][jk] >= 0) {
									MapArray[ik][jk]+=128;
								}
							} else if (MapData[ik+':'+jk].step < ThermoMinStep && MapData[ik+':'+jk].specway) {
								if (MapArray[ik][jk] >= 0) {
									MapArray[ik][jk]++;
								}
							}
						}
					}
				}
			}
		}
		//	Отрисовываем возможный клад
		if (MaxMap !== 0 || MaxMapThermo !== 0) {
			for (i = 0; i < kRow; i++) {
				for (j = 0; j < kColumn; j++) {
					if (MapArray[i][j] === 1024*MaxMap + 128*MaxMapThermo) {
						$boxMC[i * kColumn + j].style.color = ($boxML[i].textContent[j] === '@') ? 'blue' : 'red';
					} else {
						for (ik = 0; ik < MaxMapThermo; ik++) {
							if (MapArray[i][j] === 1024*MaxMap + 128*ik + (MaxMapThermo - ik)) {
								$boxMC[i * kColumn + j].style.color = ($boxML[i].textContent[j] === '@') ? 'blue' : 'darkorange';
							}
						}
					}
				}
			}
		}
	}
};
GUIp.improver.improveOppsHP = function(isAlly) {
	var color, opp, opp_type = isAlly ? 'alls' : 'opps';
	for (var number in so.state[opp_type]) {
		opp = so.state[opp_type][number];
		if (opp.hp < 1 || (isAlly && opp.hp === 1)) {
			color = 'darkgray';
		} else if (opp.hp < opp.hpm * 0.30) {
			color = 'rgb(235,0,0)';
		} else {
			color = '';
		}
		if (opp.li.opp_hp && opp.li.opp_hp[0]) {
			opp.li.opp_hp[0].style.color = color;
		}
	}
};
GUIp.improver.improveStats = function() {
	//	Парсер строки с золотом
	var i;
	var gold_parser = function(val) {
		return parseInt(val.replace(/[^0-9]/g, '')) || 0;
	};

	if (GUIp.data.isDungeon) {
		if (GUIp.storage.get('Logger:Location') === 'Field') {
			GUIp.storage.set('Logger:Location', 'Dungeon');
			GUIp.storage.set('Logger:Map_HP', GUIp.stats.HP());
			GUIp.storage.set('Logger:Map_Exp', GUIp.stats.Exp());
			GUIp.storage.set('Logger:Map_Gold', GUIp.stats.Gold());
			GUIp.storage.set('Logger:Map_Inv', GUIp.stats.Inv());
			GUIp.storage.set('Logger:Map_Charges',GUIp.stats.Charges());
			GUIp.storage.set('Logger:Map_Alls_HP', GUIp.stats.Map_Alls_HP());
			for (i = 1; i <= 4; i++) {
				GUIp.storage.set('Logger:Map_Ally'+i+'_HP', GUIp.stats.Map_Ally_HP(i));
			}
		}
		/* [E] informer to notify about low health when in dungeon mode */
		GUIp.informer.update('low health', GUIp.stats.Map_HP() < 130 && GUIp.stats.Map_HP() > 1);
		GUIp.improver.improveOppsHP(true);
		return;
	}
	if (GUIp.data.isFight) {
		if (this.isFirstTime) {
			GUIp.storage.set('Logger:Hero_HP', GUIp.stats.HP());
			GUIp.storage.set('Logger:Hero_Gold', GUIp.stats.Gold());
			GUIp.storage.set('Logger:Hero_Inv', GUIp.stats.Inv());
			GUIp.storage.set('Logger:Hero_Charges', GUIp.stats.Charges());
			GUIp.storage.set('Logger:Enemy_HP', GUIp.stats.Enemy_HP());
			GUIp.storage.set('Logger:Enemy_Gold', GUIp.stats.Enemy_Gold());
			GUIp.storage.set('Logger:Enemy_Inv', GUIp.stats.Enemy_Inv());
			GUIp.storage.set('Logger:Hero_Alls_HP', GUIp.stats.Hero_Alls_HP());
			for (i = 1; i <= 4; i++) {
				GUIp.storage.set('Logger:Hero_Ally'+i+'_HP', GUIp.stats.Hero_Ally_HP(i));
			}
			for (i = 1; i <= 5; i++) {
				GUIp.storage.set('Logger:Enemy'+i+'_HP', GUIp.stats.EnemySingle_HP(i));
			}
			GUIp.storage.set('Logger:Enemy_AliveCount', GUIp.stats.Enemy_AliveCount());
		}
		/* [E] informer to notify about low health when in fight mode */
		var health_lim;
		if (GUIp.stats.Hero_Alls_Count() === 0 && GUIp.stats.Enemy_Count() > 2) { // corovan
			health_lim = GUIp.stats.Max_HP() * 0.05 * GUIp.stats.Enemy_AliveCount();
		} else if (GUIp.stats.Hero_Alls_Count() === 0) { // single enemy
			health_lim = GUIp.stats.Max_HP() * 0.15;
		} else { // raid boss or dungeon boss
			health_lim = (GUIp.stats.Hero_Alls_MaxHP() + GUIp.stats.Max_HP()) * (GUIp.stats.Enemy_HasAbility("second_strike") ? 0.094 : 0.068);
			if (GUIp.stats.Enemy_AliveCount() > 1) { // boss has an active minion
				health_lim *= 1.3;
			}
			if (GUIp.stats.Hero_Alls_Count() < 4) { // allies count less than 4 -- clearly speculative calculation below!
				health_lim *= (4 - GUIp.stats.Hero_Alls_Count()) * 0.2 + 1;
			}
		}
		GUIp.informer.update('low health', GUIp.stats.HP() < health_lim && GUIp.stats.HP() > 1);
		GUIp.improver.improveOppsHP(true);
		GUIp.improver.improveOppsHP(false);
		return;
	}
	if (GUIp.storage.get('Logger:Location') !== 'Field') {
		GUIp.storage.set('Logger:Location', 'Field');
	}
	if (!GUIp.utils.isAlreadyImproved(document.getElementById('stats'))) {
		// Add voicegens
		GUIp.utils.addVoicegen(document.querySelector('#hk_level .l_capt'), GUIp.i18n.study, 'exp', GUIp.i18n.ask9 + GUIp.data.char_sex[1] + GUIp.i18n.to_study);
		GUIp.utils.addVoicegen(document.querySelector('#hk_health .l_capt'), GUIp.i18n.heal, 'heal', GUIp.i18n.ask6 + GUIp.data.char_sex[1] + GUIp.i18n.to_heal);
		GUIp.utils.addVoicegen(document.querySelector('#hk_gold_we .l_capt'), GUIp.i18n.dig, 'dig', GUIp.i18n.ask10 + GUIp.data.char_sex[1] + GUIp.i18n.to_dig);
		GUIp.utils.addVoicegen(document.querySelector('#hk_quests_completed .l_capt'), GUIp.i18n.cancel_task, 'cancel_task', GUIp.i18n.ask11 + GUIp.data.char_sex[0] + GUIp.i18n.to_cancel_task);
		GUIp.utils.addVoicegen(document.querySelector('#hk_quests_completed .l_capt'), GUIp.i18n.do_task, 'do_task', GUIp.i18n.ask12 + GUIp.data.char_sex[1] + GUIp.i18n.to_do_task);
		GUIp.utils.addVoicegen(document.querySelector('#hk_death_count .l_capt'), GUIp.i18n.die, 'die', GUIp.i18n.ask13 + GUIp.data.char_sex[0] + GUIp.i18n.to_die);
	}
	if (!document.querySelector('#hk_distance .voice_generator')) {
		GUIp.utils.addVoicegen(document.querySelector('#hk_distance .l_capt'), document.querySelector('#main_wrapper.page_wrapper_5c') ? '回' : GUIp.i18n.return, 'town', GUIp.i18n.ask14 + GUIp.data.char_sex[0] + GUIp.i18n.to_return);
	}

	GUIp.informer.update('much gold', GUIp.stats.Gold() >= (GUIp.data.hasTemple ? 10000 : 3000));
	GUIp.informer.update('dead', GUIp.stats.HP() === 0);
	var questName = GUIp.stats.Task_Name();
	GUIp.informer.update('guild quest', questName.match(/членом гильдии|member of the guild/) && !questName.match(/\((отменено|cancelled)\)/));
	GUIp.informer.update('mini quest', questName.match(/\((мини|mini)\)/) && !questName.match(/\((отменено|cancelled)\)/));

	//Shovel pictogramm start
	var digVoice = document.querySelector('#hk_gold_we .voice_generator');
	if (this.isFirstTime) {
		digVoice.style.backgroundImage = 'url(' + GUIp.getResource('images/shovel.png') + ')';
	}
	if (GUIp.stats.goldTextLength() > 16 - 2*document.getElementsByClassName('page_wrapper_5c').length) {
		digVoice.classList.add('shovel');
		if (GUIp.stats.goldTextLength() > 20 - 3*document.getElementsByClassName('page_wrapper_5c').length) {
			digVoice.classList.add('compact');
		} else {
			digVoice.classList.remove('compact');
		}
	} else {
		digVoice.classList.remove('shovel');
	}
	//Shovel pictogramm end
};
GUIp.improver.improvePet = function() {
	if (GUIp.data.isFight) {
		return;
	}
	var pet_badge;
	if (GUIp.stats.petIsKnockedOut()) {
		if (!GUIp.utils.isAlreadyImproved(document.getElementById('pet'))) {
			document.querySelector('#pet .block_title').insertAdjacentHTML('beforeend', '<div id="pet_badge" class="fr_new_badge equip_badge_pos hidden">0</div>');
		}
		pet_badge = document.getElementById('pet_badge');
		pet_badge.textContent = GUIp.utils.findLabel($('#pet'), GUIp.i18n.pet_status_label).siblings('.l_val').text().replace(/[^0-9:]/g, '');
		GUIp.utils.hideElem(pet_badge, document.querySelector('#pet .block_content').style.display !== 'none');
	} else {
		pet_badge = document.getElementById('pet_badge');
		if (pet_badge) {
			GUIp.utils.hideElem(pet_badge, true);
		}
	}
	// knock out informer
	GUIp.informer.update('pet knocked out', GUIp.stats.petIsKnockedOut());
};
GUIp.improver.improveEquip = function() {
	if (!GUIp.utils.isAlreadyImproved(document.getElementById('equipment'))) {
		document.querySelector('#equipment .block_title').insertAdjacentHTML('afterend', '<div id="equip_badge" class="fr_new_badge equip_badge_pos">0</div>');
	}
	var equipBadge = document.getElementById('equip_badge'),
		averageEquipLevel = 0;
	for (var i = 1; i <= 7; i++) {
		averageEquipLevel += GUIp.stats['Equip' + i]();
	}
	averageEquipLevel = (averageEquipLevel/7).toFixed(1) + '';
	if (equipBadge.textContent !== averageEquipLevel) {
		equipBadge.textContent = averageEquipLevel;
	}
};
GUIp.improver.improvePantheons = function() {
	var pants = document.querySelector('#pantheons .block_content');
	if (this.isFirstTime) {
		pants.insertAdjacentHTML('afterbegin', '<div class="guip p_group_sep" />');
	}
	if (this.isFirstTime || this.optionsChanged) {
		var relocateDuelButtons = GUIp.storage.get('Option:relocateDuelButtons') || '';
		var arenaRelocated = relocateDuelButtons.match('arena'),
			arenaInPantheons = document.querySelector('#pantheons .arena_link_wrap');
		if (arenaRelocated && !arenaInPantheons) {
			pants.insertBefore(document.getElementsByClassName('arena_link_wrap')[0], pants.firstChild);
		} else if (!arenaRelocated && arenaInPantheons) {
			document.getElementById('cntrl2').insertBefore(arenaInPantheons, document.querySelector('#control .arena_msg'));
		}
		var chfRelocated = relocateDuelButtons.match('chf'),
			chfInPantheons = document.querySelector('#pantheons .chf_link_wrap');
		if (chfRelocated && !chfInPantheons) {
			pants.insertBefore(document.getElementsByClassName('chf_link_wrap')[0], document.getElementsByClassName('guip p_group_sep')[0]);
		} else if (!chfRelocated && chfInPantheons) {
			document.getElementById('cntrl2').insertBefore(chfInPantheons, document.querySelector('#control .arena_msg').nextSibling);
		}
	}
};
GUIp.improver.improveDiary = function() {
	var i, len;
	if (GUIp.improver.isFirstTime) {
		var $msgs = document.querySelectorAll('#diary .d_msg:not(.parsed)');
		for (i = 0, len = $msgs.length; i < len; i++) {
			$msgs[i].classList.add('parsed');
		}
	} else {
		var newMessages = $('#diary .d_msg:not(.parsed)');
		if (newMessages.length) {
			if (GUIp.improver.voiceSubmitted) {
				if (newMessages.length - document.querySelectorAll('#diary .d_msg:not(.parsed) .vote_links_b').length >= 2) {
					GUIp.timeout.start();
				}
				GUIp.improver.voiceSubmitted = false;
			}
			newMessages.addClass('parsed');
		}
	}
	GUIp.improver.improvementDebounce();
};
GUIp.improver.parseDungeonPhrases = function(xhr) {
	for (var i = 0, temp, len = this.dungeonPhrases.length; i < len; i++) {
		temp = xhr.responseText.match(new RegExp('<p>' + this.dungeonPhrases[i] + '\\b([\\s\\S]+?)<\/p>'))[1].replace(/&#8230;/g, '...').replace(/^<br>\n|<br>$/g, '').replace(/<br>\n/g, '|');
		this[this.dungeonPhrases[i] + 'RegExp'] = new RegExp(temp);
		GUIp.storage.set('Dungeon:' + this.dungeonPhrases[i] + 'Phrases', temp);
	}
	GUIp.improver.improveChronicles();
};
GUIp.improver.getDungeonPhrases = function() {
	if (!GUIp.storage.get('Dungeon:pointerMarkerPhrases')) {
		this.dungeonXHRCount++;
		var customChronicler = GUIp.storage.get('Option:customDungeonChronicler') || '';
		GUIp.utils.getXHR({
			url: '/gods/' + (customChronicler.length >= 3 ? customChronicler : 'Dungeoneer'),
			onSuccess: GUIp.improver.parseDungeonPhrases.bind(GUIp.improver)
		});
	} else {
		for (var i = 0, temp, len = this.dungeonPhrases.length; i < len; i++) {
			this[this.dungeonPhrases[i] + 'RegExp'] = new RegExp(GUIp.storage.get('Dungeon:' + this.dungeonPhrases[i] + 'Phrases'));
		}
		GUIp.improver.improveChronicles();
	}
};
GUIp.improver.parseSingleChronicle = function(texts, step) {
	if (!this.chronicles[step]) {
		this.chronicles[step] = { direction: null, marks: [], pointers: [], jumping: false, directionless: false, text: texts.join(' ') };
	}
	// First step isn't an actual "step".
	if (step === 1) {
		return;
	}
	var i, len, j, len2, chronicle = this.chronicles[step];
	for (j = 0, len2 = texts.length; j < len2; j++) {
		texts[j] = texts[j].replace(/offered to trust h.. gut feeling\./, '');
		for (i = 0, len = this.dungeonPhrases.length - 1; i < len; i++) {
			if (texts[j].match(this[this.dungeonPhrases[i] + 'RegExp']) && chronicle.marks.indexOf(this.dungeonPhrases[i]) === -1) {
				chronicle.marks.push(this.dungeonPhrases[i]);
			}
		}
		var firstSentence = texts[j].match(/^.*?[\.!\?](?:\s|$)/);
		if (firstSentence) {
			var direction = firstSentence[0].match(/[^\w\-А-Яа-я](север|восток|юг|запад|north|east|south|west)/);
			if (direction) {
				chronicle.direction = direction[1];
			}
			chronicle.directionless = chronicle.directionless || !!firstSentence[0].match(/went somewhere|too busy bickering to hear in which direction to go next|The obedient heroes move in the named direction/);
			chronicle.jumping = chronicle.jumping || !!firstSentence[0].match(this.jumpingDungeonRegExp);
		}
	}
	if (texts.join(' ').match(this.pointerMarkerRegExp)) {
		var middle = texts.join(' ').match(/^.+?\.(.+)[.!?].+?[.!?]$/)[1];
		var pointer, pointers = middle.match(this.pointerRegExp);
		for (i = 0, len = pointers.length; i < len; i++) {
			switch (pointers[i].replace(/^./, '')) {
			case 'северо-восток':
			case 'north-east': pointer = 'north_east'; break;
			case 'северо-запад':
			case 'north-west': pointer = 'north_west'; break;
			case 'юго-восток':
			case 'south-east': pointer = 'south_east'; break;
			case 'юго-запад':
			case 'south-west': pointer = 'south_west'; break;
			case 'север':
			case 'north': pointer = 'north'; break;
			case 'восток':
			case 'east': pointer = 'east'; break;
			case 'юг':
			case 'south': pointer = 'south'; break;
			case 'запад':
			case 'west': pointer = 'west'; break;
			case 'очень холодно':
			case 'very cold':
			case 'freezing': pointer = 'freezing'; break;
			case 'холодно':
			case 'cold': pointer = 'cold'; break;
			case 'свежо':
			case 'mild': pointer = 'mild'; break;
			case 'тепло':
			case 'warm': pointer = 'warm'; break;
			case 'горячо':
			case 'hot': pointer = 'hot'; break;
			case 'очень горячо':
			case 'very hot':
			case 'burning': pointer = 'burning'; break;
			}
			if (chronicle.pointers.indexOf(pointer) === -1) {
				chronicle.pointers.push(pointer);
			}
		}
	}
};
GUIp.improver.parseChronicles = function(xhr) {
	this.needLog = false;
	this.dungeonXHRCount++;

	if (Object.keys(this.chronicles)[0] === '1') {
		return;
	}

	var lastNotParsed, texts = [],
		step = 1,
		step_max = +Object.keys(this.chronicles)[0],
		matches = xhr.responseText.match(/<div class="new_line ?" style='[^']*'>[\s\S]*?<div class="text_content .*?">[\s\S]+?<\/div>/g);
	for (var i = 0; step <= step_max; i++) {
		lastNotParsed = true;
		if (!matches[i].match(/<div class="text_content infl">/)) {
			texts.push(matches[i].match(/<div class="text_content ">([\s\S]+?)<\/div>/)[1].trim().replace(/&#39;/g, "'"));
		}
		if (matches[i].match(/<div class="new_line ?" style='[^']+'>/)) {
			GUIp.improver.parseSingleChronicle(texts, step);
			lastNotParsed = false;
			texts = [];
			step++;
		}
	}
	if (lastNotParsed) {
		GUIp.improver.parseSingleChronicle(texts, step);
	}

	console.log('after log chronicles');
	console.log(this.chronicles);
	console.log(JSON.stringify(this.chronicles));

	GUIp.improver.colorDungeonMap();
};
GUIp.improver.calculateXY = function(cell) {
	var coords = {};
	coords.x = GUIp.utils.getNodeIndex(cell);
	coords.y = GUIp.utils.getNodeIndex(cell.parentNode);
	return coords;
};
GUIp.improver.calculateExitXY = function() {
	var exit_coords = { x: null, y: null },
		cells = document.querySelectorAll('.dml .dmc');
	for (var i = 0, len = cells.length; i < len; i++) {
		if (cells[i].textContent.trim().match(/В|E/)) {
			exit_coords = GUIp.improver.calculateXY(cells[i]);
			break;
		}
	}
	if (!exit_coords.x) {
		exit_coords = GUIp.improver.calculateXY(document.getElementsByClassName('map_pos')[0]);
	}
	return exit_coords;
};
GUIp.improver.deleteInvalidChronicles = function() {
	var isHiddenChronicles = true,
		chronicles = document.querySelectorAll('#m_fight_log .line.d_line');
	for (var i = chronicles.length - 1; i >= 0; i--) {
		if (isHiddenChronicles) {
			if (chronicles[i].style.display !== 'none') {
				isHiddenChronicles = false;
			}
		} else {
			if (chronicles[i].style.display === 'none') {
				chronicles[i].parentNode.removeChild(chronicles[i]);
			}
		}
	}
};
GUIp.improver.improveChronicles = function() {
	if (!GUIp.storage.get('Dungeon:pointerMarkerPhrases')) {
		if (this.dungeonXHRCount < 5) {
			GUIp.improver.getDungeonPhrases();
		}
	} else {
		var numberInBlockTitle = document.querySelector('#m_fight_log .block_title').textContent.match(/\d+/);
		if (!numberInBlockTitle) {
			return;
		}
		GUIp.improver.deleteInvalidChronicles();
		var i, len, lastNotParsed, texts = [],
			chronicles = document.querySelectorAll('#m_fight_log .d_msg:not(.parsed)'),
			ch_down = document.querySelector('.sort_ch').textContent === '▼',
			step = +numberInBlockTitle[0];
		console.log('new ', chronicles.length, ' chronicles from step #', step);
		for (len = chronicles.length, i = ch_down ? 0 : len - 1; (ch_down ? i < len : i >= 0) && step; ch_down ? i++ : i--) {
			lastNotParsed = true;
			if (!chronicles[i].className.match('m_infl')) {
				texts = [chronicles[i].textContent].concat(texts);
			}
			if (chronicles[i].parentNode.className.match('turn_separator')) {
				GUIp.improver.parseSingleChronicle(texts, step);
				console.log('chronicle #', step);
				console.log(chronicles[i].textContent);
				lastNotParsed = false;
				texts = [];
				step--;
			}
			if (chronicles[i].textContent.match(this.bossHintRegExp)) {
				chronicles[i].parentNode.classList.add('bossHint');
			}
			chronicles[i].classList.add('parsed');
		}
		if (lastNotParsed) {
			GUIp.improver.parseSingleChronicle(texts, step);
		}
		console.log('last step #', step);

		if (!this.initial) {
			this.initial = true;
			console.log('initial chronicles');
			console.log(this.chronicles);
			console.log(JSON.stringify(this.chronicles));
		}

		if (this.needLog) {
			if (Object.keys(this.chronicles)[0] === '1') {
				this.needLog = false;
				GUIp.improver.colorDungeonMap();
			} else if (this.dungeonXHRCount < 5) {
				GUIp.utils.getXHR({
					url: '/duels/log/' + GUIp.stats.logId(),
					onSuccess: GUIp.improver.parseChronicles.bind(GUIp.improver)
				});
			}
		}
		// informer
		GUIp.informer.update('close to boss', this.chronicles[Object.keys(this.chronicles).reverse()[0]].marks.indexOf('bossHint') !== -1);

		if (GUIp.storage.get('Log:current') !== GUIp.stats.logId()) {
			GUIp.storage.set('Log:current', GUIp.stats.logId());
			GUIp.storage.set('Log:' + GUIp.stats.logId() + ':corrections', '');
		}
		GUIp.storage.set('Log:' + GUIp.stats.logId() + ':steps', (document.querySelector('#m_fight_log .block_title').textContent.match(/\d+/) || [0])[0]);
		GUIp.storage.set('Log:' + GUIp.stats.logId() + ':map', JSON.stringify(so.state.d_map));
	}
	GUIp.improver.improvementDebounce();
};
GUIp.improver.moveCoords = function(coords, chronicle) {
	if (chronicle.direction) {
		var step = chronicle.jumping ? 2 : 1;
		switch(chronicle.direction) {
		case 'север':
		case 'north': coords.y -= step; break;
		case 'восток':
		case 'east': coords.x += step; break;
		case 'юг':
		case 'south': coords.y += step; break;
		case 'запад':
		case 'west': coords.x -= step; break;
		}
	}
};

GUIp.improver.getRPerms = function(array, size, initialStuff, output) {
	if (initialStuff.length >= size) {
		output.push(initialStuff);
	} else {
		for (var i = 0; i < array.length; ++i) {
			this.getRPerms(array, size, initialStuff.concat(array[i]), output);
		}
	}
};

GUIp.improver.getAllRPerms = function(array, size) {
	var output = [];
	this.getRPerms(array, size, [], output);
	return output;
};

GUIp.improver.calculateDirectionlessMove = function(initCoords, initStep) {
	var i, len, j, len2, coords = { x: initCoords.x, y: initCoords.y },
		dmap = document.querySelectorAll('#map .dml'),
		heroesCoords = GUIp.improver.calculateXY(document.getElementsByClassName('map_pos')[0]),
		steps = Object.keys(this.chronicles),
		directionless = 0;

	console.log('going to calculate directionless move from step #'+initStep);
	for (i = initStep, len = steps.length; i <= len; i++) {
		if (this.chronicles[i].directionless) {
			directionless++;
		}
		GUIp.improver.moveCoords(coords, this.chronicles[i]);
	}

	var variations = this.getAllRPerms('nesw'.split(''),directionless);

	for (i = 0, len = variations.length; i < len; i++) {
		//console.log('trying combo '+variations[i].join());
		coords = { x: initCoords.x, y: initCoords.y };
		directionless = 0;
		for (j = initStep, len2 = steps.length; j <= len2; j++) {
			if (this.chronicles[j].directionless) {
				GUIp.improver.moveCoords(coords, { direction: this.corrections[variations[i][directionless]] });
				directionless++;
			} else {
				GUIp.improver.moveCoords(coords, this.chronicles[j]);
			}
			if (!dmap[coords.y] || !dmap[coords.y].children[coords.x] || dmap[coords.y].children[coords.x].textContent.match(/#|!|\?/)) {
				break;
			}
		}
		if (heroesCoords.x - coords.x === 0 && heroesCoords.y - coords.y === 0) {
			var currentCorrections = GUIp.storage.get('Log:' + GUIp.stats.logId() + ':corrections') || '';
			console.log('found result: '+variations[i].join());
			GUIp.storage.set('Log:' + GUIp.stats.logId() + ':corrections', currentCorrections + variations[i].join(''));
			return this.corrections[variations[i][0]];
		}
	}
};
GUIp.improver.colorDungeonMap = function() {
	if (GUIp.improver.colorDungeonMapTimer) {
		clearTimeout(GUIp.improver.colorDungeonMapTimer);
	}
	GUIp.improver.colorDungeonMapTimer = setTimeout(function() { GUIp.improver.colorDungeonMapInternal(); }, 150);
};
GUIp.improver.colorDungeonMapTimer = null;
GUIp.improver.colorDungeonMapInternal = function() {
	if (!GUIp.data.isDungeon) {
		return;
	}
	GUIp.improver.improveMap();
	var step, mark_no, marks_length, steptext, lasttext, titlemod, titletext, currentCell,
		trapMoveLossCount = 0,
		coords = GUIp.improver.calculateExitXY(),
		steps = Object.keys(this.chronicles),
		steps_max = steps.length;
	for (step = 1; step <= steps_max; step++) {
		if (this.chronicles[step].directionless) {
			var shortCorrection = GUIp.storage.get('Log:' + GUIp.stats.logId() + ':corrections')[this.directionlessMoveIndex++];
			if (shortCorrection) {
				this.chronicles[step].direction = this.corrections[shortCorrection];
			} else {
				this.chronicles[step].direction = GUIp.improver.calculateDirectionlessMove(coords, step);
			}
			this.chronicles[step].directionless = false;
		}
		GUIp.improver.moveCoords(coords, this.chronicles[step]);
		currentCell = document.querySelectorAll('#map .dml')[coords.y].children[coords.x];
		for (mark_no = 0, marks_length = this.chronicles[step].marks.length; mark_no < marks_length; mark_no++) {
			currentCell.classList.add(this.chronicles[step].marks[mark_no]);
		}
		if (!currentCell.title.length && this.chronicles[step].pointers.length) {
			currentCell.title = '[' + GUIp.i18n.map_pointer + ': ' + GUIp.i18n[this.chronicles[step].pointers[0]] + (this.chronicles[step].pointers[1] ? GUIp.i18n.or + GUIp.i18n[this.chronicles[step].pointers[1]] : '') + ']';
		}
		//currentCell.title += (currentCell.title.length ? '\n\n' : '') + '#' + step + ' : ' + this.chronicles[step].text;
		steptext = this.chronicles[step].text.replace('.»','».').replace(/(\!»|\?»)/g,'$1.'); // we're not going to do natural language processing, so just simplify nested sentence (yeah, result will be a bit incorrect)
		steptext = steptext.match(/[^\.]+[\.]+/g);
		if (step === 1) {
			steptext = steptext.slice(0,-1);
		} else if (step === steps_max) {
			steptext = steptext.slice(1);
		} else if (this.chronicles[step].marks.indexOf('boss') !== -1) {
			steptext = steptext.slice(1,-2);
		} else if (this.chronicles[step].marks.indexOf('trapMoveLoss') !== -1 || trapMoveLossCount) {
			if (!trapMoveLossCount) {
				steptext = steptext.slice(1);
				trapMoveLossCount++;
			} else {
				steptext = steptext.slice(0,-1);
				trapMoveLossCount = 0;
			}
		} else {
			steptext = steptext.length > 2 ? steptext.slice(1,-1) : steptext.slice(0,-1);
		}
		steptext = steptext.join('').trim();
		if (currentCell.title.length) {
			titlemod = false;
			titletext = currentCell.title.split('\n');
			for (var i = 0, len = titletext.length; i < len; i++) {
				lasttext = titletext[i].match(/^(.*?) : (.*?)$/);
				if (lasttext && lasttext[2] === steptext) {
					titletext[i] = lasttext[1] + ', #' + step + ' : ' + steptext;
					titlemod = true;
					break;
				}
			}
			if (!titlemod) {
				titletext.push('#' + step + ' : ' + steptext);
			}
			currentCell.title = titletext.join('\n');
		} else {
			currentCell.title = '#' + step + ' : ' + steptext;
		}
	}
	var heroesCoords = GUIp.improver.calculateXY(document.getElementsByClassName('map_pos')[0]);
	if (heroesCoords.x !== coords.x || heroesCoords.y !== coords.y) {
		console.log('current chronicles');
		console.log(this.chronicles);
		console.log(JSON.stringify(this.chronicles));
		console.log('m_fight_log');
		console.log(document.getElementById('m_fight_log').innerHTML);
		if (GUIp.utils.hasShownInfoMessage !== true) {
			GUIp.utils.showMessage('info', {
				title: GUIp.i18n.coords_error_title,
				content: '<div>' + GUIp.i18n.coords_error_desc + ': [x:' + (heroesCoords.x - coords.x) + ', y:' + (heroesCoords.y - coords.y) + '].</div>'
			});
			GUIp.utils.hasShownInfoMessage = true;
		}
	}
};
GUIp.improver.whenWindowResize = function() {
	GUIp.improver.chatsFix();
	//body widening
	$('body').width($(window).width() < $('#main_wrapper').width() ? $('#main_wrapper').width() : '');
};
GUIp.improver._clockToggle = function(e) {
	if (e) {
		e.stopPropagation();
	}
	if (!GUIp.improver.clockToggling) {
		GUIp.improver.clockToggling = true;
	} else {
		return;
	}
	var restoreText, clockElem = $('#control .block_title');
	if (GUIp.improver.clock) {
		clearInterval(GUIp.improver.clock.updateTimer);
		restoreText = GUIp.improver.clock.prevText;
		clockElem.fadeOut(500, function() {
			clockElem.css('color', '');
			clockElem.text(restoreText).fadeIn(500);
			clockElem.prop('title', GUIp.i18n.show_godville_clock);
			GUIp.improver.clockToggling = false;
		});
		delete GUIp.improver.clock;
	} else {
		GUIp.improver.clock = {};
		GUIp.improver.clock.prevText = clockElem.text();
		GUIp.improver.clock.blocked = true;
		clockElem.fadeOut(500, function() {
			clockElem.text('--:--:--').fadeIn(500);
			clockElem.prop('title', GUIp.i18n.hide_godville_clock);
			GUIp.improver.clock.timeBegin = new Date();
			GUIp.utils.getXHR({
				url: '//time.akamai.com/?iso',
				onSuccess: GUIp.improver._clockSync,
				onFail: function() {
					GUIp.improver.clockToggling = false;
					GUIp.improver._clockToggle();
				}
			});
		});
	}
};
GUIp.improver._clockSync = function(xhr) {
	GUIp.improver.clockToggling = false;
	var currentTime = new Date(),
		offsetHours = GUIp.storage.get("Option:offsetGodvilleClock") || 3,
		clockTitle = $('#control .block_title');
	if (currentTime - GUIp.improver.clock.timeBegin > 500) {
		clockTitle.css('color', '#CC0000');
	}
	if (!GUIp.improver.clock.useGVT) {
		GUIp.improver.clock.timeDiff = new Date(xhr.responseText) - currentTime + (GUIp.storage.get('Option:localtimeGodvilleClock') ? (currentTime.getTimezoneOffset() * -60000) : (offsetHours * 3600000));
	} else {
		GUIp.improver.clock.timeDiff = new Date(xhr.getResponseHeader("Date")) - currentTime + (GUIp.storage.get('Option:localtimeGodvilleClock') ? (currentTime.getTimezoneOffset() * -60000) : (offsetHours * 3600000));
	}
	GUIp.improver.clock.updateTimer = setInterval(function() { GUIp.improver._clockUpdate(); }, 250);
	GUIp.improver._clockUpdate();
};
GUIp.improver._clockUpdate = function() {
	var currentTime = new Date();
	if (currentTime.getTime() - GUIp.improver.clock.timeBegin.getTime() > (300 * 1000)) {
		GUIp.improver._clockToggle();
		return;
	}
	var clockElem = $('#control .block_title'),
		godvilleTime = new Date(currentTime.getTime() + GUIp.improver.clock.timeDiff);
	clockElem.text(GUIp.utils.formatClock(godvilleTime));
};

GUIp.improver.improveInterface = function() {
	if (this.isFirstTime) {
		$('a[href=#]').removeAttr('href');
		GUIp.improver.whenWindowResize();
		window.onresize = function() {
			clearInterval(GUIp.improver.windowResizeInt);
			GUIp.improver.windowResizeInt = setTimeout(function() { GUIp.improver.whenWindowResize(); }, 250);
		};
		if (GUIp.data.isFight && document.querySelector('#map .block_title, #control .block_title, #m_control .block_title')) {
			document.querySelector('#map .block_title, #control .block_title, #m_control .block_title').insertAdjacentHTML('beforeend', ' <a class="broadcast" href="/duels/log/' + GUIp.stats.logId() + '" target="_blank">' + GUIp.i18n.broadcast + '</a>');
		}
		/* [E] clock is to be initialized somewhere here */
		else if (!GUIp.storage.get('Option:disableGodvilleClock') && document.querySelector('#control .block_title')) {
			var controlTitle = document.querySelector('#control .block_title');
			controlTitle.title = GUIp.i18n.show_godville_clock;
			controlTitle.style.cursor = 'pointer';
			controlTitle.onclick = GUIp.improver._clockToggle.bind(null);
		}
	}
	if (this.isFirstTime || GUIp.storage.get('UserCssChanged') === true) {
		GUIp.storage.set('UserCssChanged', false);
		GUIp.addCSSFromString(GUIp.storage.get('UserCss'));
	}

	if (localStorage.getItem('ui_s') !== GUIp.storage.get('ui_s')) {
		GUIp.storage.set('ui_s', localStorage.getItem('ui_s') || 'th_classic');
		this.Shovel = false;
		document.body.className = document.body.className.replace(/th_\w+/g, '') + ' ' + GUIp.storage.get('ui_s');
	}

	if (this.isFirstTime || this.optionsChanged) {
		var background = GUIp.storage.get('Option:useBackground');
		if (background === 'cloud') {
			document.body.style.backgroundImage = 'url(' + GUIp.getResource('images/background.jpg') + ')';
		} else {
			document.body.style.backgroundImage = background ? 'url(' + background + ')' : '';
		}
	}
};
GUIp.improver.improveChat = function() {
	var i, len;

	// friends fetching
	var $friends = document.querySelectorAll('.frline .frname'),
		friends = [];
	for (i = 0, len = $friends.length; i < len; i++) {
		friends.push($friends[i].textContent);
	}
	this.friendsRegExp = new RegExp('^(?:' + friends.join('|') + ')$');

	// links replacing and open chat with friend button adding
	var text, $msgs = document.querySelectorAll('.fr_msg_l:not(.improved)');
	for (i = 0, len = $msgs.length; i < len; i++) {
		text = $msgs[i].childNodes[0].textContent;
		$msgs[i].removeChild($msgs[i].childNodes[0]);
		$msgs[i].insertAdjacentHTML('afterbegin', '<span>' + GUIp.utils.escapeHTML(text).replace(/(https?:\/\/[^ \n\t]*[^\?\!\.\n\t\, ]+)/g, '<a href="$1" target="_blank" title="' + GUIp.i18n.open_in_a_new_tab + '">$1</a>') + '</span>');

		var friend = $msgs[i].getElementsByClassName('gc_fr_god')[0];
		if (friend && friend.textContent.match(this.friendsRegExp)) {
			friend.insertAdjacentHTML('beforebegin', '<span class="gc_fr_oc gc_fr_page" title="' + GUIp.i18n.open_chat_with + friend.textContent + '">[✎]</span>');
			$msgs[i].getElementsByClassName('gc_fr_oc')[0].onclick = GUIp.utils.openChatWith.bind(null, friend.textContent);
		}

		$msgs[i].classList.add('improved');
	}

	// godnames in gc paste fix
	$('.gc_fr_god:not(.improved)').unbind('click').click(function() {
		var ta = this.parentNode.parentNode.parentNode.parentNode.parentNode.querySelector('textarea'),
			pos = ta.selectionDirection === 'backward' ? ta.selectionStart : ta.selectionEnd;
		ta.value = ta.value.slice(0, pos) + '@' + this.textContent + ', ' + ta.value.slice(pos);
		ta.focus();
		ta.selectionStart = ta.selectionEnd = pos + this.textContent.length + 3;
	}).addClass('improved');

	// "Shift+Enter → new line" improvement
	var keypresses, handlers,
	$tas = $('.frInputArea textarea:not(.improved)');
	if ($tas.length) {
		var new_keypress = function(handlers) {
			return function(e) {
				if (e.which === 13 && !e.shiftKey) {
					for (var i = 0, len = handlers.length; i < len; i++) {
						handlers[i](e);
					}
				}
			};
		};
		for (i = 0, len = $tas.length; i < len; i++) {
			keypresses = $._data($tas[i], 'events').keypress;
			handlers = [];
			for (var j = 0, klen = keypresses.length; j < klen; j++) {
				handlers.push(keypresses[j].handler);
			}
			$tas.eq(i).unbind('keypress').keypress(new_keypress(handlers));
		}
		$tas.addClass('improved');
		new_keypress = null;
	}
};
GUIp.improver.improveAllies = function() {
	var ally, opp_n, star, anspan;
	for (var number in so.state.alls) {
		ally = so.state.alls[number];
		opp_n = ally.li[0].getElementsByClassName('opp_n')[0];
		star = opp_n.getElementsByClassName('open_chat')[0] || document.createElement('a');
		if (!opp_n.classList.contains('improved')) {
			opp_n.classList.add('improved');
			anspan = document.createElement('span');
			anspan.textContent = ally.hero;
			anspan.title = ally.god;
			if (ally.clan === GUIp.stats.guildName()) {
				anspan.className = "guildsmanAlly";
			}
			opp_n.textContent = '';
			opp_n.insertBefore(anspan, null);
			opp_n.insertBefore(document.createTextNode(' '), null);
			opp_n.insertBefore(star, null);
			star.className = 'open_chat';
			star.title = GUIp.i18n.open_chat_with + ally.god;
			star.textContent = '★';
			star.onclick = GUIp.utils.openChatWith.bind(null, ally.god);
		}
		GUIp.utils.hideElem(star, !ally.god.match(this.friendsRegExp));
	}
};
GUIp.improver.calculateButtonsVisibility = function() {
	var i, len, baseCond = GUIp.stats.Godpower() >= 5 && !GUIp.storage.get('Option:disableVoiceGenerators'),
		isMonster = GUIp.stats.monsterName();
	if (!GUIp.data.isFight) {
		// pantheon links
		var pantLinks = document.querySelectorAll('#pantheons .arena_link_wrap, #pantheons .chf_link_wrap'),
			pantBefore = [], pantAfter = [];
		for (i = 0, len = pantLinks.length; i < len; i++) {
			pantBefore[i] = !pantLinks[i].classList.contains('hidden');
			pantAfter[i] = GUIp.stats.Godpower() >= 50;
		}
		GUIp.improver.setButtonsVisibility(pantLinks, pantBefore, pantAfter);
		// inspect buttons
		var inspBtns = document.getElementsByClassName('inspect_button'),
			inspBtnsBefore = [], inspBtnsAfter = [];
		for (i = 0, len = inspBtns.length; i < len; i++) {
			inspBtnsBefore[i] = !inspBtns[i].classList.contains('hidden');
			inspBtnsAfter[i] = baseCond && !isMonster;
		}
		GUIp.improver.setButtonsVisibility(inspBtns, inspBtnsBefore, inspBtnsAfter);
		// craft buttons
		if (this.isFirstTime) {
			this.crftBtns = [document.getElementsByClassName('craft_button b_b')[0],
							 document.getElementsByClassName('craft_button b_r')[0],
							 document.getElementsByClassName('craft_button r_r')[0],
							 document.getElementsByClassName('craft_button span')[0]
							];
		}
		var crftBtnsBefore = [], crftBtnsAfter = [];
		for (i = 0, len = this.crftBtns.length; i < len; i++) {
			crftBtnsBefore[i] = !this.crftBtns[i].classList.contains('hidden');
			crftBtnsAfter[i] = baseCond && !isMonster;
		}
		crftBtnsAfter[0] = crftBtnsAfter[0] && GUIp.inventory.b_b.length;
		crftBtnsAfter[1] = crftBtnsAfter[1] && GUIp.inventory.b_r.length;
		crftBtnsAfter[2] = crftBtnsAfter[2] && GUIp.inventory.r_r.length;
		crftBtnsAfter[3] = crftBtnsAfter[0] || crftBtnsAfter[1] || crftBtnsAfter[2];
		GUIp.improver.setButtonsVisibility(this.crftBtns, crftBtnsBefore, crftBtnsAfter);
	}
	// voice generators
	if (this.isFirstTime) {
		this.voicegens = document.getElementsByClassName('voice_generator');
		this.voicegenClasses = [];
		for (i = 0, len = this.voicegens.length; i < len; i++) {
			this.voicegenClasses[i] = this.voicegens[i].className;
		}
	}
	var voicegensBefore = [], voicegensAfter = [],
		specialConds, specialClasses;
	if (!GUIp.data.isFight) {
		var isGoingBack = so.state.stats.dir.value !== 'ft',
			isTown = GUIp.stats.townName(),
			isSearching = so.state.last_news && so.state.last_news.value.match('дорогу'),
			dieIsDisabled = GUIp.storage.get('Option:disableDieButton'),
			isFullGP = GUIp.stats.Godpower() === GUIp.stats.Max_Godpower(),
			isFullHP = GUIp.stats.HP() === GUIp.stats.Max_HP(),
			canQuestBeAffected = !GUIp.stats.Task_Name().match(/\((?:выполнено|completed|отменено|cancelled)\)/);
		specialClasses = ['heal', 'do_task', 'cancel_task', 'die', 'exp', 'dig', 'town', 'pray'];
		specialConds = [isMonster || isGoingBack || isTown || isSearching || isFullHP,				// heal
						isMonster || isGoingBack || isTown || isSearching || !canQuestBeAffected,	// do_task
																			 !canQuestBeAffected,	// cancel_task
						isMonster ||				isTown ||				 dieIsDisabled,			// die
						isMonster,																	// exp
						isMonster ||										 isTown,				// dig
						isMonster || isGoingBack || isTown ||				 isSearching,			// town
						isMonster ||										 isFullGP				// pray
					   ];
	}
	baseCond = baseCond && !$('.r_blocked:visible').length;
	for (i = 0, len = this.voicegens.length; i < len; i++) {
		voicegensBefore[i] = !this.voicegens[i].classList.contains('hidden');
		voicegensAfter[i] = baseCond;
		if (baseCond && !GUIp.data.isFight) {
			for (var j = 0, len2 = specialConds.length; j < len2; j++) {
				if (specialConds[j] && this.voicegenClasses[i].match(specialClasses[j])) {
					voicegensAfter[i] = false;
				}
			}
		}
	}
	GUIp.improver.setButtonsVisibility(this.voicegens, voicegensBefore, voicegensAfter);
};
GUIp.improver.setButtonsVisibility = function(btns, before, after) {
	for (var i = 0, len = btns.length; i < len; i++) {
		if (before[i] && !after[i]) {
			GUIp.utils.hideElem(btns[i], true);
		}
		if (!before[i] && after[i]) {
			GUIp.utils.hideElem(btns[i], false);
		}
	}
};
GUIp.improver.chatsFix = function() {
	var i, len, cells = document.querySelectorAll('.frDockCell');
	for (i = 0, len = cells.length; i < len; i++) {
		cells[i].classList.remove('left');
		cells[i].style.zIndex = len - i;
		if (cells[i].getBoundingClientRect().right < 350) {
			cells[i].classList.add('left');
		}
	}
	//padding for page settings link
	var chats = document.getElementsByClassName('frDockCell'),
		clen = chats.length,
		padding_bottom = clen ? chats[0].getBoundingClientRect().bottom - chats[clen - 1].getBoundingClientRect().top : GUIp.browser === 'Opera' ? 27 : 0,
		isBottom = window.scrollY >= document.documentElement.scrollHeight - document.documentElement.clientHeight - 10;
	padding_bottom = Math.floor(padding_bottom*10)/10 + 10;
	padding_bottom = (padding_bottom < 0) ? 0 : padding_bottom + 'px';
	document.getElementsByClassName('reset_layout')[0].style.paddingBottom = padding_bottom;
	if (isBottom) {
		window.scrollTo(0, document.documentElement.scrollHeight - document.documentElement.clientHeight);
	}
};
GUIp.improver.initOverrides = function() {
	if (so && so.a_notify) {
		so.a_notify_orig = so.a_notify;
		so.a_notify = function() {
			if (GUIp.storage.get('Option:disableArenaSound')) {
				if(($(document.activeElement).is("input") || $(document.activeElement).is("textarea")) &&
					$(document.activeElement).attr("id") !== "god_phrase" &&
					$(document.activeElement).val().length > 3) {
					var readyness = confirm(Loc.duel_switch_confirm);
					if (!readyness)  {
						return false;
					}
				}
				setTimeout(function() {
					document.location.href = document.location.pathname;
				}, 3e3);
			} else {
				so.a_notify_orig();
			}
		};
	}
	if (so && so.play_sound) {
		so.play_sound_orig = so.play_sound;
		so.play_sound = function(a, b) {
			if (!(GUIp.storage.get('Option:disablePmSound') && a === 'msg.mp3')) {
				so.play_sound_orig(a, b);
			}
		};
	}
	if (GUIp.storage.get('Option:enablePmAlerts') && GUIp.browser !== 'Opera' && Notification.permission === "granted") {
		setTimeout(function() {
			// assume that all messages are loaded at this point, make a list of existing unread ones
			for (var contact in so.messages.h_friends) {
				var hfriend = so.messages.h_friends[contact];
				if (hfriend.ms === "upd" && hfriend.msg) {
					GUIp.improver.pmNoted[contact] = hfriend.msg.id;
				}
			}
			// replace original messages update with modified one
			if (so && so.messages.nm.notify) {
				so.messages.nm.notify_orig = so.messages.nm.notify;
				so.messages.nm.notify = function() {
					// check for a new messages in the updated list and inform about them
					if (arguments[0] === "messages") {
						var callback_fn = function(cname) {
							return function() {
								if (GUIp.utils.getCurrentChat() !== cname) {
									GUIp.utils.openChatWith(cname);
								}
							};
						};
						for (var contact in so.messages.h_friends) {
							var hfriend = so.messages.h_friends[contact];
							if (hfriend.ms === "upd" && hfriend.msg.from === contact && (!GUIp.improver.pmNoted[contact] || (GUIp.improver.pmNoted[contact] < hfriend.msg.id))) {
								GUIp.improver.pmNoted[contact] = hfriend.msg.id;
								// show a notification if chat with contact is closed OR godville tab is unfocused
								// (we're NOT using document.hidden because it returns false when tab is active but the whole browser window unfocused)
								if (GUIp.utils.getCurrentChat() !== contact || !document.hasFocus()) {
									var title = '[PM] ' + contact,
									    text = hfriend.msg.msg.substring(0,200) + (hfriend.msg.msg.length > 200 ? '...' : ''),
									    callback = callback_fn(contact);
									GUIp.utils.showNotification(title,text,callback);
								}
							}
						}
					}
					// return original result in case it will appear some time
					return so.messages.nm.notify_orig.apply(this, arguments);
				};
			}
		}, 2000);
	}
};
GUIp.improver.activity = function() {
	if (!GUIp.logger.updating) {
		GUIp.logger.updating = true;
		setTimeout(function() {
			GUIp.logger.updating = false;
		}, 500);
		GUIp.logger.update();
	}
};
GUIp.improver.improvementDebounce = function(mutations) {
	clearTimeout(GUIp.improver.improveTmt);
	GUIp.improver.improveTmt = setTimeout(function() {
		GUIp.improver.improve();
		if (GUIp.data.isFight) {
			GUIp.logger.update();
		}
	}, 250);
};

// inventory
window.GUIp = window.GUIp || {};

GUIp.inventory = {};

GUIp.inventory.observer = {
	config: {
		childList: true,
		attributes: true,
		subtree: true,
		attributeFilter: ['style']
	},
	func: function(mutations) {
		GUIp.observers.mutationChecker(mutations, function(mutation) {
			return mutation.target.tagName.toLowerCase() === 'li' && mutation.type === "attributes" &&
				   mutation.target.style.display === 'none' && mutation.target.parentNode ||
				   mutation.target.tagName.toLowerCase() === 'ul' && mutation.addedNodes.length;
		}, GUIp.inventory._update);
	},
	target: ['#inventory ul']
};
GUIp.inventory.init = function() {
	if (GUIp.data.isFight) {
		return;
	}
	GUIp.inventory._createCraftButtons();
	GUIp.inventory._update();
	GUIp.observers.start(GUIp.inventory.observer);
};
GUIp.inventory._createCraftButtons = function() {
	var invContent = document.querySelector('#inventory .block_content');
	invContent.insertAdjacentHTML('beforeend', '<span class="craft_button span">' + GUIp.i18n.craft_verb + ':</span>');
	invContent.insertBefore(GUIp.inventory._createCraftButton(GUIp.i18n.b_b, 'b_b', GUIp.i18n.b_b_hint), null);
	invContent.insertBefore(GUIp.inventory._createCraftButton(GUIp.i18n.b_r, 'b_r', GUIp.i18n.b_r_hint), null);
	invContent.insertBefore(GUIp.inventory._createCraftButton(GUIp.i18n.r_r, 'r_r', GUIp.i18n.r_r_hint), null);
};
GUIp.inventory._createInspectButton = function(item_name) {
	var a = document.createElement('a');
	a.className = 'inspect_button';
	a.title = GUIp.i18n.ask1 + GUIp.data.char_sex[0] + GUIp.i18n.inspect + item_name;
	a.textContent = '?';
	a.onclick = GUIp.inventory._inspectButtonClick.bind(null, item_name);
	return a;
};
GUIp.inventory._inspectButtonClick = function(item_name) {
	GUIp.utils.setVoice(GUIp.words.inspectPhrase(GUIp.i18n.trophy + item_name));
	return false;
};
GUIp.inventory._createCraftButton = function(combo, combo_list, hint) {
	var a = document.createElement('a');
	a.className = 'craft_button ' + combo_list;
	a.title = GUIp.i18n.ask2 + GUIp.data.char_sex[0] + GUIp.i18n.craft1 + hint + GUIp.i18n.craft2;
	a.innerHTML = combo;
	a.onclick = GUIp.inventory._craftButtonClick.bind(null, combo_list);
	return a;
};
GUIp.inventory._craftButtonClick = function(combo_list) {
	var rand = Math.floor(Math.random()*GUIp.inventory[combo_list].length),
		items = GUIp.inventory[combo_list][rand];
	GUIp.utils.setVoice(GUIp.words.craftPhrase(items));
	return false;
};
GUIp.inventory._update = function() {
	var i, len, item, flags = [],
		bold_items = 0,
		trophy_boldness = {},
		forbidden_craft = GUIp.storage.get('Option:forbiddenCraft') || '';

	for (i = 0, len = GUIp.words.base.usable_items.types.length; i < len; i++) {
		flags[i] = false;
	}

	// Parse items
	for (var item_name in so.state.inventory) {
		item = so.state.inventory[item_name];
		// color items and add buttons
		if (item.description) { // usable item
			var sect = GUIp.words.usableItemType(item.description);
			bold_items++;
			if (sect !== -1) {
				flags[sect] = true;
			} else if (!~GUIp.utils.messagesShown.indexOf('info')) {
				GUIp.utils.showMessage('info', {
					title: GUIp.i18n.unknown_item_type_title,
					content: '<div>' + GUIp.i18n.unknown_item_type_content + '<b>"' + item.description + '</b>"</div>'
				});
			}
			if (!(forbidden_craft.match('usable') || (forbidden_craft.match('b_b') && forbidden_craft.match('b_r')))) {
				trophy_boldness[item_name] = true;
			}
		} else if (item.type === 'heal_potion') { // healing item
			// if item quantity has increased, it seems that class needs to be re-added again
			item.li[0].classList.add('heal_item');

			if (!(forbidden_craft.match('heal') || (forbidden_craft.match('b_r') && forbidden_craft.match('r_r')))) {
				trophy_boldness[item_name] = false;
			}
		} else {
			if (item.price === 101) { // bold item
				bold_items++;
				if (!(forbidden_craft.match('b_b') && forbidden_craft.match('b_r')) &&
					!item_name.match('золотой кирпич') && !item_name.match(' босса ')) {
					trophy_boldness[item_name] = true;
				}
			} else {
				if (!(forbidden_craft.match('b_r') && forbidden_craft.match('r_r')) &&
					!item_name.match('пушистого триббла')) {
					trophy_boldness[item_name] = false;
				}
			}
			if (!item.isImproved) {
				item.li[0].insertBefore(GUIp.inventory._createInspectButton(item_name), null);
			}
		}
		item.isImproved = true;
	}

	for (i = 0, len = flags.length; i < len; i++) {
		GUIp.informer.update(GUIp.words.base.usable_items.types[i], flags[i]);
	}
	GUIp.informer.update('transform!', flags[GUIp.words.base.usable_items.types.indexOf('transformer')] && bold_items >= 2);
	GUIp.informer.update('smelt!', flags[GUIp.words.base.usable_items.types.indexOf('smelter')] && GUIp.stats.Gold() >= 3000);

	GUIp.inventory._updateCraftCombos(trophy_boldness);
};
GUIp.inventory._updateCraftCombos = function(trophy_boldness) {
	// Склейка трофеев, формирование списков
	GUIp.inventory.b_b = [];
	GUIp.inventory.b_r = [];
	GUIp.inventory.r_r = [];
	var item_names = Object.keys(trophy_boldness).sort(),
		forbidden_craft = GUIp.storage.get('Option:forbiddenCraft') || '';
	if (item_names.length) {
		for (var i = 0, len = item_names.length - 1; i < len; i++) {
			for (var j = i + 1; j < len + 1; j++) {
				if (item_names[i][0] === item_names[j][0]) {
					if (trophy_boldness[item_names[i]] && trophy_boldness[item_names[j]]) {
						if (!forbidden_craft.match('b_b')) {
							GUIp.inventory._pushItemCombo('b_b', item_names[i], item_names[j]);
						}
					} else if (!trophy_boldness[item_names[i]] && !trophy_boldness[item_names[j]]) {
						if (!forbidden_craft.match('r_r')) {
							GUIp.inventory._pushItemCombo('r_r', item_names[i], item_names[j]);
						}
					} else {
						if (!forbidden_craft.match('b_r')) {
							GUIp.inventory._pushItemCombo('b_r', item_names[i], item_names[j]);
						}
					}
				} else {
					break;
				}
			}
		}
	}
	GUIp.improver.calculateButtonsVisibility();
};
GUIp.inventory._pushItemCombo = function(combo, first, second) {
	GUIp.inventory[combo].push(first + GUIp.i18n.and + second);
	GUIp.inventory[combo].push(second + GUIp.i18n.and + first);
};

// timers
window.GUIp = window.GUIp || {};

GUIp.timers = {};

GUIp.timers.init = function() {
	if (GUIp.data.hasTemple) {
		document.querySelector('#imp_button').insertAdjacentHTML('afterend', '<div id=\"imp_timer\" class=\"fr_new_badge hidden\" />');
		if (GUIp.data.isDungeon || (GUIp.data.isFight && GUIp.stats.Hero_Alls_Count() > 2)) {
			this.logTimer = document.querySelector('#imp_timer');
			this.logTimerIsDisabled = GUIp.storage.get('Option:disableLogTimer');
			GUIp.utils.hideElem(this.logTimer, this.logTimerIsDisabled);
		} else {
			this.layingTimer = document.querySelector('#imp_timer');
			this.layingTimerIsDisabled = GUIp.storage.get('Option:disableLayingTimer');
			GUIp.utils.hideElem(this.layingTimer, this.layingTimerIsDisabled);
		}
		if (!GUIp.storage.get('Option:disableLayingTimer') && !GUIp.storage.get('Option:disableLogTimer')) {
			var curTimer = this.layingTimer ? this.layingTimer : this.logTimer;
			curTimer.style.cursor = 'pointer';
			curTimer.onclick = GUIp.timers.toggleTimers.bind(GUIp.timers);
		}
		GUIp.timers.tick();
		setInterval(function() { GUIp.timers.tick(); }, 60000);
	}
};
GUIp.timers.getDate = function(entry) {
	return GUIp.storage.get('ThirdEye:' + entry) ? new Date(GUIp.storage.get('ThirdEye:' + entry)) : 0;
};
GUIp.timers.tick = function() {
	this._lastLayingDate = GUIp.timers.getDate('LastLaying');
	this._lastLogDate = GUIp.timers.getDate('LastLog');
	this._penultLogDate = GUIp.timers.getDate('PenultLog');
	for (var msg in so.state.diary_i) {
		var curEntryDate = new Date(so.state.diary_i[msg].time);
		if (msg.match(/^(?:Возложила?|Выставила? тридцать золотых столбиков|I placed \w+? bags of gold)/i) && curEntryDate > this._lastLayingDate) {
			this._lastLayingDate = curEntryDate;
		}
		var logs;
		if (msg.match(/^Выдержка из хроники подземелья:|Notes from the dungeon:/i) && (logs = (msg.match(/бревно для ковчега|ещё одно бревно|log for the ark/gi) || []).length)) {
			if (curEntryDate > this._lastLogDate) {
				while (logs--) {
					this._penultLogDate = this._lastLogDate;
					this._lastLogDate = curEntryDate;
				}
			} else if (curEntryDate < this._lastLogDate && curEntryDate > this._penultLogDate) {
				this._penultLogDate = curEntryDate;
			}
		}
		if (!this._latestEntryDate || this._latestEntryDate < curEntryDate) {
			this._latestEntryDate = curEntryDate;
		}
		if (!this._earliestEntryDate || this._earliestEntryDate > curEntryDate) {
			this._earliestEntryDate = curEntryDate;
		}
	}
	if (GUIp.timers.getDate('Latest') >= this._earliestEntryDate) {
		this._earliestEntryDate = GUIp.timers.getDate('Earliest');
		if (this._lastLayingDate) {
			GUIp.storage.set('ThirdEye:LastLaying', this._lastLayingDate);
		}
		if (this._lastLogDate) {
			GUIp.storage.set('ThirdEye:LastLog', this._lastLogDate);
		}
		if (this._penultLogDate) {
			GUIp.storage.set('ThirdEye:PenultLog', this._penultLogDate);
		}
	} else {
		GUIp.storage.set('ThirdEye:Earliest', this._earliestEntryDate);
		GUIp.storage.set('ThirdEye:LastLaying', this._lastLayingDate || '');
		GUIp.storage.set('ThirdEye:LastLog', this._lastLogDate || '');
		GUIp.storage.set('ThirdEye:PenultLog', this._penultLogDate || '');
	}
	GUIp.storage.set('ThirdEye:Latest', this._latestEntryDate);
	if (this.layingTimer && !this.layingTimerIsDisabled) {
		GUIp.timers._calculateTime(true, this._lastLayingDate);
	}
	if (this.logTimer && !this.logTimerIsDisabled) {
		GUIp.timers._calculateTime(false, this._penultLogDate);
	}
};
GUIp.timers._calculateTime = function(isLaying, fromDate) {
	var totalMinutes, greenHours = isLaying ? 36 : 24,
		yellowHours = isLaying ? 18 : 23;
	if (fromDate) {
		totalMinutes = Math.ceil((Date.now() + 1 - fromDate)/1000/60);
		GUIp.timers._setTimer(isLaying, totalMinutes, totalMinutes > greenHours*60 ? 'green' : totalMinutes > yellowHours*60 ? 'yellow' : 'red');
	} else {
		totalMinutes = Math.floor((Date.now() - this._earliestEntryDate)/1000/60);
		GUIp.timers._setTimer(isLaying, totalMinutes, totalMinutes > greenHours*60 ? 'green' : 'grey');
	}
};
GUIp.timers._formatTime = function(maxHours, totalMinutes) {
	var countdownMinutes = maxHours*60 - totalMinutes,
		hours = Math.floor(countdownMinutes/60),
		minutes = Math.floor(countdownMinutes%60);
	return (hours < 10 ? '0' : '') + hours + ':' + (minutes < 10 ? '0' : '') + minutes;
};
GUIp.timers._calculateExp = function(totalMinutes) {
	var baseExp = Math.min(totalMinutes/36/60*2, 2),
		amountMultiplier = [1, 2, 2.5],
		level = GUIp.stats.Level(),
		levelMultiplier = level < 100 ? 1 : level < 125 ? 0.5 : 0.25,
		title = [];
	for (var i = 1; i <= 3; i++) {
		title.push(i + '0k gld → ' + ((i + baseExp*amountMultiplier[i - 1])*levelMultiplier).toFixed(1) + '% exp');
	}
	return title.join('\n');
};
GUIp.timers._setTimer = function(isLaying, totalMinutes, color) {
	var timer = isLaying ? this.layingTimer : this.logTimer;
	timer.className = timer.className.replace(/green|yellow|red|grey/g, '');
	timer.classList.add(color);
	if (color === 'grey') {
		timer.textContent = '?';
		timer.title = (isLaying ? GUIp.i18n.gte_unknown_penalty : GUIp.i18n.log_unknown_time) + GUIp.timers._formatTime(isLaying ? 36 : 24, totalMinutes);
	} else {
		timer.textContent = color === 'green' ? isLaying ? '✓' : '木' : (isLaying ? GUIp.timers._formatTime(36, totalMinutes) : '¦' + GUIp.timers._formatTime(24, totalMinutes) + '¦');
		timer.title = isLaying ? GUIp.timers._calculateExp(totalMinutes) : totalMinutes > 24*60 ? GUIp.i18n.log_is_guaranteed : GUIp.i18n.log_isnt_guaranteed;
	}
};
GUIp.timers.toggleTimers = function(e) {
	e.stopPropagation();
	if (!this.layingTimer && !this.logTimer) {
		return;
	}
	if (this.layingTimer) {
		this.logTimer = this.layingTimer;
		delete this.layingTimer;
	} else {
		this.layingTimer = this.logTimer;
		delete this.logTimer;
	}

	var timerElem = $('#imp_timer');
	timerElem.fadeOut(500, function() {
		GUIp.timers.tick();
		timerElem.fadeIn(500);
	});
};

// observers
window.GUIp = window.GUIp || {};

GUIp.observers = {};

GUIp.observers.init = function() {
	for (var key in this) {
		if (this[key].condition) {
			GUIp.observers.start(this[key]);
		}
	}
};
GUIp.observers.start = function(obj) {
	for (var i = 0, len = obj.target.length; i < len; i++) {
		var target = document.querySelector(obj.target[i]);
		if (target) {
			var observer = new MutationObserver(obj.func);
			observer.observe(target, obj.config);
		}
	}
};
GUIp.observers.mutationChecker = function(mutations, check, callback) {
	var callbackRunRequired = false;
	for (var i = 0, len = mutations.length; i < len; i++) {
		if (check(mutations[i])) {
			callbackRunRequired = true;
			break;
		}
	}
	if (callbackRunRequired) {
		callback();
	}
};
GUIp.observers.chats = {
	condition: true,
	config: { childList: true },
	func: function(mutations) {
		for (var i = 0, len = mutations.length; i < len; i++) {
			if (mutations[i].addedNodes.length && !mutations[i].addedNodes[0].classList.contains('moved')) {
				var newNode = mutations[i].addedNodes[0];
				newNode.classList.add('moved');
				mutations[i].target.appendChild(newNode);
				var msgArea = newNode.querySelector('.frMsgArea');
				msgArea.scrollTop = msgArea.scrollTopMax || msgArea.scrollHeight;
			}
		}
		GUIp.observers.mutationChecker(mutations, function(mutation) {
			return mutation.addedNodes.length || mutation.removedNodes.length;
		}, function() { GUIp.improver.chatsFix(); GUIp.informer.clearTitle(); });
	},
	target: ['.chat_ph']
};
GUIp.observers.clearTitle = {
	condition: true,
	config: {
		childList: true,
		attributes: true,
		subtree: true,
		attributeFilter: ['style']
	},
	func: function(mutations) {
		GUIp.observers.mutationChecker(mutations, function(mutation) {
			return mutation.target.className.match(/fr_new_(?:msg|badge)/) ||
				  (mutation.target.className.match(/dockfrname_w/) && mutation.removedNodes.length && mutation.removedNodes[0].className.match(/fr_new_msg/));
		}, GUIp.informer.clearTitle.bind(GUIp.informer));
	},
	target: ['.msgDockWrapper']
};
GUIp.observers.refresher = {
	condition: true,
	config: {
		attributes: true,
		characterData: true,
		childList: true,
		subtree: true
	},
	func: function(mutations) {
		var toReset = false;
		for (var i = 0, len = mutations.length; i < len; i++) {
			var tgt = mutations[i].target,
				id = tgt.id,
				cl = tgt.className;
			if (!(id && id.match(/logger|pet_badge|equip_badge/)) &&
				!(cl && cl.match(/voice_generator|inspect_button|m_hover|craft_button/))) {
				toReset = true;
				break;
			}
		}
		if (toReset) {
			clearInterval(GUIp.improver.softRefreshInt);
			clearInterval(GUIp.improver.hardRefreshInt);
			if (!GUIp.storage.get('Option:disablePageRefresh')) {
				GUIp.improver.softRefreshInt = setInterval(function() { GUIp.improver.softRefresh(); }, (GUIp.data.isFight || GUIp.data.isDungeon) ? 5e3 : 9e4);
				GUIp.improver.hardRefreshInt = setInterval(function() { GUIp.improver.hardRefresh(); }, (GUIp.data.isFight || GUIp.data.isDungeon) ? 15e3 : 27e4);
			}
		}
	},
	target: ['#main_wrapper']
};
GUIp.observers.diary = {
	get condition() {
		return !GUIp.data.isFight && !GUIp.data.isDungeon;
	},
	config: { childList: true },
	func: function(mutations) {
		GUIp.observers.mutationChecker(mutations, function(mutation) { return mutation.addedNodes.length;	}, GUIp.improver.improveDiary);
	},
	target: ['#diary .d_content']
};
GUIp.observers.news = {
	get condition() {
		return !GUIp.data.isFight && !GUIp.data.isDungeon;
	},
	config: { childList: true, characterData: true, subtree: true },
	func: GUIp.improver.improvementDebounce,
	target: ['.f_news']
};
GUIp.observers.chronicles = {
	get condition() {
		return GUIp.data.isDungeon;
	},
	config: { childList: true },
	func: function(mutations) {
		GUIp.observers.mutationChecker(mutations, function(mutation) { return mutation.addedNodes.length;	}, GUIp.improver.improveChronicles.bind(GUIp.improver));
	},
	target: ['#m_fight_log .d_content']
};
GUIp.observers.map_colorization = {
	get condition() {
		return GUIp.data.isDungeon;
	},
	config: {
		childList: true,
		subtree: true
	},
	func: function(mutations) {
		GUIp.observers.mutationChecker(mutations, function(mutation) { return mutation.addedNodes.length;	}, GUIp.improver.colorDungeonMap.bind(GUIp.improver));
	},
	target: ['#map .block_content']
};
GUIp.observers.node_insertion = {
	condition: true,
	config: {
		childList: true,
		subtree: true
	},
	func: function(mutations) {
		GUIp.observers.mutationChecker(mutations, function(mutation) {
			// to prevent improving WHEN ENTERING FUCKING TEXT IN FUCKING TEXTAREA
			return mutation.addedNodes.length && mutation.addedNodes[0].nodeType !== 3;
		}, GUIp.improver.improvementDebounce);
	},
	target: ['body']
};

// trycatcher
window.GUIp = window.GUIp || {};

GUIp.trycatcher = {};

GUIp.trycatcher.wrap = function(method) {
	return function() {
		try {
			return method.apply(this, arguments);
		} catch (error) {
			if (GUIp.storage.get('Option:enableDebugMode')) {
				GUIp.utils.processError(error, true);
			} else {
				GUIp.utils.checkVersion(GUIp.utils.processError.bind(null, error, false), GUIp.utils.informAboutOldVersion);
			}
		}
	};
};

GUIp.trycatcher.process = function(object) {
	var type, method;
	var showOriginalSource = function() {
		return this.original.toString();
	};
	for (var key in object) {
		type = Object.prototype.toString.call(object[key]).slice(8, -1);
		switch(type) {
		case 'Function':
			method = object[key];
			object[key] = GUIp.trycatcher.wrap(method);
			object[key].original = method;
			object[key].toString = showOriginalSource;
			break;
		case 'Object':
			GUIp.trycatcher.process(object[key]);
			break;
		}
	}
};

// starter
window.GUIp = window.GUIp || {};

GUIp.starter = {};

GUIp.starter._init = function() {
	GUIp.data.init();
	GUIp.storage.migrate();
	GUIp.utils.addCSS();
	GUIp.utils.inform();
	GUIp.words.init();
	GUIp.logger.create();
	GUIp.timeout.create();
	GUIp.help.init();
	GUIp.informer.init();
	GUIp.forum.init();
	GUIp.inventory.init();
	GUIp.improver.improve();
	GUIp.timers.init();
	GUIp.observers.init();
	GUIp.improver.initOverrides();
};
GUIp.starter.start = function() {
	if ($ && ($('#m_info').length || $('#stats').length) && GUIp.browser && GUIp.i18n && GUIp.addCSSFromURL && so.state) {
		clearInterval(starterInt);
		console.time('Godville UI+ initialized in');

		GUIp.starter._init();

		if (!GUIp.data.isFight) {
			window.onmousemove = window.onscroll = window.ontouchmove = GUIp.improver.activity;
		}

		// svg for #logger fade-out in FF
		var is5c = document.getElementsByClassName('page_wrapper_5c').length;
		document.body.insertAdjacentHTML('beforeend',
			'<svg id="fader">' +
				'<defs>' +
					'<linearGradient id="gradient" x1="0" y1="0" x2 ="100%" y2="0">' +
						'<stop stop-color="black" offset="0"></stop>' +
						'<stop stop-color="white" offset="0.0' + (is5c ? '2' : '3') + '"></stop>' +
					'</linearGradient>' +
					'<mask id="fader_masking" maskUnits="objectBoundingBox" maskContentUnits="objectBoundingBox">' +
						'<rect x="0.0' + (is5c ? '2' : '3') + '" width="0.9' + (is5c ? '8' : '7') + '" height="1" fill="url(#gradient)" />' +
					'</mask>' +
				'</defs>' +
			'</svg>'
		);

		console.timeEnd('Godville UI+ initialized in');
	}
};

// Main code
GUIp.trycatcher.process(GUIp);

var starterInt = setInterval(function() { GUIp.starter.start(); }, 200);


})();