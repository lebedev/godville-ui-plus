(function() {
'use strict';

var worker = window.wrappedJSObject || window;

if (window.wrappedJSObject) {
	worker.GUIp = createObjectIn(worker);
} else {
	worker.GUIp = {};
}
// ui_data
var ui_data = window.wrappedJSObject ? createObjectIn(worker.GUIp, {defineAs: "data"}) : worker.GUIp.data = {};

// base variables initialization
ui_data.init = function() {
	ui_data._initVariables();
	ui_data._initForumData();
	ui_data._clearOldDungeonData();

	// init mobile cookies
	if (worker.navigator.userAgent.match(/Android/)) {
		worker.document.cookie = 'm_f=1';
		worker.document.cookie = 'm_pp=1';
		worker.document.cookie = 'm_fl=1';
	}

	ui_data._getLEMRestrictions();
	worker.setInterval(ui_data._getLEMRestrictions, 60*60*1000);

	ui_data._getWantedMonster();
	worker.setInterval(ui_data._getWantedMonster, 5*60*1000);
};
ui_data._initVariables = function() {
	this.currentVersion = '0.34.150.15';
	this.isFight = ui_stats.isFight();
	this.isDungeon = ui_stats.isDungeon();
	document.body.classList.add(this.isDungeon ? 'dungeon' : this.isFight ? 'fight' : 'field');
	this.god_name = ui_stats.godName();
	this.char_name = ui_stats.charName();
	this.char_sex = ui_stats.isMale() ? worker.GUIp_i18n.hero : worker.GUIp_i18n.heroine;
	ui_storage.set('ui_s', '');
	localStorage.setItem('GUIp_CurrentUser', this.god_name);
	if (ui_stats.Bricks() === 1000) {
		document.body.classList.add('has_temple');
		this.hasTemple = true;
	}
	ui_utils.voiceInput = document.getElementById('god_phrase');
};
ui_data._initForumData = function() {
	if (!ui_storage.get('Forum1')) {
		ui_storage.set('Forum1', '{}');
		ui_storage.set('Forum2', '{}');
		ui_storage.set('Forum3', '{}');
		ui_storage.set('Forum4', '{}');
		ui_storage.set('ForumInformers', '{}');

		if (worker.GUIp_locale === 'ru') {
			//ui_storage.set('Forum2', '{"2812": {"posts": 0, "date": 0}}');
			ui_storage.set('Forum5', '{}');
			ui_storage.set('Forum6', '{}');
		} else {
			//ui_storage.set('Forum1', '{"2800": {"posts": 0, "date": 0}}');
		}
	}
};
ui_data._clearOldDungeonData = function() {
	if (!this.isFight && !this.isDungeon) {
		for (var key in localStorage) {
			if (key.match(/:Dungeon:/)) {
				localStorage.removeItem(key);
			}
		}
	}
};
ui_data._getLEMRestrictions = function() {
	if (isNaN(ui_storage.get('LEMRestrictions:Date')) || Date.now() - ui_storage.get('LEMRestrictions:Date') > 24*60*60*1000) {
		ui_utils.getXHR('http://www.godalert.info/Dungeons/guip.cgi', ui_data._parseLEMRestrictions);
	}
};
ui_data._parseLEMRestrictions = function(xhr) {
	var restrictions = JSON.parse(xhr.responseText);
	ui_storage.set('LEMRestrictions:Date', Date.now());
	ui_storage.set('LEMRestrictions:FirstRequest', restrictions.first_request);
	ui_storage.set('LEMRestrictions:TimeFrame', restrictions.time_frame);
	ui_storage.set('LEMRestrictions:RequestLimit', restrictions.request_limit);
};
ui_data._getWantedMonster = function() {
	if (isNaN(ui_storage.get('WantedMonster:Date')) ||
		ui_utils.dateToMoscowTimeZone(+ui_storage.get('WantedMonster:Date')) < ui_utils.dateToMoscowTimeZone(Date.now())) {
		ui_utils.getXHR('/news', ui_data._parseWantedMonster);
	} else {
		ui_improver.wantedMonsters = new worker.RegExp(ui_storage.get('WantedMonster:Value'));
	}
};
ui_data._parseWantedMonster = function(xhr) {
	var temp = xhr.responseText.match(/(?:Разыскиваются|Wanted)[\s\S]+?>([^<]+?)<\/a>[\s\S]+?>([^<]+?)<\/a>/),
		newWantedMonster = temp ? temp[1] + '|' + temp[2] : '';
	if (newWantedMonster && newWantedMonster !== ui_storage.get('WantedMonster:Value')) {
		ui_storage.set('WantedMonster:Date', Date.now());
		ui_storage.set('WantedMonster:Value', newWantedMonster);
		ui_improver.wantedMonsters = new worker.RegExp(newWantedMonster);
	}
};
// ui_utils
var ui_utils = window.wrappedJSObject ? createObjectIn(worker.GUIp, {defineAs: "utils"}) : worker.GUIp.utils = {};

ui_utils.hasShownErrorMessage = false;
ui_utils.hasShownInfoMessage = false;
// base phrase say algorythm
ui_utils.setVoice = function(voice) {
	this.voiceInput.value = voice;
	ui_utils.triggerChangeOnVoiceInput();
};
ui_utils.triggerChangeOnVoiceInput = function() {
	worker.$(this.voiceInput).change();
};
// finds a label with given name
ui_utils.findLabel = function($base_elem, label_name) {
	return worker.$('.l_capt', $base_elem).filter(function(index) {
		return this.textContent === label_name;
	});
};
// checks if $elem already improved
ui_utils.isAlreadyImproved = function(elem) {
	if (elem.classList.contains('improved')) {
		return true;
	} else {
		elem.classList.add('improved');
		return false;
	}
};
// generic voice generator
ui_utils.getGenericVoicegenButton = function(text, section, title) {
	var voicegen = document.createElement('a');
	voicegen.title = title;
	voicegen.textContent = text;
	voicegen.className = 'voice_generator ' + (ui_data.isDungeon ? 'dungeon' : ui_data.isFight ? 'battle' : 'field') + ' ' + section;
	voicegen.onclick = function() {
		if (document.getElementById('god_phrase').getAttribute('disabled') !== 'disabled') {
			ui_utils.setVoice(ui_words.longPhrase(section));
			ui_words.currentPhrase = "";
		}
		return false;
	};
	return voicegen;
};
ui_utils.addVoicegen = function(elem, voicegen_name, section, title) {
	elem.parentNode.insertBefore(ui_utils.getGenericVoicegenButton(voicegen_name, section, title), elem.nextSibling);
};
// Случайный индекс в массиве
ui_utils.getRandomIndex = function(arr) {
	return Math.floor(Math.random()*arr.length);
};
// Случайный элемент массива
ui_utils.getRandomItem = function(arr) {
	return arr[ui_utils.getRandomIndex(arr)];
};
// Вытаскивает случайный элемент из массива
ui_utils.popRandomItem = function(arr) {
	var ind = ui_utils.getRandomIndex(arr);
	var res = arr[ind];
	arr.splice(ind, 1);
	return res;
};
// Escapes HTML symbols
ui_utils.escapeHTML = function(str) {
	return String(str).replace(/&/g, "&amp;")
					  .replace(/"/g, "&quot;")
					  .replace(/</g, "&lt;")
					  .replace(/>/g, "&gt;");
};
ui_utils.addCSS = function () {
	if (worker.GUIp_browser !== 'Opera' && !document.getElementById('ui_css')) {
		worker.GUIp_addCSSFromURL(worker.GUIp_getResource('superhero.css'), 'guip_css');
	}
};
ui_utils.getXHR = function(path, success_callback, fail_callback, extra_arg) {
	var xhr = new XMLHttpRequest();
	if (extra_arg) {
		xhr.extra_arg = extra_arg;
	}
	xhr.onreadystatechange = function() {
		if (xhr.readyState < 4) {
			return;
		} else if (xhr.status === 200) {
			if (success_callback) {
				success_callback(xhr);
			}
		} else if (fail_callback) {
			fail_callback(xhr);
		}
	};

	xhr.open('GET', path, true);
	xhr.send();
};
ui_utils.showMessage = function(msg_no, msg) {
	var id = 'msg' + msg_no;
	document.getElementById('menu_bar').insertAdjacentHTML('afterend',
		'<div id="' + id + '" class="hint_bar ui_msg">'+
			'<div class="hint_bar_capt"><b>' + msg.title + '</b></div>'+
			'<div class="hint_bar_content">' + msg.content + '</div>'+
			'<div class="hint_bar_close"><a id="' + id + '_close">' + worker.GUIp_i18n.close + '</a></div>' +
		'</div>'
	);
	var msg_elem = document.getElementById(id);
	document.getElementById(id + '_close').onclick = function() {
		worker.$(msg_elem).fadeToggle(function() {
			msg_elem.parentNode.removeChild(msg_elem);
			if (!isNaN(msg_no)) {
				ui_storage.set('lastShownMessage', msg_no);
			}
		});
		return false;
	};

	worker.setTimeout(function() {
		worker.$(msg_elem).fadeToggle(1500, msg.callback);
	}, 1000);
};
ui_utils.inform = function() {
	var last_shown = !isNaN(ui_storage.get('lastShownMessage')) ? +ui_storage.get('lastShownMessage') : -1;
	for (var i = 0, len = this.messages[worker.GUIp_locale].length; i < len; i++) {
		if (this.messages[worker.GUIp_locale][i].msg_no > last_shown) {
			ui_utils.showMessage(this.messages[worker.GUIp_locale][i].msg_no, this.messages[worker.GUIp_locale][i]);
		}
	}
};
ui_utils.messages = {
	ru: [{
		msg_no: 0,
		title: 'Приветственное сообщение Godville UI+',
		get content() { return '<div>Приветствую бог' + (document.title.match('её') ? 'иню' : 'а') + ', использующ' + (document.title.match('её') ? 'ую' : 'его') +
			' дополнение <b>Godville UI+</b>.</div>'+

			'<div style="text-align: justify; margin: 0.2em 0 0.3em;">&emsp;Нажмите на кнопку <b>настройки ui+</b> в верхнем меню или ' +
			'откройте вкладку <b>Настройки UI+</b> в <b>профиле</b> героя и ознакомьтесь с настройками дополнения, если еще этого не сделали.<br>' +

			'&emsp;Касательно форумных информеров: по умолчанию, вы подписаны только на тему дополнения и, скорее всего, видите ее <i>форумный информер</i> в левом верхнем углу.<br>' +

			'&emsp;Если с каким-то функционалом дополнения не удалось интуитивно разобраться — прочтите <b>статью дополнения в богии</b> ' +
			'или в соответствующей <b>теме на форуме</b>.<br>' +

			'&emsp;Инструкции на случай проблем можно прочесть в <i>диалоговом окне помощи</i> (оно сейчас открыто), которое открывается/закрывается ' +
			'по щелчку на кнопке <b style="text-decoration: underline;">help</b> в верхнем меню. Ссылки на все ранее упомянутое находятся там же.<br>' +

			'<div style="text-align: right;">Приятной игры!<br>~~Бэдлак</div>';
		},
		callback: function() {
			if (!ui_storage.get('helpDialogVisible')) {
				ui_help.toggleDialog();
			}
		}
	},
	{
		msg_no: 8, // 0..7 are used
		title: 'Godville UI+: Разработка прекращена',
		content: '<div style="text-align: justify;">&emsp;Вы ничего не можете с этим поделать.</div>' +
				 '<div style="text-align: right;">Подпись.<br>~~Бэдлак</div>'
	}
	/*{
		msg_no: 9, // 0..8 are used
		title: 'Godville UI+: Заголовок',
		content: '<div style="text-align: justify;">&emsp;Текст.</div>' +
				 '<div style="text-align: right;">Подпись.<br>~~Бэдлак</div>'
	}*/],
	en: [{
		msg_no: 0,
		title: 'Godville UI+ greeting message',
		get content() { return '<div>Greetings to a god' + (document.title.match('his') ? '' : 'dess') + ', using <b>Godville UI+</b> ' + (worker.GUIp_browser === 'Firefox' ? 'add-on' : 'extension') + '.</div>' +
			'<div style="text-align: justify; margin: 0.2em 0 0.3em;">&emsp;Please click <b>ui+ settings</b> button at the top of a page, or ' +
			'open <b>UI+ settings</b> tab in the hero <b>profile</b> and familiarize yourself with the settings available in this ' + (worker.GUIp_browser === 'Firefox' ? 'add-on' : 'extension') + ', if you haven\'t done so yet.<br>' +

			'&emsp;In respect to forum informers, by default you are only subscribed to the topic for this addon, and most likely you can see it <i>in the upper left corner</i> right now.<br>' +

			'&emsp;If you can\'t figure out some functions of the ' + (worker.GUIp_browser === 'Firefox' ? 'add-on' : 'extension') + ' - feel free to ask in the forums.<br>' +

			'&emsp;Guides for handling errors can be found in the <i>help dialog</i> (which is open now), that can be shown or hidden by clicking <b style="text-decoration: underline;">ui+ help</b> in the top menu. ' +
			'Links to everything mentioned above can also be found there.<br>' +

			'<div style="text-align: right;">Enjoy the game!<br>~~Bad Luck</div>';
		},
		callback: function() {
			if (!ui_storage.get('helpDialogVisible')) {
				ui_help.toggleDialog();
			}
		}
	},
	{
		msg_no: 3, // 0..2 are used
		title: 'Godville UI+: The Development is Discontinued',
		content: '<div style="text-align: justify;">&emsp;And you can\'t do anything with it.</div>' +
				 '<div style="text-align: right;">Signature.<br>~~Bad Luck</div>'
	}
	/*{
		msg_no: 4, // 0..3 are used
		title: 'Godville UI+: Title',
		content: '<div style="text-align: justify;">&emsp;Text.</div>' +
				 '<div style="text-align: right;">Signature.<br>~~Bad Luck</div>'
	}*/]
};
ui_utils.getNodeIndex = function(node) {
	var i = 0;
	while ((node = node.previousElementSibling)) {
		i++;
	}
	return i;
};
ui_utils.openChatWith = function(friend, e) {
	if (e) {
		e.preventDefault();
		e.stopPropagation();
	}
	worker.so.nm.bindings.show_friend[0].update(friend);
	/*var current, friends = document.querySelectorAll('.msgDockPopupW .frline');
	for (var i = 0, len = friends.length; i < len; i++) {
		current = friends[i].querySelector('.frname');
		if (current.textContent === friend) {
			current.click();
			break;
		}
	}*/
};
ui_utils.dateToMoscowTimeZone = function(date) {
	var temp = new Date(date);
	temp.setTime(temp.getTime() + (temp.getTimezoneOffset() + 180)*60*1000);
	return temp.getFullYear() + '/' +
		  (temp.getMonth() + 1 < 10 ? '0' : '') + (temp.getMonth() + 1) + '/' +
		  (temp.getDate() < 10 ? '0' : '') + temp.getDate();
};
ui_utils.setVoiceSubmitState = function(condition, disable) {
	if (!ui_data.isFight && condition) {
		var voice_submit = document.getElementById('voice_submit');
		if (disable) {
			voice_submit.setAttribute('disabled', 'disabled');
		} else {
			voice_submit.removeAttribute('disabled');
		}
		return true;
	}
	return false;
};
ui_utils.hideElem = function(elem, hide) {
	if (hide) {
		elem.classList.add('hidden');
	} else {
		elem.classList.remove('hidden');
	}
};
ui_utils._parseVersion = function(isNewestCallback, isNotNewestCallback, failCallback, xhr) {
	var match = xhr.responseText.match(/Godville UI\+ (\d+\.\d+\.\d+\.\d+)/);
	if (match) {
		var temp_cur = ui_data.currentVersion.split('.'),
			last_version = match[1],
			temp_last = last_version.split('.'),
			isNewest = +temp_cur[0] < +temp_last[0] ? false :
					   +temp_cur[0] > +temp_last[0] ? true :
					   +temp_cur[1] < +temp_last[1] ? false :
					   +temp_cur[1] > +temp_last[1] ? true :
					   +temp_cur[2] < +temp_last[2] ? false :
					   +temp_cur[2] > +temp_last[2] ? true :
					   +temp_cur[3] < +temp_last[3] ? false : true;
		if (isNewest) {
			if (isNewestCallback) {
				isNewestCallback();
			}
		} else if (isNotNewestCallback) {
			isNotNewestCallback();
		}
	} else if (failCallback) {
		failCallback();
	}
};
ui_utils.checkVersion = function(isNewestCallback, isNotNewestCallback, failCallback) {
	ui_utils.getXHR('/forums/show/' + (worker.GUIp_locale === 'ru' ? '2' : '1'), ui_utils._parseVersion.bind(null, isNewestCallback, isNotNewestCallback, failCallback), failCallback);
};

ui_utils.processError = function(error, isDebugMode) {
	if (isDebugMode) {
		worker.console.warn(worker.GUIp_i18n.debug_mode_warning);
	}
	var name_message = error.name + ': ' + error.message,
		stack = error.stack.replace(name_message, '').replace(/^\n|    at /g, '').replace(/(?:chrome-extension|@resource).*?:(\d+:\d+)/g, '@$1');
	worker.console.error('Godville UI+ error log:\n' +
						  name_message + '\n' +
						  worker.GUIp_i18n.error_message_stack_trace + ': ' + stack);
	if (!ui_utils.hasShownErrorMessage) {
		ui_utils.hasShownErrorMessage = true;
		ui_utils.showMessage('error', {
			title: worker.GUIp_i18n.error_message_title,
			content: (isDebugMode ? '<div><b class="debug_mode_warning">' + worker.GUIp_i18n.debug_mode_warning + '</b></div>' : '') +
					 '<div id="possible_actions">' +
						'<div>' + worker.GUIp_i18n.error_message_text + ' <b>' + name_message + '</b>.</div>' +
						'<div>' + worker.GUIp_i18n.possible_actions + '</div>' +
						'<ol>' +
							'<li>' + worker.GUIp_i18n.if_first_time + '<a id="press_here_to_reload">' + worker.GUIp_i18n.press_here_to_reload + '</a></li>' +
							'<li>' + worker.GUIp_i18n.if_repeats + '<a id="press_here_to_show_details">' + worker.GUIp_i18n.press_here_to_show_details + '</a></li>' +
						'</ol>' +
					 '</div>' +
					 '<div id="error_details" class="hidden">' +
						'<div>' + worker.GUIp_i18n.error_message_subtitle + '</div>' +
						'<div>' + worker.GUIp_i18n.browser + ' <b>' + worker.GUIp_browser + ' ' + navigator.userAgent.match(worker.GUIp_browser + '\/([\\d.]+)')[1] +'</b>.</div>' +
						'<div>' + worker.GUIp_i18n.version + ' <b>' + ui_data.currentVersion + '</b>.</div>' +
						'<div>' + worker.GUIp_i18n.error_message_text + ' <b>' + name_message + '</b>.</div>' +
						'<div>' + worker.GUIp_i18n.error_message_stack_trace + ': <b>' + stack.replace(/\n/g, '<br>') + '</b></div>' +
					 '</div>',
			callback: function() {
				document.getElementById('press_here_to_reload').onclick = location.reload.bind(location);
				document.getElementById('press_here_to_show_details').onclick = function() {
					ui_utils.hideElem(document.getElementById('possible_actions'), true);
					ui_utils.hideElem(document.getElementById('error_details'), false);
					if (!ui_storage.get('helpDialogVisible')) {
						ui_help.toggleDialog();
					}
				};
			}
		});
	}
};

ui_utils.informAboutOldVersion = function() {
	ui_utils.showMessage('update_required', {
		title: worker.GUIp_i18n.error_message_title,
		content: '<div>' + worker.GUIp_i18n.error_message_in_old_version + '</div>',
		callback: function() {
			if (!ui_storage.get('helpDialogVisible')) {
				ui_help.toggleDialog();
			}
		}
	});
};

// ui_timeout
var ui_timeout = window.wrappedJSObject ? createObjectIn(worker.GUIp, {defineAs: "timeout"}) : worker.GUIp.timeout = {};

ui_timeout.bar = null;
ui_timeout.timeout = 0;
ui_timeout._finishtDate = 0;
ui_timeout._tickInt = 0;
ui_timeout._tick = function() {
	if (Date.now() > this._finishDate) {
		worker.clearInterval(this._tickInt);
		if (this.bar.style.transitionDuration) {
			this.bar.style.transitionDuration = '';
		}
		this.bar.classList.remove('running');
		ui_utils.setVoiceSubmitState(!ui_improver.freezeVoiceButton.match('when_empty') || document.querySelector('#god_phrase').value, false);
	}
};
// creates timeout bar element
ui_timeout.create = function() {
	this.bar = document.createElement('div');
	this.bar.id = 'timeout_bar';
	document.body.insertBefore(this.bar, document.body.firstChild);
};
// starts timeout bar
ui_timeout.start = function() {
	worker.clearInterval(this._tickInt);
	this.bar.style.transitionDuration = '';
	this.bar.classList.remove('running');
	worker.setTimeout(ui_timeout._delayedStart, 10);
	this._finishtDate = Date.now() + this.timeout*1000;
	this._tickInt = worker.setInterval(ui_timeout._tick.bind(this), 100);
	ui_utils.setVoiceSubmitState(ui_improver.freezeVoiceButton.match('after_voice'), true);
};
ui_timeout._delayedStart = function() {
	var customTimeout = ui_storage.get('Option:voiceTimeout');
	if (!isNaN(customTimeout)) {
		ui_timeout.timeout = customTimeout;
		ui_timeout.bar.style.transitionDuration = customTimeout + 's';
	} else {
		ui_timeout.timeout = 20;
	}
	ui_timeout.bar.classList.add('running');
};

// ui_help
var ui_help = window.wrappedJSObject ? createObjectIn(worker.GUIp, {defineAs: "help"}) : worker.GUIp.help = {};

ui_help.init = function() {
	ui_help._createHelpDialog();
	ui_help._createButtons();
};
// creates ui dialog
ui_help._createHelpDialog = function() {
	document.getElementById('menu_bar').insertAdjacentHTML('afterend',
		'<div id="ui_help" class="hint_bar" style="padding-bottom: 0.7em; display: none;">' +
		'<div class="hint_bar_capt"><b>Godville UI+ (v' + ui_data.currentVersion + ')</b>, ' + worker.GUIp_i18n.help_dialog_capt + '</div>' +
		'<div class="hint_bar_content" style="padding: 0.5em 0.8em;">'+
			'<div style="text-align: left;">' +
				'<div>' + worker.GUIp_i18n.how_to_update + '</div>' +
				'<ol>' +
					worker.GUIp_i18n['help_update_' + worker.GUIp_browser] +
				'</ol>' +
				'<div>' + worker.GUIp_i18n.help_useful_links + '</div>' +
			'</div>' +
		'</div>' +
		'<div class="hint_bar_close"></div></div>'
	);

	if (ui_storage.get('helpDialogVisible')) { worker.$('#ui_help').show(); }
};
ui_help._createButtons = function() {
	var menu_bar = document.querySelector('#menu_bar ul');
	menu_bar.insertAdjacentHTML('beforeend', '| <li><a href="user/profile#ui_settings">' + worker.GUIp_i18n.ui_settings_top_menu + '</a></li> | <li></li>');
	ui_help._addToggleButton(menu_bar.lastElementChild, '<strong>' + worker.GUIp_i18n.ui_help + '</strong>');
	if (ui_storage.get('Option:enableDebugMode')) {
		ui_help._addDumpButton('<span>dump: </span>', 'all');
		ui_help._addDumpButton('<span>, </span>', 'options', 'Option');
		ui_help._addDumpButton('<span>, </span>', 'logger', 'Logger');
		ui_help._addDumpButton('<span>, </span>', 'forum', 'Forum');
		ui_help._addDumpButton('<span>, </span>', 'log', 'Log:');
	}
	ui_help._addToggleButton(document.getElementsByClassName('hint_bar_close')[0], worker.GUIp_i18n.close);
};
// gets toggle button
ui_help._addToggleButton = function(elem, text) {
	elem.insertAdjacentHTML('beforeend', '<a class="close_button">' + text + '</a>');
	elem.getElementsByClassName('close_button')[0].onclick = function() {
		ui_help.toggleDialog();
		return false;
	};
};
// gets dump button with a given label and selector
ui_help._addDumpButton = function(text, label, selector) {
	var hint_bar_content = document.getElementsByClassName('hint_bar_content')[0];
	hint_bar_content.insertAdjacentHTML('beforeend', text + '<a class="devel_link" id="dump_' + label + '">' + label + '</a>');
	document.getElementById('dump_' + label).onclick = function() {
		ui_storage.dump(selector);
	};
};
ui_help.toggleDialog = function(visible) {
	ui_storage.set('helpDialogVisible', !ui_storage.get('helpDialogVisible'));
	worker.$('#ui_help').slideToggle('slow');
};

// ui_storage
var ui_storage = window.wrappedJSObject ? createObjectIn(worker.GUIp, {defineAs: "storage"}) : worker.GUIp.storage = {};

ui_storage._get_key = function(key) {
	return 'GUIp_' + ui_data.god_name + ':' + key;
};
// gets diff with a value
ui_storage._diff = function(id, value) {
	var diff = null;
	var old = ui_storage.get(id);
	if (old !== null) {
		diff = value - old;
	}
	return diff;
};
// stores a value
ui_storage.set = function(id, value) {
	localStorage.setItem(ui_storage._get_key(id), value);
	return value;
};
// reads a value
ui_storage.get = function(id) {
	var val = localStorage.getItem(ui_storage._get_key(id));
	if (val === 'true') { return true; }
	if (val === 'false') { return false; }
	return val;
};
// stores value and gets diff with old
ui_storage.set_with_diff = function(id, value) {
	var diff = ui_storage._diff(id, value);
	ui_storage.set(id, value);
	return diff;
};
// dumps all values related to current god_name
ui_storage.dump = function(selector) {
	var lines = [],
		regexp = '^GUIp_' + (selector ? (ui_data.god_name + ':' + selector) : '');
	for (var key in localStorage) {
		if (key.match(regexp)) {
			lines.push(key + ' = ' + localStorage.getItem(key));
		}
	}
	lines.sort();
	worker.console.info('Godville UI+ log: Storage:\n' + lines.join('\n'));
};
// resets saved options
ui_storage.clear = function(what) {
	if (!what || !what.match(/^(?:GUIp|Godville|All)$/)) {
		if (worker.GUIp_locale === 'ru') {
			worker.console.log('Godville UI+: использование storage.clear:\n' +
							   'storage.clear("GUIp") для удаление только настроек Godville UI+\n' +
							   'storage.clear("Godville") для удаления настроек Годвилля, сохранив настройки Godville UI+\n' +
							   'storage.clear("All") для удаления всех настроек');
		} else {
			worker.console.log('Godville UI+: storage.clean usage:\n' +
							   'storage.clear("GUIp") to remove Godville UI+ setting only\n' +
							   'storage.clear("Godville") to remove Godville setting and keep Godville UI+ settings\n' +
							   'storage.clear("All") to remove all setting');
		}
		return;
	}
	for (var key in localStorage) {
		if (what === 'GUIp' && key.match(/^GUIp_/) ||
			what === 'Godville' && !key.match(/^GUIp_/) ||
			what === 'All') {
			localStorage.removeItem(key);
		}
	}
	location.reload();
};
ui_storage._rename = function(from, to) {
	for (var key in localStorage) {
		if (key.match(from)) {
			localStorage.setItem(key.replace(from, to), localStorage.getItem(key));
			localStorage.removeItem(key);
		}
	}
};
ui_storage._rename_nesw = function(from, to) {
	if (ui_storage.get('phrases_walk_' + from)) {
		ui_storage.set('CustomPhrases:go_' + to, ui_storage.get('phrases_walk_' + from));
		localStorage.removeItem(ui_storage._get_key('phrases_walk_' + from));
	}
};
ui_storage._delete = function(regexp) {
	for (var key in localStorage) {
		if (key.match(/^GUIp_/) && key.match(regexp)) {
			localStorage.removeItem(key);
		}
	}
};
ui_storage.migrate = function() {
	if (!localStorage.getItem('GUIp_migrated')) {
		ui_storage._rename(/^GM/, 'GUIp_');
		localStorage.setItem('GUIp_migrated', '141115');
	}
	if (localStorage.getItem('GUIp_migrated') < '150113') {
		ui_storage._rename_nesw('n', 'north');
		ui_storage._rename_nesw('e', 'east');
		ui_storage._rename_nesw('s', 'south');
		ui_storage._rename_nesw('w', 'west');
		ui_storage._rename(/:phrases_/, ':CustomPhrases:');
		localStorage.setItem('GUIp_migrated', '150113');
	}
	if (localStorage.getItem('GUIp_migrated') < '150228') {
		ui_storage._rename(/:thirdEye(.+)Entry/, ':ThirdEye:$1');
		localStorage.setItem('GUIp_migrated', '150228');
	}
	if (localStorage.getItem('GUIp_migrated') < '150419') {
		var forum;
		for (var i = 1; i <= (worker.GUIp_locale === 'ru' ? 6 : 4); i++) {
			forum = JSON.parse(ui_storage.get('Forum' + i));
			for (var topic in forum) {
				if (!isNaN(forum[topic])) {
					forum[topic] = { posts: forum[topic], date: 0 };
				}
			}
			ui_storage.set('Forum' + i, JSON.stringify(forum));
		}
		localStorage.setItem('GUIp_migrated', '150419');
	}
	if (localStorage.getItem('GUIp_migrated') < '150419_2') {
		var forum2;
		for (var key in localStorage) {
			if (key.match('Forum\\d')) {
				forum2 = JSON.parse(localStorage.getItem(key));
				for (var topic2 in forum2) {
					if (!isNaN(forum2[topic2])) {
						forum2[topic2] = { posts: forum2[topic2], date: 0 };
					}
				}
				localStorage.setItem(key, JSON.stringify(forum2));
			}
		}
		localStorage.setItem('GUIp_migrated', '150419_2');
	}
	if (localStorage.getItem('GUIp_migrated') < '150510') {
		ui_storage._delete(':Stats:');
		localStorage.setItem('GUIp_migrated', '150510');
	}
};

// ui_words
var ui_words = window.wrappedJSObject ? createObjectIn(worker.GUIp, {defineAs: "words"}) : worker.GUIp.words = {};

ui_words.currentPhrase = '';
// gets words from phrases.js file and splits them into sections
ui_words.init = function() {
	this.base = worker.GUIp_words();
	for (var sect in this.base.phrases) {
		var text = ui_storage.get('CustomPhrases:' + sect);
		if (text && text !== "") {
			this.base.phrases[sect] = text.split("||");
		}
	}
};
ui_words._changeFirstLetter = function(text) {
	return text.charAt(0).toLowerCase() + text.slice(1);
};
ui_words._addHeroName = function(text) {
	if (!ui_storage.get('Option:useHeroName')) { return text; }
	return ui_data.char_name + ', ' + ui_words._changeFirstLetter(text);
};
ui_words._addExclamation = function(text) {
	if (!ui_storage.get('Option:useExclamations')) { return text; }
	return ui_utils.getRandomItem(this.base.phrases.exclamation) + ', ' + ui_words._changeFirstLetter(text);
};
// single phrase gen
ui_words._randomPhrase = function(sect) {
	return ui_utils.getRandomItem(this.base.phrases[sect]);
};
ui_words._longPhrase_recursion = function(source, len) {
	while (source.length) {
		var next = ui_utils.popRandomItem(source);
		var remainder = len - next.length - 2; // 2 for ', '
		if (remainder > 0) {
			return [next].concat(ui_words._longPhrase_recursion(source, remainder));
		}
	}
	return [];
};
// main phrase constructor
ui_words.longPhrase = function(sect, item_name, len) {
	if (ui_storage.get('phrasesChanged')) {
		ui_words.init();
		ui_storage.set('phrasesChanged', 'false');
	}
	var prefix = ui_words._addHeroName(ui_words._addExclamation(''));
	var phrases;
	if (item_name) {
		phrases = [ui_words._randomPhrase(sect) + ' ' + item_name + '!'];
	} else if (ui_storage.get('Option:useShortPhrases') || sect.match(/go_/)) {
		phrases = [ui_words._randomPhrase(sect)];
	} else {
		phrases = ui_words._longPhrase_recursion(this.base.phrases[sect].slice(), (len || 100) - prefix.length);
	}
	this.currentPhrase = prefix ? prefix + ui_words._changeFirstLetter(phrases.join(' ')) : phrases.join(' ');
	return this.currentPhrase;
};
// inspect button phrase gen
ui_words.inspectPhrase = function(item_name) {
	return ui_words.longPhrase('inspect_prefix', item_name);
};
// craft button phrase gen
ui_words.craftPhrase = function(items) {
	return ui_words.longPhrase('craft_prefix', items);
};
// Checkers
ui_words.usableItemType = function(desc) {
	return this.base.usable_items.descriptions.indexOf(desc);
};

// ui_stats
var ui_stats = window.wrappedJSObject ? createObjectIn(worker.GUIp, {defineAs: "stats"}) : worker.GUIp.stats = {};

ui_stats.Bricks = function() {
	return worker.so.state.stats.bricks_cnt.value;
};
ui_stats.Charges =
ui_stats.Map_Charges =
ui_stats.Hero_Charges = function() {
	return worker.so.state.stats.accumulator.value;
};
ui_stats.Death = function() {
	return worker.so.state.stats.death_count.value;
};
ui_stats.Enemy_Gold = function() {
	return worker.so.state.o_stats.gold.value;
};
ui_stats.Enemy_HP = function() {
	var opps_hp = 0;
	for (var opp in worker.so.state.opps) {
		opps_hp += worker.so.state.opps[opp].hp;
	}
	return opps_hp;
};
ui_stats.Enemy_Inv = function() {
	return worker.so.state.o_stats.inventory_num.value;
};
ui_stats.Equip1 = function() {
	return +worker.so.state.equipment.weapon.level;
};
ui_stats.Equip2 = function() {
	return +worker.so.state.equipment.shield.level;
};
ui_stats.Equip3 = function() {
	return +worker.so.state.equipment.head.level;
};
ui_stats.Equip4 = function() {
	return +worker.so.state.equipment.body.level;
};
ui_stats.Equip5 = function() {
	return +worker.so.state.equipment.arms.level;
};
ui_stats.Equip6 = function() {
	return +worker.so.state.equipment.legs.level;
};
ui_stats.Equip7 = function() {
	return +worker.so.state.equipment.talisman.level;
};
ui_stats.Exp =
ui_stats.Map_Exp =
ui_stats.Hero_Exp = function() {
	return worker.so.state.stats.exp_progress.value;
};
ui_stats.Godpower = function() {
	return worker.so.state.stats.godpower.value;
};
ui_stats.Gold =
ui_stats.Map_Gold =
ui_stats.Hero_Gold = function() {
	return worker.so.state.stats.gold.value;
};
ui_stats.HP =
ui_stats.Map_HP =
ui_stats.Hero_HP = function() {
	return worker.so.state.stats.health.value;
};
ui_stats.Inv =
ui_stats.Map_Inv =
ui_stats.Hero_Inv = function() {
	return worker.so.state.stats.inventory_num.value;
};
ui_stats.Level = function() {
	return worker.so.state.stats.level.value;
};
ui_stats.Logs = function() {
	return parseFloat(worker.so.state.stats.wood.value)*10;
};
ui_stats.Map_Alls_HP =
ui_stats.Hero_Alls_HP = function() {
	var allies_hp = 0;
	for (var ally in worker.so.state.alls) {
		allies_hp += worker.so.state.alls[ally].hp;
	}
	return allies_hp;
};
ui_stats.Max_Godpower = function() {
	return worker.so.state.stats.max_gp.value;
};
ui_stats.Max_HP = function() {
	return worker.so.state.stats.max_health.value;
};
ui_stats.Monster = function() {
	return worker.so.state.stats.monsters_killed.value;
};
ui_stats.Pet_Level = function() {
	return worker.so.state.pet.pet_level && worker.so.state.pet.pet_level.value;
};
ui_stats.Task = function() {
	return worker.so.state.stats.quest_progress.value;
};
ui_stats.Task_Name = function() {
	return worker.so.state.stats.quest.value;
};
ui_stats.Savings = function() {
	return worker.so.state.stats.retirement && parseInt(worker.so.state.stats.retirement.value);
};
ui_stats.petIsKnockedOut = function() {
	return worker.so.state.pet.pet_is_dead && worker.so.state.pet.pet_is_dead.value;
};
ui_stats.charName = function() {
	return worker.so.state.stats.name.value;
};
ui_stats.godName = function() {
	return worker.so.state.stats.godname.value;
};
ui_stats.goldTextLength = function() {
	return worker.so.state.stats.gold_we.value.length;
};
ui_stats.heroHasPet = function() {
	return worker.so.state.has_pet;
};
ui_stats.isArenaAvailable = function() {
	return worker.so.state.arena_available();
};
ui_stats.isDungeon = function() {
	return worker.so.state.fight_type() === 'dungeon';
};
ui_stats.isDungeonAvailable = function() {
	return worker.so.state.dungeon_available();
};
ui_stats.isFight = function() {
	return worker.so.state.is_fighting();
};
ui_stats.isMale = function() {
	return worker.so.state.stats.gender.value === 'male';
};
ui_stats.monsterName = function() {
	return worker.so.state.stats.monster_name && worker.so.state.stats.monster_name.value;
};
ui_stats.logId = function() {
	return worker.so.state.stats.perm_link.value;
};
// ui_logger
var ui_logger = window.wrappedJSObject ? createObjectIn(worker.GUIp, {defineAs: "logger"}) : worker.GUIp.logger = {};

ui_logger.create = function() {
	this.updating = false;
	this.bar = worker.$('<ul id="logger" style="mask: url(#fader_masking);"/>');
	worker.$('#menu_bar').after(this.bar);
	this.need_separator = false;
	this.dungeonWatchers = [
		['Map_HP', 'hp', worker.GUIp_i18n.hero_health, 'hp'],
		['Map_Exp', 'exp', worker.GUIp_i18n.exp, 'exp'],
		['Map_Inv', 'inv', worker.GUIp_i18n.inventory, 'inv'],
		['Map_Gold', 'gld', worker.GUIp_i18n.gold, 'gold'],
		['Map_Charges', 'ch', worker.GUIp_i18n.charges, 'charges'],
		['Map_Alls_HP', 'a:hp', worker.GUIp_i18n.allies_health, 'allies']
	];
	this.battleWatchers = [
		['Hero_HP', 'h:hp', worker.GUIp_i18n.hero_health, 'hp'],
		['Enemy_HP', 'e:hp', worker.GUIp_i18n.enemy_health, 'death'],
		['Hero_Alls_HP', 'a:hp', worker.GUIp_i18n.allies_health, 'allies'],
		['Hero_Inv', 'h:inv', worker.GUIp_i18n.inventory, 'inv'],
		['Hero_Gold', 'h:gld', worker.GUIp_i18n.gold, 'gold'],
		['Hero_Charges', 'ch', worker.GUIp_i18n.charges, 'charges'],
		['Enemy_Gold', 'e:gld', worker.GUIp_i18n.gold, 'monster'],
		['Enemy_Inv', 'e:inv', worker.GUIp_i18n.inventory, 'monster']
	];
	this.fieldWatchers = [
		['Exp', 'exp', worker.GUIp_i18n.exp],
		['Level', 'lvl', worker.GUIp_i18n.level],
		['HP', 'hp', worker.GUIp_i18n.health],
		['Charges', 'ch', worker.GUIp_i18n.charges],
		['Task', 'tsk', worker.GUIp_i18n.task],
		['Monster', 'mns', worker.GUIp_i18n.monsters],
		['Inv', 'inv', worker.GUIp_i18n.inventory],
		['Gold', 'gld', worker.GUIp_i18n.gold],
		['Bricks', 'br', worker.GUIp_i18n.bricks],
		['Logs', 'wd', worker.GUIp_i18n.logs],
		['Savings', 'rtr', worker.GUIp_i18n.savings],
		['Equip1', 'eq1', worker.GUIp_i18n.weapon, 'equip'],
		['Equip2', 'eq2', worker.GUIp_i18n.shield, 'equip'],
		['Equip3', 'eq3', worker.GUIp_i18n.head, 'equip'],
		['Equip4', 'eq4', worker.GUIp_i18n.body, 'equip'],
		['Equip5', 'eq5', worker.GUIp_i18n.arms, 'equip'],
		['Equip6', 'eq6', worker.GUIp_i18n.legs, 'equip'],
		['Equip7', 'eq7', worker.GUIp_i18n.talisman, 'equip'],
		['Death', 'death', worker.GUIp_i18n.death_count],
		['Pet_Level', 'pet_level', worker.GUIp_i18n.pet_level, 'monster']
	];
	this.commonWatchers = [
		['Godpower', 'gp', worker.GUIp_i18n.godpower]
	];
};
ui_logger._appendStr = function(id, klass, str, descr) {
	// append separator if needed
	if (this.need_separator) {
		this.need_separator = false;
		if (this.bar.children().length > 0) {
			this.bar.append('<li class="separator">|</li>');
		}
	}
	// append string
	this.bar.append('<li class="' + klass + '" title="' + descr + '">' + str + '</li>');
	this.bar.scrollLeft(10000); //Dirty fix
	while (worker.$('#logger li').position().left + worker.$('#logger li').width() < 0 || worker.$('#logger li')[0].className === "separator") {
		worker.$('#logger li:first').remove();
	}
};
ui_logger._watchStatsValue = function(id, name, descr, klass) {
	klass = (klass || id).toLowerCase();
	var s, diff = ui_storage.set_with_diff('Logger:' + id, ui_stats[id]());
	if (diff) {
		// Если нужно, то преобразовываем в число с одним знаком после запятой
		if (parseInt(diff) !== diff) { diff = diff.toFixed(1); }
		// Добавление плюcа, минуса или стрелочки
		if (diff < 0) {
			if (name === 'exp' && +ui_storage.get('Logger:Level') !== ui_stats.Level()) {
				s = '→' + ui_stats.Exp();
			} else if (name === 'tsk' && ui_storage.get('Logger:Task_Name') !== ui_stats.Task_Name()) {
				ui_storage.set('Logger:Task_Name', ui_stats.Task_Name());
				s = '→' + ui_stats.Task();
			} else {
				s = diff;
			}
		} else {
			s = '+' + diff;
		}
		ui_logger._appendStr(id, klass, name + s, descr);
	}
};
ui_logger._updateWatchers = function(watchersList) {
	for (var i = 0, len = watchersList.length; i < len; i++) {
		ui_logger._watchStatsValue.apply(this, watchersList[i]);
	}
};
ui_logger.update = function() {
	if (ui_storage.get('Option:disableLogger')) {
		this.bar.hide();
		return;
	} else {
		this.bar.show();
	}
	if (ui_data.isDungeon) {
		ui_logger._updateWatchers(this.dungeonWatchers);
	} else if (ui_data.isFight) {
		ui_logger._updateWatchers(this.battleWatchers);
	} else {
		ui_logger._updateWatchers(this.fieldWatchers);
	}
	ui_logger._updateWatchers(this.commonWatchers);
	this.need_separator = true;
};

// ui_informer
var ui_informer = window.wrappedJSObject ? createObjectIn(worker.GUIp, {defineAs: "informer"}) : worker.GUIp.informer = {};

ui_informer.init = function() {
	//title saver
	this.title = document.title;
	//favicon saver
	this.favicon = document.querySelector('link[rel="shortcut icon"]');
	// container
	document.getElementById('main_wrapper').insertAdjacentHTML('afterbegin', '<div id="informer_bar" />');
	this.container = document.getElementById('informer_bar');
	// load
	ui_informer._load();
};
ui_informer._load = function() {
	this.flags = JSON.parse(ui_storage.get('informer_flags') || '{}');
	for (var flag in this.flags) {
		if (this.flags[flag]) {
			delete this.flags[flag];
		}
	}
	ui_informer._save();
};
ui_informer._save = function() {
	ui_storage.set('informer_flags', JSON.stringify(this.flags));
};
ui_informer._createLabel = function(flag) {
	var id = flag.replace(/ /g, '_');
	this.container.insertAdjacentHTML('beforeend', '<div id="' + id + '">' + flag + '</div>');
	document.getElementById(id).onclick = function() {
		ui_informer.hide(flag);
		return false;
	};
};
ui_informer._deleteLabel = function(flag) {
	var label = document.getElementById(flag.replace(/ /g, '_'));
	if (label) {
		this.container.removeChild(label);
	}
};
ui_informer._tick = function() {
	// пройти по всем флагам и выбрать те, которые надо показывать
	var activeFlags = [];
	for (var flag in this.flags) {
		if (this.flags[flag]) {
			activeFlags.push(flag);
		}
	}
	activeFlags.sort();

	// если есть чё, показать или вернуть стандартный заголовок
	if (activeFlags.length) {
		ui_informer._updateTitle(activeFlags);
		this.tref = worker.setTimeout(ui_informer._tick.bind(ui_informer), 700);
	} else {
		ui_informer.clearTitle();
		this.tref = 0;
	}
};
ui_informer.clearTitle = function() {
	for (var flag in this.flags) {
		if (this.flags[flag]) {
			return;
		}
	}
	document.title = ui_informer._getTitleNotices() + this.title;
	this.favicon.href = 'images/favicon.ico';
};
ui_informer._getTitleNotices = function() {
	var forbidden_title_notices = ui_storage.get('Option:forbiddenTitleNotices') || '';
	var titleNotices = (!forbidden_title_notices.match('pm') ? ui_informer._getPMTitleNotice() : '') +
					   (!forbidden_title_notices.match('gm') ? ui_informer._getGMTitleNotice() : '') +
					   (!forbidden_title_notices.match('fi') ? ui_informer._getFITitleNotice() : '');
	return titleNotices ? titleNotices + ' ' : '';
};
ui_informer._getPMTitleNotice = function() {
	var pm = 0,
		pm_badge = document.querySelector('.fr_new_badge_pos');
	if (pm_badge && pm_badge.style.display !== 'none') {
		pm = +pm_badge.textContent;
	}
	var stars = document.querySelectorAll('.msgDock .fr_new_msg');
	for (var i = 0, len = stars.length; i < len; i++) {
		if (!stars[i].parentNode.getElementsByClassName('dockfrname')[0].textContent.match(/Гильдсовет|Guild Council/)) {
			pm++;
		}
	}
	return pm ? '[' + pm + ']' : '';
};
ui_informer._getGMTitleNotice = function() {
	var gm = document.getElementsByClassName('gc_new_badge')[0].style.display !== 'none',
		stars = document.querySelectorAll('.msgDock .fr_new_msg');
	for (var i = 0, len = stars.length; i < len; i++) {
		if (stars[i].parentNode.getElementsByClassName('dockfrname')[0].textContent.match(/Гильдсовет|Guild Council/)) {
			gm = true;
			break;
		}
	}
	return gm ? '[g]' : '';
};
ui_informer._getFITitleNotice = function() {
	return document.querySelector('#forum_informer_bar a') ? '[f]' : '';
};
ui_informer._updateTitle = function(activeFlags) {
	this.odd_tick = !this.odd_tick;
	var sep = this.odd_tick ? '!!!' : '...';
	document.title = ui_informer._getTitleNotices() + sep + ' ' + activeFlags.join('! ') + ' ' + sep;
	if (worker.GUIp_browser !== 'Opera') {
		this.favicon.href = this.odd_tick ? 'images/favicon.ico'
										  : 'data:image/x-icon;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQEAYAAABPYyMiAAAABmJLR0T///////8JWPfcAAAACXBIWXMAAABIAAAASABGyWs+AAAAF0lEQVRIx2NgGAWjYBSMglEwCkbBSAcACBAAAeaR9cIAAAAASUVORK5CYII=';
	}
};
ui_informer.update = function(flag, value) {
	if (value && (flag === 'fight' || !(ui_data.isFight && !ui_data.isDungeon)) && !(ui_storage.get('Option:forbiddenInformers') &&
		ui_storage.get('Option:forbiddenInformers').match(flag.replace(/ /g, '_')))) {
		if (this.flags[flag] === undefined) {
			this.flags[flag] = true;
			ui_informer._createLabel(flag);
			ui_informer._save();
			if (!this.tref) {
				ui_informer._tick();
			}
		}
	} else if (this.flags[flag] !== undefined) {
		delete this.flags[flag];
		ui_informer._deleteLabel(flag);
		ui_informer._save();
	}
};
ui_informer.hide = function(flag) {
	this.flags[flag] = false;
	ui_informer._deleteLabel(flag);
	ui_informer._save();
};

// ui_forum
var ui_forum = window.wrappedJSObject ? createObjectIn(worker.GUIp, {defineAs: "forum"}) : worker.GUIp.forum = {};

ui_forum.init = function() {
	document.body.insertAdjacentHTML('afterbegin', '<div id="forum_informer_bar" />');
	ui_forum._check();
	worker.setInterval(ui_forum._check.bind(ui_forum), 5*60*1000);
};
ui_forum._check = function() {
	for (var forum_no = 1; forum_no <= (worker.GUIp_locale === 'ru' ? 6 : 4); forum_no++) {
		var current_forum = JSON.parse(ui_storage.get('Forum' + forum_no)),
			topics = [];
		for (var topic in current_forum) {
			// to prevent simultaneous ForumInformers access
			worker.setTimeout(ui_utils.getXHR.bind(ui_forum, '/forums/show/' + forum_no, ui_forum._parse.bind(ui_forum), undefined, forum_no), 500*forum_no);
			break;
		}
	}
};
ui_forum._process = function(forum_no) {
	var informers = JSON.parse(ui_storage.get('ForumInformers')),
		topics = JSON.parse(ui_storage.get('Forum' + forum_no));
	for (var topic in topics) {
		if (informers[topic]) {
			ui_forum._setInformer(topic, informers[topic], topics[topic].posts);
		}
	}
	ui_informer.clearTitle();
};
ui_forum._setInformer = function(topic_no, topic_data, posts_count) {
	var informer = document.getElementById('topic' + topic_no);
	if (!informer) {
		document.getElementById('forum_informer_bar').insertAdjacentHTML('beforeend',
			'<a id="topic' + topic_no + '" target="_blank"><span></span><div class="fr_new_badge"></div></a>'
		);
		informer = document.getElementById('topic' + topic_no);
		informer.onclick = function(e) {
			if (e.which === 1) {
				e.preventDefault();
			}
		};
		informer.onmouseup = function(e) {
			if (e.which === 1 || e.which === 2) {
				var informers = JSON.parse(ui_storage.get('ForumInformers'));
				delete informers[this.id.match(/\d+/)[0]];
				ui_storage.set('ForumInformers', JSON.stringify(informers));
				worker.$(this).slideToggle("fast", function() {
					if (this.parentElement) {
						this.parentElement.removeChild(this);
						ui_informer.clearTitle();
					}
				});
			}
		};
	}
	var page = Math.floor((posts_count - topic_data.diff)/25) + 1;
	informer.href = '/forums/show_topic/' + topic_no + '?page=' + page + '#guip_' + (posts_count - topic_data.diff + 25 - page*25);
	informer.style.paddingRight = (16 + String(topic_data.diff).length*6) + 'px';
	informer.getElementsByTagName('span')[0].textContent = topic_data.name;
	informer.getElementsByTagName('div')[0].textContent = topic_data.diff;
};
ui_forum._parse = function(xhr) {
	var diff, temp, old_diff, topic_name, posts, date, last_poster,
		topics = JSON.parse(ui_storage.get('Forum' + xhr.extra_arg)),
		informers = JSON.parse(ui_storage.get('ForumInformers'));
	for (var topic in topics) {
		temp = xhr.responseText.match("show_topic\\/" + topic + "[^\\d>]+>([^<]+)(?:.*?\\n*?)*?<td class=\"ca inv stat\">(\\d+)<\\/td>(?:.*?\\n*?)*?<abbr class=\"updated\" title=\"([^\"]+)(?:.*?\\n*?)*?<strong class=\"fn\">([^<]+)<\\/strong>(?:.*?\\n*?)*?show_topic\\/" + topic);
		if (temp) {
			topic_name = temp[1].replace(/&quot;/g, '"');
			posts = +temp[2];
			date = temp[3];
			last_poster = temp[4];

			diff = posts - topics[topic].posts;

			if (diff < 0 || diff === 0 && topics[topic].date && topics[topic].date !== date) {
				diff = 1;
			}

			topics[topic].posts = posts;
			topics[topic].date = date;

			if (diff > 0) {
				if (last_poster !== ui_data.god_name) {
					old_diff = informers[topic] ? informers[topic].diff : 0;
					informers[topic] = { diff: old_diff + diff, name: topic_name };
				} else {
					delete informers[topic];
				}
			}
		}
	}
	ui_storage.set('ForumInformers', JSON.stringify(informers));
	ui_storage.set('Forum' + xhr.extra_arg, JSON.stringify(topics));
	ui_forum._process(xhr.extra_arg);
};

// ui_improver
var ui_improver = window.wrappedJSObject ? createObjectIn(worker.GUIp, {defineAs: "improver"}) : worker.GUIp.improver = {};

ui_improver.improveTmt = 0;
ui_improver.isFirstTime = true;
ui_improver.voiceSubmitted = false;
ui_improver.wantedMonsters = null;
ui_improver.friendsRegExp = null;
ui_improver.windowResizeInt = 0;
ui_improver.mapColorizationTmt = 0;
// trophy craft combinations
ui_improver.b_b = [];
ui_improver.b_r = [];
ui_improver.r_r = [];
// dungeon
ui_improver.chronicles = {};
ui_improver.directionlessMoveIndex = 0;
ui_improver.dungeonPhrases = [
	'bossHint',
	'boss',
	'bonusGodpower',
	'bonusHealth',
	'trapUnknown',
	'trapTrophy',
	'trapGold',
	'trapLowDamage',
	'trapModerateDamage',
	'trapMoveLoss',
	'jumpingDungeon',
	'pointerMarker'
];
ui_improver.corrections = { n: 'north', e: 'east', s: 'south', w: 'west' };
ui_improver.pointerRegExp = new worker.RegExp('[^а-яa-z](северо-восток|северо-запад|юго-восток|юго-запад|' +
														'север|восток|юг|запад|' +
														'очень холодно|холодно|свежо|тепло|очень горячо|горячо|' +
														'north-east|north-west|south-east|south-west|' +
														'north|east|south|west|' +
														'freezing|very cold|cold|mild|warm|hot|burning|very hot|hot)', 'gi');
ui_improver.dungeonXHRCount = 0;
ui_improver.needLog = true;
// resresher
ui_improver.softRefreshInt = 0;
ui_improver.hardRefreshInt = 0;
ui_improver.softRefresh = function() {
	worker.console.info('Godville UI+ log: Soft reloading...');
	document.getElementById('d_refresh').click();
};
ui_improver.hardRefresh = function() {
	worker.console.warn('Godville UI+ log: Hard reloading...');
	location.reload();
};
ui_improver.improve = function() {
	this.improveInProcess = true;
	ui_informer.update('fight', ui_data.isFight && !ui_data.isDungeon);
	ui_informer.update('arena available', ui_stats.isArenaAvailable());
	ui_informer.update('dungeon available', ui_stats.isDungeonAvailable());

	this.optionsChanged = this.isFirstTime ? false : ui_storage.get('optionsChanged');
	if (this.isFirstTime) {
		if (!ui_data.isFight && !ui_data.isDungeon) {
			ui_improver.improveDiary();
		}
		if (ui_data.isDungeon) {
			ui_improver.getDungeonPhrases();
		}
	}
	ui_improver.improveStats();
	ui_improver.improvePet();
	ui_improver.improveVoiceDialog();
	if (!ui_data.isFight) {
		ui_improver.improveNews();
		ui_improver.improveEquip();
		ui_improver.improvePantheons();
	}
	if (ui_data.isDungeon) {
		ui_improver.improveMap();
	}
	ui_improver.improveInterface();
	ui_improver.improveChat();
	if (ui_data.isFight || ui_data.isDungeon) {
		ui_improver.improveAllies();
	}
	ui_improver.calculateButtonsVisibility();
	this.isFirstTime = false;
	this.improveInProcess = false;
	ui_storage.set('optionsChanged', false);
};
ui_improver.improveVoiceDialog = function() {
	if (this.isFirstTime || this.optionsChanged) {
		this.freezeVoiceButton = ui_storage.get('Option:freezeVoiceButton') || '';
	}
	// Add voicegens and show timeout bar after saying
	if (this.isFirstTime) {
		ui_utils.setVoiceSubmitState(this.freezeVoiceButton.match('when_empty'), true);
		worker.$(document).on('change keypress paste focus textInput input', '#god_phrase', function() {
			if (!ui_utils.setVoiceSubmitState(this.value && !(ui_improver.freezeVoiceButton.match('after_voice') && parseInt(ui_timeout.bar.style.width)), false)) {
				ui_utils.setVoiceSubmitState(ui_improver.freezeVoiceButton.match('when_empty'), true);
			}
			ui_utils.hideElem(document.getElementById('clear_voice_input'), !this.value);
		}).on('click', '.gv_text.div_link', function() {
			ui_utils.triggerChangeOnVoiceInput();
		});
		document.getElementById('voice_edit_wrap').insertAdjacentHTML('afterbegin', '<div id="clear_voice_input" class="div_link_nu gvl_popover hidden" title="' + worker.GUIp_i18n.clear_voice_input + '">×</div>');
		document.getElementById('clear_voice_input').onclick = function() {
			ui_utils.setVoice('');
		};
		document.getElementById('voice_submit').onclick = function() {
			ui_utils.hideElem(document.getElementById('clear_voice_input'), true);
			ui_improver.voiceSubmitted = true;
		};

			if (!ui_utils.isAlreadyImproved(document.getElementById('cntrl'))) {
			var gp_label = document.getElementsByClassName('gp_label')[0];
			gp_label.classList.add('l_capt');
			document.getElementsByClassName('gp_val')[0].classList.add('l_val');
			if (ui_data.isDungeon && document.getElementById('map')) {
				var isContradictions = document.getElementById('map').textContent.match(/Противоречия|Disobedience/);
				ui_utils.addVoicegen(gp_label, worker.GUIp_i18n.east, (isContradictions ? 'go_west' : 'go_east'), worker.GUIp_i18n.ask3 + ui_data.char_sex[0] + worker.GUIp_i18n.go_east);
				ui_utils.addVoicegen(gp_label, worker.GUIp_i18n.west, (isContradictions ? 'go_east' : 'go_west'), worker.GUIp_i18n.ask3 + ui_data.char_sex[0] + worker.GUIp_i18n.go_west);
				ui_utils.addVoicegen(gp_label, worker.GUIp_i18n.south, (isContradictions ? 'go_north' : 'go_south'), worker.GUIp_i18n.ask3 + ui_data.char_sex[0] + worker.GUIp_i18n.go_south);
				ui_utils.addVoicegen(gp_label, worker.GUIp_i18n.north, (isContradictions ? 'go_south' : 'go_north'), worker.GUIp_i18n.ask3 + ui_data.char_sex[0] + worker.GUIp_i18n.go_north);
			} else {
				if (ui_data.isFight) {
					ui_utils.addVoicegen(gp_label, worker.GUIp_i18n.defend, 'defend', worker.GUIp_i18n.ask4 + ui_data.char_sex[0] + worker.GUIp_i18n.to_defend);
					ui_utils.addVoicegen(gp_label, worker.GUIp_i18n.pray, 'pray', worker.GUIp_i18n.ask5 + ui_data.char_sex[0] + worker.GUIp_i18n.to_pray);
					ui_utils.addVoicegen(gp_label, worker.GUIp_i18n.heal, 'heal', worker.GUIp_i18n.ask6 + ui_data.char_sex[1] + worker.GUIp_i18n.to_heal);
					ui_utils.addVoicegen(gp_label, worker.GUIp_i18n.hit, 'hit', worker.GUIp_i18n.ask7 + ui_data.char_sex[1] + worker.GUIp_i18n.to_hit);
				} else {
					ui_utils.addVoicegen(gp_label, worker.GUIp_i18n.sacrifice, 'sacrifice', worker.GUIp_i18n.ask8 + ui_data.char_sex[1] + worker.GUIp_i18n.to_sacrifice);
					ui_utils.addVoicegen(gp_label, worker.GUIp_i18n.pray, 'pray', worker.GUIp_i18n.ask5 + ui_data.char_sex[0] + worker.GUIp_i18n.to_pray);
				}
			}
		}
	}
	//hide_charge_button
	var charge_button = document.querySelector('#cntrl .hch_link');
	charge_button.style.visibility = ui_storage.get('Option:hideChargeButton') ? 'hidden' : '';
	ui_informer.update('full godpower', ui_stats.Godpower() === ui_stats.Max_Godpower());
};
ui_improver.improveNews = function() {
	if (!ui_utils.isAlreadyImproved(document.getElementById('news'))) {
		ui_utils.addVoicegen(document.querySelector('#news .l_capt'), worker.GUIp_i18n.hit, 'hit', worker.GUIp_i18n.ask7 + ui_data.char_sex[1] + worker.GUIp_i18n.to_hit);
	}
	var isWantedMonster = false,
		isSpecialMonster = false,
		isTamableMonster = false;
	// Если герой дерется с монстром
	var currentMonster = ui_stats.monsterName();
	if (currentMonster) {
		isWantedMonster = this.wantedMonsters && currentMonster.match(this.wantedMonsters);
		isSpecialMonster = currentMonster.match(/Врачующий|Дарующий|Зажиточный|Запасливый|Кирпичный|Латающий|Лучезарный|Сияющий|Сюжетный|Линяющий|Bricked|Enlightened|Glowing|Healing|Holiday|Loaded|Questing|Shedding|Smith|Wealthy/);

		if (!ui_stats.heroHasPet) {
			var hasArk = ui_stats.Logs() >= 1000;
			var pet, hero_level = ui_stats.Level();
			for (var i = 0; i < ui_words.base.pets.length; i++) {
				pet = ui_words.base.pets[i];
				if (currentMonster.match(pet.name, 'i') && hero_level >= pet.min_level && hero_level <= (pet.min_level + (hasArk ? 28 : 14))) {
					isTamableMonster = true;
					break;
				}
			}
		}
	}

	ui_informer.update('wanted monster', isWantedMonster);
	ui_informer.update('special monster', isSpecialMonster);
	ui_informer.update('tamable monster', isTamableMonster);

	if (ui_data.hasTemple && this.optionsChanged) {
		ui_timers.layingTimerIsDisabled = ui_storage.get('Option:disableLayingTimer');
		ui_utils.hideElem(ui_timers.layingTimer, ui_timers.layingTimerIsDisabled);
		ui_timers.tick();
	}
};
ui_improver.MapIteration = function(MapThermo, iPointer, jPointer, step, kRow, kColumn) {
	step++;
	for (var iStep = -1; iStep <= 1; iStep++) {
		for (var jStep = -1; jStep <= 1; jStep++) {
			if (iStep !== jStep && (iStep === 0 || jStep === 0)) {
				var iNext = iPointer + iStep,
					jNext = jPointer + jStep;
				if (iNext >= 0 && iNext < kRow && jNext >= 0 && jNext < kColumn) {
					if (MapThermo[iNext][jNext] !== -1) {
						if (MapThermo[iNext][jNext] > step || MapThermo[iNext][jNext] === 0) {
							MapThermo[iNext][jNext] = step;
							ui_improver.MapIteration(MapThermo, iNext, jNext, step, kRow, kColumn);
						}
					}
				}
			}
		}
	}
};
ui_improver.improveMap = function() {
	if (this.isFirstTime) {
		document.getElementsByClassName('map_legend')[0].nextElementSibling.insertAdjacentHTML('beforeend',
			'<div class="guip_legend"><div class="dmc bossHint"></div><div> - ' + worker.GUIp_i18n.boss_warning_hint + '</div></div>' +
			'<div class="guip_legend"><div class="dmc boss"></div><div> - ' + worker.GUIp_i18n.boss_slay_hint + '</div></div>' +
			'<div class="guip_legend"><div class="dmc bonusGodpower"></div><div> - ' + worker.GUIp_i18n.small_prayer_hint + '</div></div>' +
			'<div class="guip_legend"><div class="dmc bonusHealth"></div><div> - ' + worker.GUIp_i18n.small_healing_hint + '</div></div>' +
			'<div class="guip_legend"><div class="dmc trapUnknown"></div><div> - ' + worker.GUIp_i18n.unknown_trap_hint + '</div></div>' +
			'<div class="guip_legend"><div class="dmc trapTrophy"></div><div> - ' + worker.GUIp_i18n.trophy_loss_trap_hint + '</div></div>' +
			'<div class="guip_legend"><div class="dmc trapLowDamage"></div><div> - ' + worker.GUIp_i18n.low_damage_trap_hint + '</div></div>' +
			'<div class="guip_legend"><div class="dmc trapModerateDamage"></div><div> - ' + worker.GUIp_i18n.moderate_damage_trap_hint + '</div></div>' +
			'<div class="guip_legend"><div class="dmc trapMoveLoss"></div><div> - ' + worker.GUIp_i18n.move_loss_trap_hint + '</div></div>' +
			'<div class="guip_legend"><div class="dmc bossHint trapMoveLoss"></div><div> - ' + worker.GUIp_i18n.boss_warning_and_trap_hint + '</div></div>' +
			'<div class="guip_legend"><div class="dmc boss trapMoveLoss"></div><div> - ' + worker.GUIp_i18n.boss_slay_and_trap_hint + '</div></div>'
		);
	}
	if (this.isFirstTime || this.optionsChanged) {
		var control = document.getElementById('m_control'),
			map = document.getElementById('map'),
			right_block = document.getElementById('a_right_block');
		if (ui_storage.get('Option:relocateMap')) {
			if (!document.querySelector('#a_central_block #map')) {
				control.parentNode.insertBefore(map, control);
				right_block.insertBefore(control, null);
				if (worker.GUIp_locale === 'ru') {
					document.querySelector('#m_control .block_title').textContent = 'Пульт';
				}
			}
		} else {
			if (!document.querySelector('#a_right_block #map')) {
				map.parentNode.insertBefore(control, map);
				right_block.insertBefore(map, null);
				if (worker.GUIp_locale === 'ru') {
					document.querySelector('#m_control .block_title').textContent = 'Пульт вмешательства в личную жизнь';
				}
			}
		}
	}
	if (document.querySelectorAll('#map .dml').length) {
		var i, j, len,
			$box = worker.$('#cntrl .voice_generator'),
			$boxML = worker.$('#map .dml'),
			$boxMC = worker.$('#map .dmc'),
			kRow = $boxML.length,
			kColumn = $boxML[0].textContent.length,
			isJumping = document.getElementById('map').textContent.match(/Прыгучести|Jumping/),
			MaxMap = 0,	// Счетчик указателей
			MapArray = []; // Карта возможного клада
		for (i = 0; i < kRow; i++) {
			MapArray[i] = [];
			for (j = 0; j < kColumn; j++) {
				MapArray[i][j] = ('?!@'.indexOf($boxML[i].textContent[j]) !== - 1) ? 0 : -1;
			}
		}
		// Гласы направления делаем невидимыми
		for (i = 0; i < 4; i++) {
			$box[i].style.visibility = 'hidden';
		}
		for (var si = 0; si < kRow; si++) {
			// Ищем где мы находимся
			j = $boxML[si].textContent.indexOf('@');
			if (j !== -1) {
				var chronicles = document.querySelectorAll('#m_fight_log .d_line'),
					isMoveLoss = [];
				len = +worker.Object.keys(this.chronicles).reverse()[0];
				for (i = 0; i < 4; i++) {
					isMoveLoss[i] = len > i && this.chronicles[len - i].marks.indexOf('trapMoveLoss') !== -1;
				}
				var directionsShouldBeShown = !isMoveLoss[0] || (isMoveLoss[1] && (!isMoveLoss[2] || isMoveLoss[3]));
				if (directionsShouldBeShown) {
					//	Проверяем куда можно пройти
					if ($boxML[si - 1].textContent[j] !== '#' || isJumping && (si === 1 || si !== 1 && $boxML[si - 2].textContent[j] !== '#')) {
						$box[0].style.visibility = '';	//	Север
					}
					if ($boxML[si + 1].textContent[j] !== '#' || isJumping && (si === kRow - 2 || si !== kRow - 2 && $boxML[si + 2].textContent[j] !== '#')) {
						$box[1].style.visibility = '';	//	Юг
					}
					if ($boxML[si].textContent[j - 1] !== '#' || isJumping && $boxML[si].textContent[j - 2] !== '#') {
						$box[2].style.visibility = '';	//	Запад
					}
					if ($boxML[si].textContent[j + 1] !== '#' || isJumping && $boxML[si].textContent[j + 2] !== '#') {
						$box[3].style.visibility = '';	//	Восток
					}
				}
			}
			//	Ищем указатели
			for (var sj = 0; sj < kColumn; sj++) {
				var ik, jk, ij, ttl,
					pointer = $boxML[si].textContent[sj];
				if ('←→↓↑↙↘↖↗↻↺↬↫⌊⌋⌈⌉∨<∧>'.indexOf(pointer) !== -1) {
					MaxMap++;
					$boxMC[si * kColumn + sj].style.color = 'green';
					ttl = $boxMC[si * kColumn + sj].title.replace(/северо-восток|north-east/,'↗')
														 .replace(/северо-запад|north-west/,'↖')
														 .replace(/юго-восток|south-east/,'↘')
														 .replace(/юго-запад|south-west/,'↙')
														 .replace(/север|north/,'↑')
														 .replace(/восток|east/,'→')
														 .replace(/юг|south/,'↓')
														 .replace(/запад|west/, '←');
					for (ij = 0, len = ttl.length; ij < len; ij++){
						if ('→←↓↑↘↙↖↗'.indexOf(ttl[ij]) !== - 1){
							for (ik = 0; ik < kRow; ik++) {
								for (jk = 0; jk < kColumn; jk++) {
									var istep = parseInt((Math.abs(jk - sj) - 1) / 5),
										jstep = parseInt((Math.abs(ik - si) - 1) / 5);
									if ('←→'.indexOf(ttl[ij]) !== -1 && ik >= si - istep && ik <= si + istep ||
										ttl[ij] === '↓' && ik >= si + istep ||
										ttl[ij] === '↑' && ik <= si - istep ||
										'↙↘'.indexOf(ttl[ij]) !== -1 && ik > si + istep ||
										'↖↗'.indexOf(ttl[ij]) !== -1 && ik < si - istep) {
										if (ttl[ij] === '→' && jk >= sj + jstep ||
											ttl[ij] === '←' && jk <= sj - jstep ||
											'↓↑'.indexOf(ttl[ij]) !== -1 && jk >= sj - jstep && jk <= sj + jstep ||
											'↘↗'.indexOf(ttl[ij]) !== -1 && jk > sj + jstep ||
											'↙↖'.indexOf(ttl[ij]) !== -1 && jk < sj - jstep) {
											if (MapArray[ik][jk] >= 0) {
												MapArray[ik][jk]++;
											}
										}
									}
								}
							}
						}
					}
				}
				if ('✺☀♨☁❄✵'.indexOf(pointer) !== -1) {
					MaxMap++;
					$boxMC[si * kColumn + sj].style.color = 'green';
					var ThermoMinStep = 0;	//	Минимальное количество шагов до клада
					var ThermoMaxStep = 0;	//	Максимальное количество шагов до клада
					switch(pointer) {
						case '✺': ThermoMinStep = 1; ThermoMaxStep = 2; break;	//	✺ - очень горячо(1-2)
						case '☀': ThermoMinStep = 3; ThermoMaxStep = 5; break;	//	☀ - горячо(3-5)
						case '♨': ThermoMinStep = 6; ThermoMaxStep = 9; break;	//	♨ - тепло(6-9)
						case '☁': ThermoMinStep = 10; ThermoMaxStep = 13; break;	//	☁ - свежо(10-13)
						case '❄': ThermoMinStep = 14; ThermoMaxStep = 18; break;	//	❄ - холодно(14-18)
						case '✵': ThermoMinStep = 19; ThermoMaxStep = 100; break;	//	✵ - очень холодно(19)
					}
					//	Временная карта возможных ходов
					var MapThermo = [];
					for (ik = 0; ik < kRow; ik++) {
						MapThermo[ik] = [];
						for (jk = 0; jk < kColumn; jk++) {
							MapThermo[ik][jk] = ($boxML[ik].textContent[jk] === '#' || ((Math.abs(jk - sj) + Math.abs(ik - si)) > ThermoMaxStep)) ? -1 : 0;
						}
					}
					//	Запускаем итерацию
					ui_improver.MapIteration(MapThermo, si, sj, 0, kRow, kColumn);
					//	Метим возможный клад
					for (ik = ((si - ThermoMaxStep) > 0 ? si - ThermoMaxStep : 0); ik <= ((si + ThermoMaxStep) < kRow ? si + ThermoMaxStep : kRow - 1); ik++) {
						for (jk = ((sj - ThermoMaxStep) > 0 ? sj - ThermoMaxStep : 0); jk <= ((sj + ThermoMaxStep) < kColumn ? sj + ThermoMaxStep : kColumn - 1); jk++) {
							if (MapThermo[ik][jk] >= ThermoMinStep & MapThermo[ik][jk] <= ThermoMaxStep) {
								if (MapArray[ik][jk] >= 0) {
									MapArray[ik][jk]++;
								}
							}
						}
					}
				}
			}
		}
		//	Отрисовываем возможный клад
		if (MaxMap !== 0) {
			for (i = 0; i < kRow; i++) {
				for (j = 0; j < kColumn; j++) {
					if (MapArray[i][j] === MaxMap) {
						$boxMC[i * kColumn + j].style.color = ($boxML[i].textContent[j] === '@') ? 'blue' : 'red';
					}
				}
			}
		}
	}
};
ui_improver.improveStats = function() {
	//	Парсер строки с золотом
	var gold_parser = function(val) {
		return parseInt(val.replace(/[^0-9]/g, '')) || 0;
	};

	if (ui_data.isDungeon) {
		if (ui_storage.get('Logger:Location') === 'Field') {
			ui_storage.set('Logger:Location', 'Dungeon');
			ui_storage.set('Logger:Map_HP', ui_stats.HP());
			ui_storage.set('Logger:Map_Exp', ui_stats.Exp());
			ui_storage.set('Logger:Map_Gold', ui_stats.Gold());
			ui_storage.set('Logger:Map_Inv', ui_stats.Inv());
			ui_storage.set('Logger:Map_Charges',ui_stats.Charges());
			ui_storage.set('Logger:Map_Alls_HP', ui_stats.Map_Alls_HP());
		}
		//ui_informer.update('low health', +ui_stats.Map_HP() < 130);
		return;
	}
	if (ui_data.isFight) {
		if (this.isFirstTime) {
			ui_storage.set('Logger:Hero_HP', ui_stats.HP());
			ui_storage.set('Logger:Hero_Gold', ui_stats.Gold());
			ui_storage.set('Logger:Hero_Inv', ui_stats.Inv());
			ui_storage.set('Logger:Hero_Charges', ui_stats.Charges());
			ui_storage.set('Logger:Enemy_HP', ui_stats.Enemy_HP());
			ui_storage.set('Logger:Enemy_Gold', ui_stats.Enemy_Gold());
			ui_storage.set('Logger:Enemy_Inv', ui_stats.Enemy_Inv());
			ui_storage.set('Logger:Hero_Alls_HP', ui_stats.Hero_Alls_HP());
		}
		//ui_informer.update('low health', +ui_stats.Hero_HP() < 130);
		return;
	}
	if (ui_storage.get('Logger:Location') !== 'Field') {
		ui_storage.set('Logger:Location', 'Field');
	}
	if (!ui_utils.isAlreadyImproved(document.getElementById('stats'))) {
		// Add voicegens
		ui_utils.addVoicegen(document.querySelector('#hk_level .l_capt'), worker.GUIp_i18n.study, 'exp', worker.GUIp_i18n.ask9 + ui_data.char_sex[1] + worker.GUIp_i18n.to_study);
		ui_utils.addVoicegen(document.querySelector('#hk_health .l_capt'), worker.GUIp_i18n.heal, 'heal', worker.GUIp_i18n.ask6 + ui_data.char_sex[1] + worker.GUIp_i18n.to_heal);
		ui_utils.addVoicegen(document.querySelector('#hk_gold_we .l_capt'), worker.GUIp_i18n.dig, 'dig', worker.GUIp_i18n.ask10 + ui_data.char_sex[1] + worker.GUIp_i18n.to_dig);
		ui_utils.addVoicegen(document.querySelector('#hk_quests_completed .l_capt'), worker.GUIp_i18n.cancel_task, 'cancel_task', worker.GUIp_i18n.ask11 + ui_data.char_sex[0] + worker.GUIp_i18n.to_cancel_task);
		ui_utils.addVoicegen(document.querySelector('#hk_quests_completed .l_capt'), worker.GUIp_i18n.do_task, 'do_task', worker.GUIp_i18n.ask12 + ui_data.char_sex[1] + worker.GUIp_i18n.to_do_task);
		ui_utils.addVoicegen(document.querySelector('#hk_death_count .l_capt'), worker.GUIp_i18n.die, 'die', worker.GUIp_i18n.ask13 + ui_data.char_sex[0] + worker.GUIp_i18n.to_die);
	}
	if (!document.querySelector('#hk_distance .voice_generator')) {
		ui_utils.addVoicegen(document.querySelector('#hk_distance .l_capt'), document.querySelector('#main_wrapper.page_wrapper_5c') ? '回' : worker.GUIp_i18n.return, 'town', worker.GUIp_i18n.ask14 + ui_data.char_sex[0] + worker.GUIp_i18n.to_return);
	}

	ui_informer.update('much gold', ui_stats.Gold() >= (ui_data.hasTemple ? 10000 : 3000));
	ui_informer.update('dead', ui_stats.HP() === 0);
	var questName = ui_stats.Task_Name();
	ui_informer.update('guild quest', questName.match(/членом гильдии|member of the guild/) && !questName.match(/\((отменено|cancelled)\)/));
	ui_informer.update('mini quest', questName.match(/\((мини|mini)\)/) && !questName.match(/\((отменено|cancelled)\)/));

	//Shovel pictogramm start
	var digVoice = document.querySelector('#hk_gold_we .voice_generator');
	if (this.isFirstTime) {
		digVoice.style.backgroundImage = 'url(' + worker.GUIp_getResource('images/shovel.png') + ')';
	}
	if (ui_stats.goldTextLength() > 16 - 2*document.getElementsByClassName('page_wrapper_5c').length) {
		digVoice.classList.add('shovel');
		if (ui_stats.goldTextLength() > 20 - 3*document.getElementsByClassName('page_wrapper_5c').length) {
			digVoice.classList.add('compact');
		} else {
			digVoice.classList.remove('compact');
		}
	} else {
		digVoice.classList.remove('shovel');
	}
	//Shovel pictogramm end
};
ui_improver.improvePet = function() {
	if (ui_data.isFight) {
		return;
	}
	var pet_badge;
	if (ui_stats.petIsKnockedOut()) {
		if (!ui_utils.isAlreadyImproved(document.getElementById('pet'))) {
			document.querySelector('#pet .block_title').insertAdjacentHTML('beforeend', '<div id="pet_badge" class="fr_new_badge equip_badge_pos hidden">0</div>');
		}
		pet_badge = document.getElementById('pet_badge');
		pet_badge.textContent = ui_utils.findLabel(worker.$('#pet'), worker.GUIp_i18n.pet_status_label).siblings('.l_val').text().replace(/[^0-9:]/g, '');
		ui_utils.hideElem(pet_badge, document.querySelector('#pet .block_content').style.display !== 'none');
	} else {
		pet_badge = document.getElementById('pet_badge');
		if (pet_badge) {
			ui_utils.hideElem(pet_badge, true);
		}
	}
	// knock out informer
	ui_informer.update('pet knocked out', ui_stats.petIsKnockedOut());
};
ui_improver.improveEquip = function() {
	if (!ui_utils.isAlreadyImproved(document.getElementById('equipment'))) {
		document.querySelector('#equipment .block_title').insertAdjacentHTML('afterend', '<div id="equip_badge" class="fr_new_badge equip_badge_pos">0</div>');
	}
	var equipBadge = document.getElementById('equip_badge'),
		averageEquipLevel = 0;
	for (var i = 1; i <= 7; i++) {
		averageEquipLevel += ui_stats['Equip' + i]();
	}
	averageEquipLevel = (averageEquipLevel/7).toFixed(1) + '';
	if (equipBadge.textContent !== averageEquipLevel) {
		equipBadge.textContent = averageEquipLevel;
	}
};
ui_improver.improvePantheons = function() {
	var pants = document.querySelector('#pantheons .block_content');
	if (this.isFirstTime) {
		pants.insertAdjacentHTML('afterbegin', '<div class="guip p_group_sep" />');
	}
	if (this.isFirstTime || this.optionsChanged) {
		var relocateDuelButtons = ui_storage.get('Option:relocateDuelButtons') || '';
		var arenaRelocated = relocateDuelButtons.match('arena'),
			arenaInPantheons = document.querySelector('#pantheons .arena_link_wrap');
		if (arenaRelocated && !arenaInPantheons) {
			pants.insertBefore(document.getElementsByClassName('arena_link_wrap')[0], pants.firstChild);
		} else if (!arenaRelocated && arenaInPantheons) {
			document.getElementById('cntrl2').insertBefore(arenaInPantheons, document.querySelector('#control .arena_msg'));
		}
		var chfRelocated = relocateDuelButtons.match('chf'),
			chfInPantheons = document.querySelector('#pantheons .chf_link_wrap');
		if (chfRelocated && !chfInPantheons) {
			pants.insertBefore(document.getElementsByClassName('chf_link_wrap')[0], document.getElementsByClassName('guip p_group_sep')[0]);
		} else if (!chfRelocated && chfInPantheons) {
			document.getElementById('cntrl2').insertBefore(chfInPantheons, document.querySelector('#control .arena_msg').nextSibling);
		}
	}
};
ui_improver.improveDiary = function() {
	var i, len;
	if (ui_improver.isFirstTime) {
		var $msgs = document.querySelectorAll('#diary .d_msg:not(.parsed)');
		for (i = 0, len = $msgs.length; i < len; i++) {
			$msgs[i].classList.add('parsed');
		}
	} else {
		var newMessages = worker.$('#diary .d_msg:not(.parsed)');
		if (newMessages.length) {
			if (ui_improver.voiceSubmitted) {
				if (newMessages.length - document.querySelectorAll('#diary .d_msg:not(.parsed) .vote_links_b').length >= 2) {
					ui_timeout.start();
				}
				ui_improver.voiceSubmitted = false;
			}
			newMessages.addClass('parsed');
		}
	}
	ui_improver.improvementDebounce();
};
ui_improver.parseDungeonPhrases = function(xhr) {
	for (var i = 0, temp, len = this.dungeonPhrases.length; i < len; i++) {
		temp = xhr.responseText.match(new worker.RegExp('<p>' + this.dungeonPhrases[i] + '\\b([\\s\\S]+?)<\/p>'))[1].replace(/&#8230;/g, '...').replace(/^<br>\n|<br>$/g, '').replace(/<br>\n/g, '|');
		this[this.dungeonPhrases[i] + 'RegExp'] = new worker.RegExp(temp);
		ui_storage.set('Dungeon:' + this.dungeonPhrases[i] + 'Phrases', temp);
	}
	ui_improver.improveChronicles();
};
ui_improver.getDungeonPhrases = function() {
	if (!ui_storage.get('Dungeon:pointerMarkerPhrases')) {
		this.dungeonXHRCount++;
		ui_utils.getXHR('/gods/' + (worker.GUIp_locale === 'ru' ? 'Спандарамет' : 'God Of Dungeons'), ui_improver.parseDungeonPhrases.bind(ui_improver));
	} else {
		for (var i = 0, temp, len = this.dungeonPhrases.length; i < len; i++) {
			this[this.dungeonPhrases[i] + 'RegExp'] = new worker.RegExp(ui_storage.get('Dungeon:' + this.dungeonPhrases[i] + 'Phrases'));
		}
		ui_improver.improveChronicles();
	}
};
ui_improver.parseSingleChronicle = function(texts, step) {
	if (!this.chronicles[step]) {
		this.chronicles[step] = { direction: null, marks: [], pointers: [], jumping: false, directionless: false, text: texts.join(' ') };
	}
	var i, len, j, len2, chronicle = this.chronicles[step];
	for (j = 0, len2 = texts.length; j < len2; j++) {
		texts[j] = texts[j].replace(/offered to trust h.. gut feeling\./, '');
		for (i = 0, len = this.dungeonPhrases.length - 1; i < len; i++) {
			if (texts[j].match(this[this.dungeonPhrases[i] + 'RegExp']) && chronicle.marks.indexOf(this.dungeonPhrases[i]) === -1) {
				chronicle.marks.push(this.dungeonPhrases[i]);
			}
		}
		var firstSentence = texts[j].match(/^.*?[\.!\?](?:\s|$)/);
		if (firstSentence) {
			var direction = firstSentence[0].match(/[^\wА-Яа-я](север|восток|юг|запад|north|east|south|west)/);
			if (direction) {
				chronicle.direction = direction[1];
			}
			chronicle.directionless = chronicle.directionless || !!firstSentence[0].match(/went somewhere|too busy bickering to hear in which direction to go next|The obedient heroes move in the named direction/);
			chronicle.jumping = chronicle.jumping || !!firstSentence[0].match(this.jumpingDungeonRegExp);
		}
	}
	if (texts.join(' ').match(this.pointerMarkerRegExp)) {
		var middle = texts.join(' ').match(/^.+?\.(.+)[.!?].+?[.!?]$/)[1];
		var pointer, pointers = middle.match(this.pointerRegExp);
		for (i = 0, len = pointers.length; i < len; i++) {
			switch (pointers[i].replace(/^./, '')) {
			case 'северо-восток':
			case 'north-east': pointer = 'north_east'; break;
			case 'северо-запад':
			case 'north-west': pointer = 'north_west'; break;
			case 'юго-восток':
			case 'south-east': pointer = 'south_east'; break;
			case 'юго-запад':
			case 'south-west': pointer = 'south_west'; break;
			case 'север':
			case 'north': pointer = 'north'; break;
			case 'восток':
			case 'east': pointer = 'east'; break;
			case 'юг':
			case 'south': pointer = 'south'; break;
			case 'запад':
			case 'west': pointer = 'west'; break;
			case 'очень холодно':
			case 'very cold':
			case 'freezing': pointer = 'freezing'; break;
			case 'холодно':
			case 'cold': pointer = 'cold'; break;
			case 'свежо':
			case 'mild': pointer = 'mild'; break;
			case 'тепло':
			case 'warm': pointer = 'warm'; break;
			case 'горячо':
			case 'hot': pointer = 'hot'; break;
			case 'очень горячо':
			case 'very hot':
			case 'burning': pointer = 'burning'; break;
			}
			if (chronicle.pointers.indexOf(pointer) === -1) {
				chronicle.pointers.push(pointer);
			}
		}
	}
};
ui_improver.parseChronicles = function(xhr) {
	this.needLog = false;
	this.dungeonXHRCount++;

	if (worker.Object.keys(this.chronicles)[0] === '1') {
		return;
	}

	var lastNotParsed, texts = [],
		step = 1,
		step_max = +worker.Object.keys(this.chronicles)[0],
		matches = xhr.responseText.match(/<div class="new_line" style='[^']*'>[\s\S]*?<div class="text_content .*?">[\s\S]+?<\/div>/g);
	worker.chronicles = matches;
	worker.response = xhr.responseText;
	for (var i = 0; step <= step_max; i++) {
		lastNotParsed = true;
		if (!matches[i].match(/<div class="text_content infl">/)) {
			texts.push(matches[i].match(/<div class="text_content ">([\s\S]+?)<\/div>/)[1].trim().replace(/&#39;/g, "'"));
		}
		if (matches[i].match(/<div class="new_line" style='[^']+'>/)) {
			ui_improver.parseSingleChronicle(texts, step);
			lastNotParsed = false;
			texts = [];
			step++;
		}
	}
	if (lastNotParsed) {
		ui_improver.parseSingleChronicle(texts, step);
	}

			worker.console.log('after log chronicles');
			worker.console.log(this.chronicles);
			worker.console.log(JSON.stringify(this.chronicles));

	ui_improver.colorDungeonMap();
};
ui_improver.calculateXY = function(cell) {
	var coords = {};
	coords.x = ui_utils.getNodeIndex(cell);
	coords.y = ui_utils.getNodeIndex(cell.parentNode);
	return coords;
};
ui_improver.calculateExitXY = function() {
	var exit_coords = { x: null, y: null },
		cells = document.querySelectorAll('.dml .dmc');
	for (var i = 0, len = cells.length; i < len; i++) {
		if (cells[i].textContent.trim().match(/В|E/)) {
			exit_coords = ui_improver.calculateXY(cells[i]);
			break;
		}
	}
	if (!exit_coords.x) {
		exit_coords = ui_improver.calculateXY(document.getElementsByClassName('map_pos')[0]);
	}
	return exit_coords;
};
ui_improver.deleteInvalidChronicles = function() {
	var isHiddenChronicles = true,
		chronicles = document.querySelectorAll('#m_fight_log .line.d_line');
	for (var i = chronicles.length - 1; i >= 0; i--) {
		if (isHiddenChronicles) {
			if (chronicles[i].style.display !== 'none') {
				isHiddenChronicles = false;
			}
		} else {
			if (chronicles[i].style.display === 'none') {
				chronicles[i].parentNode.removeChild(chronicles[i]);
			}
		}
	}
};
ui_improver.improveChronicles = function() {
	if (!ui_storage.get('Dungeon:pointerMarkerPhrases')) {
		if (this.dungeonXHRCount < 5) {
			ui_improver.getDungeonPhrases();
		}
	} else {
		var numberInBlockTitle = document.querySelector('#m_fight_log .block_title').textContent.match(/\d+/);
		if (!numberInBlockTitle) {
			return;
		}
		ui_improver.deleteInvalidChronicles();
		var i, len, lastNotParsed, texts = [],
			chronicles = document.querySelectorAll('#m_fight_log .d_msg:not(.parsed)'),
			ch_down = document.querySelector('.sort_ch').textContent === '▼',
			step = +numberInBlockTitle[0];
		worker.console.log('new ', chronicles.length, ' chronicles from step #', step);
		for (len = chronicles.length, i = ch_down ? 0 : len - 1; (ch_down ? i < len : i >= 0) && step; ch_down ? i++ : i--) {
			lastNotParsed = true;
			if (!chronicles[i].className.match('m_infl')) {
				texts = [chronicles[i].textContent].concat(texts);
			}
			if (chronicles[i].parentNode.className.match('turn_separator')) {
				ui_improver.parseSingleChronicle(texts, step);
				worker.console.log('chronicle #', step);
				worker.console.log(chronicles[i].textContent);
				lastNotParsed = false;
				texts = [];
				step--;
			}
			if (chronicles[i].textContent.match(this.bossHintRegExp)) {
				chronicles[i].parentNode.classList.add('bossHint');
			}
			chronicles[i].classList.add('parsed');
		}
		if (lastNotParsed) {
			ui_improver.parseSingleChronicle(texts, step);
		}
		worker.console.log('last step #', step);

		if (!this.initial) {
			this.initial = true;
			worker.console.log('initial chronicles');
			worker.console.log(this.chronicles);
			worker.console.log(JSON.stringify(this.chronicles));
		}

		if (this.needLog) {
			if (worker.Object.keys(this.chronicles)[0] === '1') {
				this.needLog = false;
				ui_improver.colorDungeonMap();
			} else if (this.dungeonXHRCount < 5) {
				ui_utils.getXHR('/duels/log/' + ui_stats.logId(), ui_improver.parseChronicles.bind(ui_improver));
			}
		}
		// informer
		ui_informer.update('close to boss', this.chronicles[worker.Object.keys(this.chronicles).reverse()[0]].marks.indexOf('bossHint') !== -1);

		if (ui_storage.get('Log:current') !== ui_stats.logId()) {
			ui_storage.set('Log:current', ui_stats.logId());
			ui_storage.set('Log:' + ui_stats.logId() + ':corrections', '');
		}
		ui_storage.set('Log:' + ui_stats.logId() + ':steps', (document.querySelector('#m_fight_log .block_title').textContent.match(/\d+/) || [0])[0]);
		ui_storage.set('Log:' + ui_stats.logId() + ':map', JSON.stringify(worker.so.state.d_map));
	}
	ui_improver.improvementDebounce();
};
ui_improver.moveCoords = function(coords, chronicle) {
	if (chronicle.direction) {
		var step = chronicle.jumping ? 2 : 1;
		switch(chronicle.direction) {
		case 'север':
		case 'north': coords.y -= step; break;
		case 'восток':
		case 'east': coords.x += step; break;
		case 'юг':
		case 'south': coords.y += step; break;
		case 'запад':
		case 'west': coords.x -= step; break;
		}
	}
};
ui_improver.calculateDirectionlessMove = function(initCoords, initStep) {
	var i, len, j, len2, temp, coords = { x: initCoords.x, y: initCoords.y },
		heroesCoords = ui_improver.calculateXY(document.getElementsByClassName('map_pos')[0]),
		directionless = 0;
	for (i = initStep, len = this.chronicles.length; i < len; i++) {
		if (this.chronicles[i].directionless) {
			directionless++;
		}
		ui_improver.moveCoords(coords, this.chronicles[i]);
	}
	var diff = { x: heroesCoords.x - coords.x, y: heroesCoords.y - coords.y };
	var first = '';
	while (diff.y < 0) {
		diff.y++;
		directionless--;
		first += 'n';
	}
	while (diff.x > 0) {
		diff.x--;
		directionless--;
		first += 'e';
	}
	while (diff.y > 0) {
		diff.y--;
		directionless--;
		first += 's';
	}
	while (diff.x < 0) {
		diff.x++;
		directionless--;
		first += 'w';
	}
	first = [first];
	while (directionless > 0) {
		directionless -= 2;
		temp = [];
		for (i = 0, len = first.length; i < len; i++) {
			temp.push(first[i] + 'ns');
			temp.push(first[i] + 'ew');
		}
		first = temp;
	}
	var second = [];
	for (i = 0, len = first.length; i < len; i++) {
		var last = first[i].split('').sort();
		second.push(last.join(''));
		// Narayana algorithm
		while (true) {
			// calculate k
			var k = last.length - 2;
			while (k >= 0 && last[k] >= last[k + 1]) {
				k--;
			}
			// exit if there's no more changes
			if (k === -1) {
				break;
			}
			// calculate t
			var t = last.length - 1;
			while (last[k] >= last[t] && t >= k + 1) {
				t--;
			}
			// swap k with t
			temp = last[k]; last[k] = last[t]; last[t] = temp;
			// reverse k+1..n
			last = last.slice(0, k + 1).concat(last.slice(k + 1).reverse());

			second.push(last.join(''));
		}
	}
	for (i = 0, len = second.length; i < len; i++) {
		coords = { x: initCoords.x, y: initCoords.y };
		directionless = 0;
		for (j = initStep, len2 = this.chronicles.length; j < len2; j++) {
			if (this.chronicles[j].directionless) {
				ui_improver.moveCoords(coords, { direction: this.corrections[second[i][directionless]] });
				directionless++;
			} else {
				ui_improver.moveCoords(coords, this.chronicles[j]);
			}
			if (document.querySelectorAll('#map .dml')[coords.y].children[coords.x].textContent.match(/#|!|\?/)) {
				break;
			}
		}
		if (heroesCoords.x - coords.x === 0 && heroesCoords.y - coords.y === 0) {
			ui_storage.set('Log:' + ui_stats.logId() + ':corrections', ui_storage.get('Log:' + ui_stats.logId() + ':corrections') + second[i]);
			return this.corrections[second[i][0]];
		}
	}
};
ui_improver.colorDungeonMap = function() {
	var step, mark_no, marks_length, currentCell,
		coords = ui_improver.calculateExitXY(),
		steps = worker.Object.keys(this.chronicles),
		steps_max = steps.length;
	for (step = 1; step <= steps_max; step++) {
		if (this.chronicles[step].directionless) {
			var shortCorrection = ui_storage.get('Log:' + ui_stats.logId() + ':corrections')[this.directionlessMoveIndex++];
			if (shortCorrection) {
				this.chronicles[step].direction = this.corrections[shortCorrection];
			} else {
				this.chronicles[step].direction = ui_improver.calculateDirectionlessMove(coords, step);
			}
			this.chronicles[step].directionless = false;
		}
		ui_improver.moveCoords(coords, this.chronicles[step]);
		currentCell = document.querySelectorAll('#map .dml')[coords.y].children[coords.x];
		for (mark_no = 0, marks_length = this.chronicles[step].marks.length; mark_no < marks_length; mark_no++) {
			currentCell.classList.add(this.chronicles[step].marks[mark_no]);
		}
		if (this.chronicles[step].pointers.length) {
			currentCell.title = worker.GUIp_i18n[this.chronicles[step].pointers[0]] + (this.chronicles[step].pointers[1] ? worker.GUIp_i18n.or + worker.GUIp_i18n[this.chronicles[step].pointers[1]] : '');
		}
	}
	var heroesCoords = ui_improver.calculateXY(document.getElementsByClassName('map_pos')[0]);
	if (heroesCoords.x !== coords.x || heroesCoords.y !== coords.y) {
		worker.console.log('current chronicles');
		worker.console.log(this.chronicles);
		worker.console.log(JSON.stringify(this.chronicles));
		worker.console.log('m_fight_log');
		worker.console.log(document.getElementById('m_fight_log').innerHTML);
		if (ui_utils.hasShownInfoMessage !== true) {
			ui_utils.showMessage('info', {
				title: 'Хера! Ошибка!',
				content: '<div>Кароч, разница координат: по x: ' + (heroesCoords.x - coords.x) + ', по y: ' + (heroesCoords.y - coords.y) + '.</div>'
			});
			ui_utils.hasShownInfoMessage = true;
		}
	}
};
ui_improver.whenWindowResize = function() {
	ui_improver.chatsFix();
	//body widening
	worker.$('body').width(worker.$(worker).width() < worker.$('#main_wrapper').width() ? worker.$('#main_wrapper').width() : '');
};
ui_improver.improveInterface = function() {
	if (this.isFirstTime) {
		worker.$('a[href=#]').removeAttr('href');
		ui_improver.whenWindowResize();
		worker.onresize = function() {
			worker.clearInterval(ui_improver.windowResizeInt);
			ui_improver.windowResizeInt = worker.setTimeout(ui_improver.whenWindowResize.bind(ui_improver), 250);
		};
		if (ui_data.isFight) {
			document.querySelector('#map .block_title, #control .block_title, #m_control .block_title').insertAdjacentHTML('beforeend', ' <a class="broadcast" href="/duels/log/' + ui_stats.logId() + '" target="_blank">' + worker.GUIp_i18n.broadcast + '</a>');
		}
	}
	if (this.isFirstTime || ui_storage.get('UserCssChanged') === true) {
		ui_storage.set('UserCssChanged', false);
		worker.GUIp_addCSSFromString(ui_storage.get('UserCss'));
	}

	if (localStorage.getItem('ui_s') !== ui_storage.get('ui_s')) {
		ui_storage.set('ui_s', localStorage.getItem('ui_s') || 'th_classic');
		this.Shovel = false;
		document.body.className = document.body.className.replace(/th_\w+/g, '') + ' ' + ui_storage.get('ui_s');
	}

	if (this.isFirstTime || this.optionsChanged) {
		var background = ui_storage.get('Option:useBackground');
		if (background === 'cloud') {
			document.body.style.backgroundImage = 'url(' + worker.GUIp_getResource('images/background.jpg') + ')';
		} else {
			document.body.style.backgroundImage = background ? 'url(' + background + ')' : '';
		}
	}
};
ui_improver.improveChat = function() {
	var i, len;

	// friends fetching
	var $friends = document.querySelectorAll('.frline .frname'),
		friends = [];
	for (i = 0, len = $friends.length; i < len; i++) {
		friends.push($friends[i].textContent);
	}
	this.friendsRegExp = new worker.RegExp('^(?:' + friends.join('|') + ')$');

	// links replacing and open chat with friend button adding
	var text, $msgs = document.querySelectorAll('.fr_msg_l:not(.improved)');
	for (i = 0, len = $msgs.length; i < len; i++) {
		text = $msgs[i].childNodes[0].textContent;
		$msgs[i].removeChild($msgs[i].childNodes[0]);
		$msgs[i].insertAdjacentHTML('afterbegin', '<span>' + ui_utils.escapeHTML(text).replace(/(https?:\/\/[^ \n\t]*[^\?\!\.\n\t\, ]+)/g, '<a href="$1" target="_blank" title="' + worker.GUIp_i18n.open_in_a_new_tab + '">$1</a>') + '</span>');

		var friend = $msgs[i].getElementsByClassName('gc_fr_god')[0];
		if (friend && friend.textContent.match(this.friendsRegExp)) {
			friend.insertAdjacentHTML('beforebegin', '<span class="gc_fr_oc gc_fr_page" title="' + worker.GUIp_i18n.open_chat_with + friend.textContent + '">[✎]</span>');
			$msgs[i].getElementsByClassName('gc_fr_oc')[0].onclick = ui_utils.openChatWith.bind(null, friend.textContent);
		}

		$msgs[i].classList.add('improved');
	}

	// godnames in gc paste fix
	worker.$('.gc_fr_god:not(.improved)').unbind('click').click(function() {
		var ta = this.parentNode.parentNode.parentNode.parentNode.parentNode.querySelector('textarea'),
			pos = ta.selectionDirection === 'backward' ? ta.selectionStart : ta.selectionEnd;
		ta.value = ta.value.slice(0, pos) + '@' + this.textContent + ', ' + ta.value.slice(pos);
		ta.focus();
		ta.selectionStart = ta.selectionEnd = pos + this.textContent.length + 3;
	}).addClass('improved');

	// "Shift+Enter → new line" improvement
	var keypresses, handlers,
	$tas = worker.$('.frInputArea textarea:not(.improved)');
	if ($tas.length) {
		var new_keypress = function(handlers) {
			return function(e) {
				if (e.which === 13 && !e.shiftKey) {
					for (var i = 0, len = handlers.length; i < len; i++) {
						handlers[i](e);
					}
				}
			};
		};
		for (i = 0, len = $tas.length; i < len; i++) {
			keypresses = worker.$._data($tas[i], 'events').keypress;
			handlers = [];
			for (var j = 0, klen = keypresses.length; j < klen; j++) {
				handlers.push(keypresses[j].handler);
			}
			$tas.eq(i).unbind('keypress').keypress(new_keypress(handlers));
		}
		$tas.addClass('improved');
		new_keypress = null;
	}
};
ui_improver.improveAllies = function() {
	var ally, opp_n, star;
	for (var number in worker.so.state.alls) {
		ally = worker.so.state.alls[number];
		opp_n = ally.li[0].getElementsByClassName('opp_n')[0];
		star = opp_n.getElementsByClassName('open_chat')[0] || document.createElement('a');
		if (!opp_n.classList.contains('improved')) {
			opp_n.classList.add('improved');
			opp_n.title = ally.god;
			opp_n.insertBefore(star, null);
			star.className = 'open_chat';
			star.title = worker.GUIp_i18n.open_chat_with + ally.god;
			star.textContent = '★';
			star.onclick = ui_utils.openChatWith.bind(null, ally.god);
		}
		ui_utils.hideElem(star, !ally.god.match(this.friendsRegExp));
	}
};
ui_improver.calculateButtonsVisibility = function() {
	var i, len, baseCond = ui_stats.Godpower() >= 5 && !ui_storage.get('Option:disableVoiceGenerators'),
		isMonster = ui_stats.monsterName();
	if (!ui_data.isFight) {
		// pantheon links
		var pantLinks = document.querySelectorAll('#pantheons .arena_link_wrap, #pantheons .chf_link_wrap'),
			pantBefore = [], pantAfter = [];
		for (i = 0, len = pantLinks.length; i < len; i++) {
			pantBefore[i] = !pantLinks[i].classList.contains('hidden');
			pantAfter[i] = ui_stats.Godpower() >= 50;
		}
		ui_improver.setButtonsVisibility(pantLinks, pantBefore, pantAfter);
		// inspect buttons
		var inspBtns = document.getElementsByClassName('inspect_button'),
			inspBtnsBefore = [], inspBtnsAfter = [];
		for (i = 0, len = inspBtns.length; i < len; i++) {
			inspBtnsBefore[i] = !inspBtns[i].classList.contains('hidden');
			inspBtnsAfter[i] = baseCond && !isMonster;
		}
		ui_improver.setButtonsVisibility(inspBtns, inspBtnsBefore, inspBtnsAfter);
		// craft buttons
		if (this.isFirstTime) {
			this.crftBtns = [document.getElementsByClassName('craft_button b_b')[0],
							 document.getElementsByClassName('craft_button b_r')[0],
							 document.getElementsByClassName('craft_button r_r')[0],
							 document.getElementsByClassName('craft_button span')[0]
							];
		}
		var crftBtnsBefore = [], crftBtnsAfter = [];
		for (i = 0, len = this.crftBtns.length; i < len; i++) {
			crftBtnsBefore[i] = !this.crftBtns[i].classList.contains('hidden');
			crftBtnsAfter[i] = baseCond && !isMonster;
		}
		crftBtnsAfter[0] = crftBtnsAfter[0] && ui_inventory.b_b.length;
		crftBtnsAfter[1] = crftBtnsAfter[1] && ui_inventory.b_r.length;
		crftBtnsAfter[2] = crftBtnsAfter[2] && ui_inventory.r_r.length;
		crftBtnsAfter[3] = crftBtnsAfter[0] || crftBtnsAfter[1] || crftBtnsAfter[2];
		ui_improver.setButtonsVisibility(this.crftBtns, crftBtnsBefore, crftBtnsAfter);
	}
	// voice generators
	if (this.isFirstTime) {
		this.voicegens = document.getElementsByClassName('voice_generator');
		this.voicegenClasses = [];
		for (i = 0, len = this.voicegens.length; i < len; i++) {
			this.voicegenClasses[i] = this.voicegens[i].className;
		}
	}
	var voicegensBefore = [], voicegensAfter = [],
		specialConds, specialClasses;
	if (!ui_data.isFight) {
		var isGoingBack = worker.so.state.stats.dir.value !== 'ft',
			isTown = worker.so.state.stats.town_name && worker.so.state.stats.town_name.value,
			isSearching = worker.so.state.last_news && worker.so.state.last_news.value.match('дорогу'),
			dieIsDisabled = ui_storage.get('Option:disableDieButton'),
			isFullGP = ui_stats.Godpower() === ui_stats.Max_Godpower(),
			isFullHP = ui_stats.HP() === ui_stats.Max_HP(),
			canQuestBeAffected = !ui_stats.Task_Name().match(/\((?:выполнено|completed|отменено|cancelled)\)/);
		specialClasses = ['heal', 'do_task', 'cancel_task', 'die', 'exp', 'dig', 'town', 'pray'];
		specialConds = [isMonster || isGoingBack || isTown || isSearching || isFullHP,				// heal
						isMonster || isGoingBack || isTown || isSearching || !canQuestBeAffected,	// do_task
																			 !canQuestBeAffected,	// cancel_task
						isMonster ||				isTown ||				 dieIsDisabled,			// die
						isMonster,																	// exp
						isMonster ||										 isTown,				// dig
						isMonster || isGoingBack || isTown ||				 isSearching,			// town
						isMonster ||										 isFullGP				// pray
					   ];
	}
	baseCond = baseCond && !worker.$('.r_blocked:visible').length;
	for (i = 0, len = this.voicegens.length; i < len; i++) {
		voicegensBefore[i] = !this.voicegens[i].classList.contains('hidden');
		voicegensAfter[i] = baseCond;
		if (baseCond && !ui_data.isFight) {
			for (var j = 0, len2 = specialConds.length; j < len2; j++) {
				if (specialConds[j] && this.voicegenClasses[i].match(specialClasses[j])) {
					voicegensAfter[i] = false;
				}
			}
		}
	}
	ui_improver.setButtonsVisibility(this.voicegens, voicegensBefore, voicegensAfter);
};
ui_improver.setButtonsVisibility = function(btns, before, after) {
	for (var i = 0, len = btns.length; i < len; i++) {
		if (before[i] && !after[i]) {
			ui_utils.hideElem(btns[i], true);
		}
		if (!before[i] && after[i]) {
			ui_utils.hideElem(btns[i], false);
		}
	}
};
ui_improver.chatsFix = function() {
	var i, len, cells = document.querySelectorAll('.frDockCell');
	for (i = 0, len = cells.length; i < len; i++) {
		cells[i].classList.remove('left');
		cells[i].style.zIndex = len - i;
		if (cells[i].getBoundingClientRect().right < 350) {
			cells[i].classList.add('left');
		}
	}
	//padding for page settings link
	var chats = document.getElementsByClassName('frDockCell'),
		clen = chats.length,
		padding_bottom = clen ? chats[0].getBoundingClientRect().bottom - chats[clen - 1].getBoundingClientRect().top : worker.GUIp_browser === 'Opera' ? 27 : 0,
		isBottom = worker.scrollY >= document.documentElement.scrollHeight - document.documentElement.clientHeight - 10;
	padding_bottom = Math.floor(padding_bottom*10)/10 + 10;
	padding_bottom = (padding_bottom < 0) ? 0 : padding_bottom + 'px';
	document.getElementsByClassName('reset_layout')[0].style.paddingBottom = padding_bottom;
	if (isBottom) {
		worker.scrollTo(0, document.documentElement.scrollHeight - document.documentElement.clientHeight);
	}
};
ui_improver.initSoundsOverride = function() {
	if (worker.so && worker.so.a_notify) {
		worker.so.a_notify_orig = worker.so.a_notify;
		worker.so.a_notify = function() {
			if (ui_storage.get('Option:disableArenaSound')) {
				if((worker.$(document.activeElement).is("input") || worker.$(document.activeElement).is("textarea")) &&
					worker.$(document.activeElement).attr("id") !== "god_phrase" &&
					worker.$(document.activeElement).val().length > 3) {
					var readyness = worker.confirm(worker.Loc.duel_switch_confirm);
					if (!readyness)  {
						return false;
					}
				}
				worker.setTimeout(function() {
					document.location.href = document.location.pathname;
				}, 3e3);
			} else {
				worker.so.a_notify_orig();
			}
		};
	}
	if (worker.so && worker.so.play_sound) {
		worker.so.play_sound_orig = worker.so.play_sound;
		worker.so.play_sound = function(a, b) {
			if (!(ui_storage.get('Option:disablePmSound') && a === 'msg.mp3')) {
				worker.so.play_sound_orig(a, b);
			}
		};
	}
};
ui_improver.activity = function() {
	if (!ui_logger.updating) {
		ui_logger.updating = true;
		worker.setTimeout(function() {
			ui_logger.updating = false;
		}, 500);
		ui_logger.update();
	}
};
ui_improver.improvementDebounce = function(mutations) {
	worker.clearTimeout(ui_improver.improveTmt);
	ui_improver.improveTmt = worker.setTimeout(function() {
		ui_improver.improve();
		if (ui_data.isFight) {
			ui_logger.update();
		}
	}, 250);
};

// ui_inventory
var ui_inventory = window.wrappedJSObject ? createObjectIn(worker.GUIp, {defineAs: "inventory"}) : worker.GUIp.inventory = {};

ui_inventory.observer = {
	config: {
		childList: true,
		attributes: true,
		subtree: true,
		attributeFilter: ['style']
	},
	func: function(mutations) {
		ui_observers.mutationChecker(mutations, function(mutation) {
			return mutation.target.tagName.toLowerCase() === 'li' && mutation.type === "attributes" &&
				   mutation.target.style.display === 'none' && mutation.target.parentNode ||
				   mutation.target.tagName.toLowerCase() === 'ul' && mutation.addedNodes.length;
		}, ui_inventory._update);
	},
	target: ['#inventory ul']
};
ui_inventory.init = function() {
	if (ui_data.isFight) {
		return;
	}
	ui_inventory._createCraftButtons();
	ui_inventory._update();
	ui_observers.start(ui_inventory.observer);
};
ui_inventory._createCraftButtons = function() {
	var invContent = document.querySelector('#inventory .block_content');
	invContent.insertAdjacentHTML('beforeend', '<span class="craft_button span">' + worker.GUIp_i18n.craft_verb + ':</span>');
	invContent.insertBefore(ui_inventory._createCraftButton(worker.GUIp_i18n.b_b, 'b_b', worker.GUIp_i18n.b_b_hint), null);
	invContent.insertBefore(ui_inventory._createCraftButton(worker.GUIp_i18n.b_r, 'b_r', worker.GUIp_i18n.b_r_hint), null);
	invContent.insertBefore(ui_inventory._createCraftButton(worker.GUIp_i18n.r_r, 'r_r', worker.GUIp_i18n.r_r_hint), null);
};
ui_inventory._createInspectButton = function(item_name) {
	var a = document.createElement('a');
	a.className = 'inspect_button';
	a.title = worker.GUIp_i18n.ask1 + ui_data.char_sex[0] + worker.GUIp_i18n.inspect + item_name;
	a.textContent = '?';
	a.onclick = ui_inventory._inspectButtonClick.bind(null, item_name);
	return a;
};
ui_inventory._inspectButtonClick = function(item_name) {
	ui_utils.setVoice(ui_words.inspectPhrase(worker.GUIp_i18n.trophy + item_name));
	return false;
};
ui_inventory._createCraftButton = function(combo, combo_list, hint) {
	var a = document.createElement('a');
	a.className = 'craft_button ' + combo_list;
	a.title = worker.GUIp_i18n.ask2 + ui_data.char_sex[0] + worker.GUIp_i18n.craft1 + hint + worker.GUIp_i18n.craft2;
	a.innerHTML = combo;
	a.onclick = ui_inventory._craftButtonClick.bind(null, combo_list);
	return a;
};
ui_inventory._craftButtonClick = function(combo_list) {
	var rand = Math.floor(Math.random()*ui_inventory[combo_list].length),
		items = ui_inventory[combo_list][rand];
	ui_utils.setVoice(ui_words.craftPhrase(items));
	return false;
};
ui_inventory._update = function() {
	var i, len, item, flags = [],
		bold_items = 0,
		trophy_boldness = {},
		forbidden_craft = ui_storage.get('Option:forbiddenCraft') || '';

	for (i = 0, len = ui_words.base.usable_items.types.length; i < len; i++) {
		flags[i] = false;
	}

	// Parse items
	for (var item_name in worker.so.state.inventory) {
		item = worker.so.state.inventory[item_name];
		// color items and add buttons
		if (item.description) { // usable item
			var sect = ui_words.usableItemType(item.description);
			bold_items++;
			if (sect !== -1) {
				flags[sect] = true;
			} else if (!ui_utils.hasShownInfoMessage) {
				ui_utils.hasShownInfoMessage = true;
				ui_utils.showMessage('info', {
					title: worker.GUIp_i18n.unknown_item_type_title,
					content: '<div>' + worker.GUIp_i18n.unknown_item_type_content + '<b>"' + item.description + '</b>"</div>'
				});
			}
			if (!(forbidden_craft.match('usable') || (forbidden_craft.match('b_b') && forbidden_craft.match('b_r')))) {
				trophy_boldness[item_name] = true;
			}
		} else if (item.type === 'heal_potion') { // healing item
			if (!item.isImproved) {
				item.li[0].classList.add('heal_item');
			}
			if (!(forbidden_craft.match('heal') || (forbidden_craft.match('b_r') && forbidden_craft.match('r_r')))) {
				trophy_boldness[item_name] = false;
			}
		} else {
			if (item.price === 101) { // bold item
				bold_items++;
				if (!(forbidden_craft.match('b_b') && forbidden_craft.match('b_r')) &&
					!item_name.match('золотой кирпич') && !item_name.match(' босса ')) {
					trophy_boldness[item_name] = true;
				}
			} else {
				if (!(forbidden_craft.match('b_r') && forbidden_craft.match('r_r')) &&
					!item_name.match('пушистого триббла')) {
					trophy_boldness[item_name] = false;
				}
			}
			if (!item.isImproved) {
				item.li[0].insertBefore(ui_inventory._createInspectButton(item_name), null);
			}
		}
		item.isImproved = true;
	}

	for (i = 0, len = flags.length; i < len; i++) {
		ui_informer.update(ui_words.base.usable_items.types[i], flags[i]);
	}
	ui_informer.update('transform!', flags[ui_words.base.usable_items.types.indexOf('transformer')] && bold_items >= 2);
	ui_informer.update('smelt!', flags[ui_words.base.usable_items.types.indexOf('smelter')] && ui_stats.Gold() >= 3000);

	ui_inventory._updateCraftCombos(trophy_boldness);
};
ui_inventory._updateCraftCombos = function(trophy_boldness) {
	// Склейка трофеев, формирование списков
	ui_inventory.b_b = [];
	ui_inventory.b_r = [];
	ui_inventory.r_r = [];
	var item_names = worker.Object.keys(trophy_boldness).sort(),
		forbidden_craft = ui_storage.get('Option:forbiddenCraft') || '';
	if (item_names.length) {
		for (var i = 0, len = item_names.length - 1; i < len; i++) {
			for (var j = i + 1; j < len + 1; j++) {
				if (item_names[i][0] === item_names[j][0]) {
					if (trophy_boldness[item_names[i]] && trophy_boldness[item_names[j]]) {
						if (!forbidden_craft.match('b_b')) {
							ui_inventory._pushItemCombo('b_b', item_names[i], item_names[j]);
						}
					} else if (!trophy_boldness[item_names[i]] && !trophy_boldness[item_names[j]]) {
						if (!forbidden_craft.match('r_r')) {
							ui_inventory._pushItemCombo('r_r', item_names[i], item_names[j]);
						}
					} else {
						if (!forbidden_craft.match('b_r')) {
							ui_inventory._pushItemCombo('b_r', item_names[i], item_names[j]);
						}
					}
				} else {
					break;
				}
			}
		}
	}
	ui_improver.calculateButtonsVisibility();
};
ui_inventory._pushItemCombo = function(combo, first, second) {
	ui_inventory[combo].push(first + worker.GUIp_i18n.and + second);
	ui_inventory[combo].push(second + worker.GUIp_i18n.and + first);
};
// ui_timers
var ui_timers = window.wrappedJSObject ? createObjectIn(worker.GUIp, {defineAs: "timers"}) : worker.GUIp.timers = {};

ui_timers.init = function() {
	if (ui_data.hasTemple) {
		document.querySelector('#imp_button').insertAdjacentHTML('afterend', '<div id=\"imp_timer\" class=\"fr_new_badge hidden\" />');
		if (!ui_data.isFight && !ui_data.isDungeon) {
			this.layingTimer = document.querySelector('#imp_timer');
			this.layingTimerIsDisabled = ui_storage.get('Option:disableLayingTimer');
			ui_utils.hideElem(this.layingTimer, this.layingTimerIsDisabled);
		}
		if (ui_data.isDungeon) {
			this.logTimer = document.querySelector('#imp_timer');
			this.logTimerIsDisabled = ui_storage.get('Option:disableLogTimer');
			ui_utils.hideElem(this.logTimer, this.logTimerIsDisabled);
		}
		ui_timers.tick();
		worker.setInterval(ui_timers.tick.bind(ui_timers), 60000);
	}
};
ui_timers.getDate = function(entry) {
	return ui_storage.get('ThirdEye:' + entry) ? new Date(ui_storage.get('ThirdEye:' + entry)) : 0;
};
ui_timers.tick = function() {
	this._lastLayingDate = ui_timers.getDate('LastLaying');
	this._lastLogDate = ui_timers.getDate('LastLog');
	this._penultLogDate = ui_timers.getDate('PenultLog');
	for (var msg in worker.so.state.diary_i) {
		var curEntryDate = new Date(worker.so.state.diary_i[msg].time);
		if (msg.match(/^(?:Возложила?|Выставила? тридцать золотых столбиков|I placed \w+? bags of gold)/) && curEntryDate > this._lastLayingDate) {
			this._lastLayingDate = curEntryDate;
		}
		var logs;
		if (msg.match(/^Выдержка из хроники подземелья:|Notes from the dungeon:/) && (logs = (msg.match(/бревно для ковчега|ещё одно бревно|log for the ark/g) || []).length)) {
			if (curEntryDate > this._lastLogDate) {
				while (logs--) {
					this._penultLogDate = this._lastLogDate;
					this._lastLogDate = curEntryDate;
				}
			} else if (curEntryDate < this._lastLogDate && curEntryDate > this._penultLogDate) {
				this._penultLogDate = curEntryDate;
			}
		}
		if (!this._latestEntryDate || this._latestEntryDate < curEntryDate) {
			this._latestEntryDate = curEntryDate;
		}
		if (!this._earliestEntryDate || this._earliestEntryDate > curEntryDate) {
			this._earliestEntryDate = curEntryDate;
		}
	}
	if (ui_timers.getDate('Latest') >= this._earliestEntryDate) {
		this._earliestEntryDate = ui_timers.getDate('Earliest');
		if (this._lastLayingDate) {
			ui_storage.set('ThirdEye:LastLaying', this._lastLayingDate);
		}
		if (this._lastLogDate) {
			ui_storage.set('ThirdEye:LastLog', this._lastLogDate);
		}
		if (this._penultLogDate) {
			ui_storage.set('ThirdEye:PenultLog', this._penultLogDate);
		}
	} else {
		ui_storage.set('ThirdEye:Earliest', this._earliestEntryDate);
		ui_storage.set('ThirdEye:LastLaying', this._lastLayingDate || '');
		ui_storage.set('ThirdEye:LastLog', this._lastLogDate || '');
		ui_storage.set('ThirdEye:PenultLog', this._penultLogDate || '');
	}
	ui_storage.set('ThirdEye:Latest', this._latestEntryDate);
	if (this.layingTimer && !this.layingTimerIsDisabled) {
		ui_timers._calculateTime(true, this._lastLayingDate);
	}
	if (this.logTimer && !this.logTimerIsDisabled) {
		ui_timers._calculateTime(false, this._penultLogDate);
	}
};
ui_timers._calculateTime = function(isLaying, fromDate) {
	var totalMinutes, greenHours = isLaying ? 36 : 24,
		yellowHours = isLaying ? 18 : 23;
	if (fromDate) {
		totalMinutes = Math.ceil((Date.now() + 1 - fromDate)/1000/60);
		ui_timers._setTimer(isLaying, totalMinutes, totalMinutes > greenHours*60 ? 'green' : totalMinutes > yellowHours*60 ? 'yellow' : 'red');
	} else {
		totalMinutes = Math.floor((Date.now() - this._earliestEntryDate)/1000/60);
		ui_timers._setTimer(isLaying, totalMinutes, totalMinutes > greenHours*60 ? 'green' : 'grey');
	}
};
ui_timers._formatTime = function(maxHours, totalMinutes) {
	var countdownMinutes = maxHours*60 - totalMinutes,
		hours = Math.floor(countdownMinutes/60),
		minutes = Math.floor(countdownMinutes%60);
	return (hours < 10 ? '0' : '') + hours + ':' + (minutes < 10 ? '0' : '') + minutes;
};
ui_timers._calculateExp = function(totalMinutes) {
	var baseExp = Math.min(totalMinutes/36/60*2, 2),
		amountMultiplier = [1, 2, 2.5],
		level = ui_stats.Level(),
		levelMultiplier = level < 100 ? 1 : level < 125 ? 0.5 : 0.25,
		title = [];
	for (var i = 1; i <= 3; i++) {
		title.push(i + '0k gld → ' + ((i + baseExp*amountMultiplier[i - 1])*levelMultiplier).toFixed(1) + '% exp');
	}
	return title.join('\n');
};
ui_timers._setTimer = function(isLaying, totalMinutes, color) {
	var timer = isLaying ? this.layingTimer : this.logTimer;
	timer.className = timer.className.replace(/green|yellow|red|grey/g, '');
	timer.classList.add(color);
	if (color === 'grey') {
		timer.textContent = '?';
		timer.title = (isLaying ? worker.GUIp_i18n.gte_unknown_penalty : worker.GUIp_i18n.log_unknown_time) + ui_timers._formatTime(isLaying ? 36 : 24, totalMinutes);
	} else {
		timer.textContent = color === 'green' ? isLaying ? '✓' : '木' : ui_timers._formatTime(isLaying ? 36 : 24, totalMinutes);
		timer.title = isLaying ? ui_timers._calculateExp(totalMinutes) : totalMinutes > 24*60 ? worker.GUIp_i18n.log_is_guaranteed : worker.GUIp_i18n.log_isnt_guaranteed;
	}
};
// ui_observers
var ui_observers = window.wrappedJSObject ? createObjectIn(worker.GUIp, {defineAs: "observers"}) : worker.GUIp.observers = {};

ui_observers.init = function() {
	for (var key in this) {
		if (this[key].condition) {
			ui_observers.start(this[key]);
		}
	}
};
ui_observers.start = function(obj) {
	for (var i = 0, len = obj.target.length; i < len; i++) {
		var target = document.querySelector(obj.target[i]);
		if (target) {
			var observer = new MutationObserver(obj.func);
			observer.observe(target, obj.config);
		}
	}
};
ui_observers.mutationChecker = function(mutations, check, callback) {
	var callbackRunRequired = false;
	for (var i = 0, len = mutations.length; i < len; i++) {
		if (check(mutations[i])) {
			callbackRunRequired = true;
			break;
		}
	}
	if (callbackRunRequired) {
		callback();
	}
};
ui_observers.chats = {
	condition: true,
	config: { childList: true },
	func: function(mutations) {
		for (var i = 0, len = mutations.length; i < len; i++) {
			if (mutations[i].addedNodes.length && !mutations[i].addedNodes[0].classList.contains('moved')) {
				var newNode = mutations[i].addedNodes[0];
				newNode.classList.add('moved');
				mutations[i].target.appendChild(newNode);
				var msgArea = newNode.querySelector('.frMsgArea');
				msgArea.scrollTop = msgArea.scrollTopMax || msgArea.scrollHeight;
			}
		}
		ui_observers.mutationChecker(mutations, function(mutation) {
			return mutation.addedNodes.length || mutation.removedNodes.length;
		}, function() { ui_improver.chatsFix(); ui_informer.clearTitle(); });
	},
	target: ['.chat_ph']
};
ui_observers.clearTitle = {
	condition: true,
	config: {
		childList: true,
		attributes: true,
		subtree: true,
		attributeFilter: ['style']
	},
	func: function(mutations) {
		ui_observers.mutationChecker(mutations, function(mutation) {
			return mutation.target.className.match(/fr_new_(?:msg|badge)/) ||
				  (mutation.target.className.match(/dockfrname_w/) && mutation.removedNodes.length && mutation.removedNodes[0].className.match(/fr_new_msg/));
		}, ui_informer.clearTitle.bind(ui_informer));
	},
	target: ['.msgDockWrapper']
};
ui_observers.refresher = {
	condition: true,
	config: {
		attributes: true,
		characterData: true,
		childList: true,
		subtree: true
	},
	func: function(mutations) {
		var toReset = false;
		for (var i = 0, len = mutations.length; i < len; i++) {
			var tgt = mutations[i].target,
				id = tgt.id,
				cl = tgt.className;
			if (!(id && id.match(/logger|pet_badge|equip_badge/)) &&
				!(cl && cl.match(/voice_generator|inspect_button|m_hover|craft_button/))) {
				toReset = true;
				break;
			}
		}
		if (toReset) {
			worker.clearInterval(ui_improver.softRefreshInt);
			worker.clearInterval(ui_improver.hardRefreshInt);
			if (!ui_storage.get('Option:disablePageRefresh')) {
				ui_improver.softRefreshInt = worker.setInterval(ui_improver.softRefresh, (ui_data.isFight || ui_data.isDungeon) ? 5e3 : 9e4);
				ui_improver.hardRefreshInt = worker.setInterval(ui_improver.hardRefresh, (ui_data.isFight || ui_data.isDungeon) ? 15e3 : 27e4);
			}
		}
	},
	target: ['#main_wrapper']
};
ui_observers.diary = {
	get condition() {
		return !ui_data.isFight && !ui_data.isDungeon;
	},
	config: { childList: true },
	func: function(mutations) {
		ui_observers.mutationChecker(mutations, function(mutation) { return mutation.addedNodes.length;	}, ui_improver.improveDiary);
	},
	target: ['#diary .d_content']
};
ui_observers.news = {
	get condition() {
		return !ui_data.isFight && !ui_data.isDungeon;
	},
	config: { childList: true, characterData: true, subtree: true },
	func: ui_improver.improvementDebounce,
	target: ['.f_news']
};
ui_observers.chronicles = {
	get condition() {
		return ui_data.isDungeon;
	},
	config: { childList: true },
	func: function(mutations) {
		ui_observers.mutationChecker(mutations, function(mutation) { return mutation.addedNodes.length;	}, ui_improver.improveChronicles.bind(ui_improver));
	},
	target: ['#m_fight_log .d_content']
};
ui_observers.map_colorization = {
	get condition() {
		return ui_data.isDungeon;
	},
	config: {
		childList: true,
		subtree: true
	},
	func: function(mutations) {
		ui_observers.mutationChecker(mutations, function(mutation) { return mutation.addedNodes.length;	}, ui_improver.colorDungeonMap.bind(ui_improver));
	},
	target: ['#map .block_content']
};
ui_observers.node_insertion = {
	condition: true,
	config: {
		childList: true,
		subtree: true
	},
	func: function(mutations) {
		ui_observers.mutationChecker(mutations, function(mutation) {
			// to prevent improving WHEN ENTERING FUCKING TEXT IN FUCKING TEXTAREA
			return mutation.addedNodes.length && mutation.addedNodes[0].nodeType !== 3;
		}, ui_improver.improvementDebounce);
	},
	target: ['body']
};
// ui_trycatcher
var ui_trycatcher = window.wrappedJSObject ? createObjectIn(worker.GUIp, {defineAs: "trycatcher"}) : worker.GUIp.trycatcher = {};

ui_trycatcher.replaceWithImproved = function(method) {
	return function() {
		try {
			return method.apply(this, arguments);
		} catch (error) {
			if (ui_storage.get('Option:enableDebugMode')) {
				ui_utils.processError(error, true);
			} else {
				ui_utils.checkVersion(ui_utils.processError.bind(null, error, false), ui_utils.informAboutOldVersion);
			}
		}
	};
};
ui_trycatcher.process = function(object) {
	var method_name, method;
	for (method_name in object) {
		method = object[method_name];
		if (typeof method === "function") {
			object[method_name] = ui_trycatcher.replaceWithImproved(method);
		}
	}
};

// ui_starter
var ui_starter = window.wrappedJSObject ? createObjectIn(worker.GUIp, {defineAs: "starter"}) : worker.GUIp.starter = {};

ui_starter._init = function() {
	ui_data.init();
	ui_storage.migrate();
	ui_utils.addCSS();
	ui_utils.inform();
	ui_words.init();
	ui_logger.create();
	ui_timeout.create();
	ui_help.init();
	ui_informer.init();
	ui_forum.init();
	ui_inventory.init();
	ui_improver.improve();
	ui_timers.init();
	ui_observers.init();
	ui_improver.initSoundsOverride();
};
ui_starter.start = function() {
	if (worker.$ && (worker.$('#m_info').length || worker.$('#stats').length) && worker.GUIp_browser && worker.GUIp_i18n && worker.GUIp_addCSSFromURL && worker.so.state) {
		worker.clearInterval(starterInt);
		worker.console.time('Godville UI+ initialized in');

		ui_starter._init();

		if (!ui_data.isFight) {
			worker.onmousemove = worker.onscroll = worker.ontouchmove = ui_improver.activity;
		}

		// svg for #logger fade-out in FF
		var is5c = document.getElementsByClassName('page_wrapper_5c').length;
		document.body.insertAdjacentHTML('beforeend',
			'<svg id="fader">' +
				'<defs>' +
					'<linearGradient id="gradient" x1="0" y1="0" x2 ="100%" y2="0">' +
						'<stop stop-color="black" offset="0"></stop>' +
						'<stop stop-color="white" offset="0.0' + (is5c ? '2' : '3') + '"></stop>' +
					'</linearGradient>' +
					'<mask id="fader_masking" maskUnits="objectBoundingBox" maskContentUnits="objectBoundingBox">' +
						'<rect x="0.0' + (is5c ? '2' : '3') + '" width="0.9' + (is5c ? '8' : '7') + '" height="1" fill="url(#gradient)" />' +
					'</mask>' +
				'</defs>' +
			'</svg>'
		);

		worker.console.timeEnd('Godville UI+ initialized in');
	}
};

// Main code
var objects = [ui_data, ui_utils, ui_timeout, ui_help, ui_storage, ui_words, ui_stats, ui_logger,
			   ui_informer, ui_forum, ui_improver, ui_inventory, ui_timers, ui_observers, ui_starter];
for (var i = 0, len = objects.length; i < len; i++) {
	ui_trycatcher.process(objects[i]);
}
for (var observer in ui_observers) {
	ui_trycatcher.process(ui_observers[observer]);
}
var starterInt = worker.setInterval(ui_starter.start.bind(ui_starter), 200);

})();