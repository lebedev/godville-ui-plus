(function() {
	'use strict';
	window.so.play_sound = function(a, b) {};
})();