(function() {
'use strict';

// base functions and variables initialization
window.GUIp = window.GUIp || {};

var doc = document;
var $id = function(id) {
	return doc.getElementById(id);
};
var $C = function(classname) {
	return doc.getElementsByClassName(classname);
};
var $c = function(classname) {
	return doc.getElementsByClassName(classname)[0];
};
var $Q = function(sel, el) {
	return (el || doc).querySelectorAll(sel);
};
var $q = function(sel, el) {
	return (el || doc).querySelector(sel);
};
var storage = {
	_getKey: function(key) {
		return "GUIp_" + this.god_name + ':' + key;
	},
	set: function(id, value) {
		localStorage.setItem(this._getKey(id), value);
		return value;
	},
	get: function(id) {
		var value = localStorage.getItem(this._getKey(id));
		if (value === 'true') { return true; }
		else if (value === 'false') { return false; }
		else { return value; }
	},
	god_name: ''
};
var addSmallElements = function() {
	var temp = $Q('.c2');
	for (i = 0, len = temp.length; i < len; i++) {
		if (!temp[i].querySelector('small')) {
			temp[i].insertAdjacentHTML('beforeend', '<small />');
		}
	}
};
var followOnclick = function(e) {
	try {
		e.preventDefault();
		var topic = isTopic ? location.pathname.match(/\d+/)[0]
							: this.parentElement.parentElement.querySelector('a').href.match(/\d+/)[0],
			posts = isTopic ? +$c('subtitle').textContent.match(/\d+/)[0]
							: +this.parentElement.parentElement.nextElementSibling.textContent,
			dates = isTopic ? document.getElementsByTagName('abbr')
							: null,
			date =  isTopic ? document.getElementsByClassName('disabled next_page').length ? dates[dates.length - 1].title : 0
							: this.parentElement.parentElement.parentElement.getElementsByTagName('abbr')[0].title,
			topics = JSON.parse(storage.get(forum_no));
		topics[topic] = { posts: posts, date: date };
		storage.set(forum_no, JSON.stringify(topics));
		this.style.display = 'none';
		this.parentElement.querySelector('.unfollow').style.display = 'inline';
	} catch(error) {
		console.error(error);
	}
};
var addOnclickToFollow = function() {
	var follow_links = $Q('.follow');
	for (i = 0, len = follow_links.length; i < len; i++) {
		follow_links[i].onclick = followOnclick;
	}
};
var unfollowOnclick = function(e) {
	try {
		e.preventDefault();
		var topic = isTopic ? location.pathname.match(/\d+/)[0]
							: this.parentElement.parentElement.querySelector('a').href.match(/\d+/)[0],
			topics = JSON.parse(storage.get(forum_no)),
			informers = JSON.parse(storage.get('ForumInformers'));
		delete topics[topic];
		storage.set(forum_no, JSON.stringify(topics));
		delete informers[topic];
		storage.set('ForumInformers', JSON.stringify(informers));
		this.style.display = 'none';
		this.parentElement.querySelector('.follow').style.display = 'inline';
	} catch(error) {
		console.error(error);
	}
};
var addOnclickToUnfollow = function() {
	var unfollow_links = $Q('.unfollow');
	for (i = 0, len = unfollow_links.length; i < len; i++) {
		unfollow_links[i].onclick = unfollowOnclick;
	}
};
var addLinks = function() {
	var links_containers;
	if (isTopic) {
		links_containers = $Q('#topic_mod');
	} else {
		links_containers = $Q('.c2 small');
	}
	for (i = 0, len = links_containers.length; i < len; i++) {
		topic = isTopic ? location.pathname.match(/\d+/)[0]
						: links_containers[i].parentElement.getElementsByTagName('a')[0].href.match(/\d+/)[0];
		var isFollowed = topics[topic] !== undefined;
		links_containers[i].insertAdjacentHTML('beforeend',
			(isTopic ? '(' : '\n') + '<a class="follow" href="#" style="display: ' + (isFollowed ? 'none' : 'inline') + '">' + (isTopic ? GUIp.i18n.Subscribe : GUIp.i18n.subscribe) + '</a>' +
									 '<a class="unfollow" href="#" style="display: ' + (isFollowed ? 'inline' : 'none') + '">' + (isTopic ? GUIp.i18n.Unsubscribe : GUIp.i18n.unsubscribe) + '</a>' + (isTopic ? ')' : '')
		);
	}
	addOnclickToFollow();
	addOnclickToUnfollow();
};

// topic formatting
var val, ss, se, nls, nle, selection;
var initEditor = function(editor) {
	val = editor.value;
	ss = editor.selectionStart;
	se = editor.selectionEnd;
	selection = getSelection().isCollapsed ? '' : getSelection().toString().trim().replace(/\n[\n\s]*/g, '<br>');
};
var putSelectionTo = function(editor, pos, quoting) {
	setTimeout(function() {
		editor.focus();
		editor.selectionStart = editor.selectionEnd = pos + (quoting ? selection.length : 0);
	}, 50);
};
var basicFormatting = function(left_and_right, editor) {
	try {
		initEditor(editor);
		while (ss < se && val[ss].match(/\s/)) {
			ss++;
		}
		while (ss < se && val[se - 1].match(/\s/)) {
			se--;
		}
		editor.value = val.slice(0, ss) + (val && val[ss - 1] && val[ss - 1].match(/[a-zA-Zа-яА-ЯёЁ]/) ? ' ' : '') + left_and_right[0] + val.slice(ss, se) + selection + left_and_right[1] + (val && val [se] && val[se].match(/[a-zA-Zа-яА-ЯёЁ]/) ? ' ' : '') + val.slice(se);
		putSelectionTo(editor, se + left_and_right[0].length, true);
		return false;
	} catch(error) {
		console.error(error);
	}
};
var quoteFormatting = function(quotation, editor) {
	try {
		initEditor(editor);
		nls = val && val[ss - 1] && !val[ss - 1].match(/\n/) ? '\n\n' : (val[ss - 2] && !val[ss - 2].match(/\n/) ? '\n' : '');
		nle = ss !== se && val ? ((val[se] && !val[se].match(/\n/) || !val[se]) ? '\n\n'
																				: (val[se + 1] && !val[se + 1].match(/\n/) ? '\n'
																														   : ''))
							   : '' +
			  selection ? (!selection[selection.length - 1].match(/\n/) ? '\n\n'
																		: (selection && selection[selection.length - 2] && !selection[selection.length - 2].match(/\n/) ? '\n'
																																										: ''))
						: '';
		editor.value = val.slice(0, ss) + nls + quotation + val.slice(ss, se) + selection + nle + val.slice(se);
		putSelectionTo(editor, se + quotation.length + nls.length + (se > ss || selection ? nle.length : 0), true);
		return false;
	} catch(error) {
		console.error(error);
	}
};
var listFormatting = function(list_marker, editor) {
	try {
		initEditor(editor);
		nls = val && val[ss - 1] && !val[ss - 1].match(/\n/) ? '\n' : '';
		nle = val && val[se] && !val[se].match(/\n/) ? '\n\n' : (val[se + 1] && !val[se + 1].match(/\n/) ? '\n' : '');
		var count = val.slice(ss, se).match(/\n/g) ? val.slice(ss, se).match(/\n/g).length + 1 : 1;
		editor.value = val.slice(0, ss) + nls + list_marker + ' ' + val.slice(ss, se).replace(/\n/g, '\n' + list_marker + ' ') + nle + val.slice(se);
		putSelectionTo(editor, se + nls.length + (list_marker.length + 1)*count, true);
		return false;
	} catch(error) {
		console.error(error);
	}
};
var pasteBr = function(dummy, editor) {
	try {
		initEditor(editor);
		var pos = editor.selectionDirection === 'backward' ? ss : se;
		editor.value = val.slice(0, pos) + '<br>' + val.slice(pos);
		putSelectionTo(editor, pos + 4, true);
		return false;
	} catch(error) {
		console.error(error);
	}
};
var setClickActions = function(id, container) {
	var elem, temp = '#' + id + ' .formatting.',
		buttons = [
			{ class: 'bold', func: basicFormatting, params: ['*', '*'] },
			{ class: 'underline', func: basicFormatting, params: ['+', '+'] },
			{ class: 'strike', func: basicFormatting, params: ['-', '-'] },
			{ class: 'italic', func: basicFormatting, params: ['_', '_'] },
			{ class: 'godname', func: basicFormatting, params: ['"', '":пс'] },
			{ class: 'link', func: basicFormatting, params: ['"', '":'] },
			{ class: 'sup', func: basicFormatting, params: ['^', '^'] },
			{ class: 'sub', func: basicFormatting, params: ['~', '~'] },
			{ class: 'monospace', func: basicFormatting, params: ['@', '@'] },
			{ class: 'bq', func: quoteFormatting, params: 'bq. ' },
			{ class: 'bc', func: quoteFormatting, params: 'bc. ' },
			{ class: 'ul', func: listFormatting, params: '*' },
			{ class: 'ol', func: listFormatting, params: '#' },
			{ class: 'br', func: pasteBr, params: null },
		];
	for (i = 0, len = buttons.length; i < len; i++) {
		if ((elem = $q(temp + buttons[i].class))) {
			elem.onclick = buttons[i].func.bind(this, buttons[i].params, container);
		}
	}
};
var setCtrlEnterAction = function(textarea, button) {
	textarea.onkeydown = function(e) {
		if (e.ctrlKey && e.keyCode === 13) {
			e.preventDefault();
			button.click();
		}
	};
};
var initSmartQuotation = function() {
	document.body.insertAdjacentHTML('beforeend', '<div id="quote_button"><div id="copy" title="Скопировать цитату"></div><div id="quote" title="' + GUIp.i18n.quote_hint + '"></div><div id="quote_with_author" title="' + GUIp.i18n.quote_with_author_hint + '">+</div></div>');

	var quoteButton = document.getElementById('quote_button');

	$q('#copy', quoteButton).style.backgroundImage = 'url(' + GUIp.getResource('images/copy.png') + ')';
	$q('#quote', quoteButton).style.backgroundImage =
	$q('#quote_with_author', quoteButton).style.backgroundImage = 'url(' + GUIp.getResource('images/quote.png') + ')';

	document.onmouseup = function() {
		quoteButton.classList.remove('shown');
		setTimeout(setupQuoteDialog, 50);
	};

	var setupQuoteDialog = function() {
		var selection = window.getSelection(),
			range = selection.getRangeAt(0),
			container = range.commonAncestorContainer;
		if (container.nodeType === 3) {
			container = container.parentElement;
		}
		container.classList.add('current_selection_container');
		if ((document.querySelector('.body.entry-content.current_selection_container') || document.querySelector('.body.entry-content .current_selection_container')) && selection.toString().length > 2) {
			var rect = range.getBoundingClientRect(),
				qbRect = window.qbRect = quoteButton.getBoundingClientRect(),
			    leftOffset = (rect.left + rect.right)/2 - (qbRect.right - qbRect.left)/2,
			    topOffset = window.pageYOffset + rect.top - (qbRect.bottom - qbRect.top) - 5;
			quoteButton.style.left = leftOffset + 'px';
			quoteButton.style.top = topOffset + 'px';
			quoteButton.classList.add('shown');

			document.getElementById('copy').onclick = function() {
				// TODO: copy to clipboard.
			};
			document.getElementById('quote').onclick = function() {
				var editor, init;
				if (document.getElementById('edit').style.display !== 'none' && document.getElementById('edit_body')) {
					editor = document.getElementById('edit_body');
				} else {
					editor = document.getElementById('post_body');
					if (document.getElementById('reply').style.display === 'none') {
						ReplyForm.init();
					}
				}
				quoteFormatting('bq. ', editor);
				getSelection().collapseToStart();
				return false;
			};
			document.getElementById('quote_with_author').onclick = function() {
				var editor;
				if (document.getElementById('edit').style.display !== 'none' && document.getElementById('edit_body')) {
					editor = document.getElementById('edit_body');
				} else {
					editor = document.getElementById('post_body');
					if (document.getElementById('reply').style.display === 'none') {
						ReplyForm.init();
					}
				}
				quoteFormatting('bq. ', editor);

				var findPost = function(el) {
					do {
						el = el.parentNode;
					} while (!el.classList.contains('post'));
					return el;
				};

				var post = findPost(container),
					author = post.querySelector('.post_info a').textContent;
				setTimeout(ReplyForm.add_name.bind(null, author), 100);
				getSelection().collapseToStart();
				return false;
			};
		}
		container.classList.remove('current_selection_container');
	};
};
var addFormattingButtonsAndCtrlEnter = function() {
	var formatting_buttons =
		'<div>' +
			'<button class="formatting button bold" title="' + GUIp.i18n.bold_hint + '">' + GUIp.i18n.bold + '</button>' +
			'<button class="formatting button underline" title="' + GUIp.i18n.underline_hint + '">' + GUIp.i18n.underline + '</button>' +
			'<button class="formatting button strike" title="' + GUIp.i18n.strike_hint + '">' + GUIp.i18n.strike + '</button>' +
			'<button class="formatting button italic" title="' + GUIp.i18n.italic_hint + '">' + GUIp.i18n.italic + '</button>' +
			'<button class="formatting bq" title="' + GUIp.i18n.quote_hint + '">bq.</button>' +
			'<button class="formatting bc" title="' + GUIp.i18n.code_hint + '">bc.</button>' +
			(GUIp.locale === 'ru' ? '<button class="formatting button godname" title="Вставить ссылку на бога"></button>' : '') +
			'<button class="formatting button link" title="' + GUIp.i18n.link_hint + '">a</button>' +
			'<button class="formatting button ul" title="' + GUIp.i18n.unordered_list_hint + '">•</button>' +
			'<button class="formatting button ol" title="' + GUIp.i18n.ordered_list_hint + '">1.</button>' +
			'<button class="formatting button br" title="' + GUIp.i18n.br_hint + '"></button>' +
			'<button class="formatting button sup" title="' + GUIp.i18n.sup_hint + '">X<sup>2</sup></button>' +
			'<button class="formatting button sub" title="' + GUIp.i18n.sub_hint + '">X<sub>2</sub></button>' +
			'<button class="formatting button monospace" title="' + GUIp.i18n.monospace_hint + '">' + GUIp.i18n.monospace + '</button>' +
		'</div>';
	$id('post_body_editor').insertAdjacentHTML('afterbegin', formatting_buttons);
	setClickActions('post_body_editor', $id('post_body'));
	setCtrlEnterAction($id('post_body'), document.querySelector('#reply input[type="submit"]'));

	var editFormObserver = new MutationObserver(function(mutations) {
		if ($id('edit_body_editor') && !$q('#edit_body_editor.improved')) {
			$id('edit_body_editor').classList.add('improved');
			$id('edit_body_editor').insertAdjacentHTML('afterbegin', formatting_buttons);
			setClickActions('edit_body_editor', $id('edit_body'));
			setCtrlEnterAction($id('edit_body'), document.querySelector('#edit input[type="submit"]'));
		}
	});
	editFormObserver.observe($id('content'), { childList: true, subtree: true });
	initSmartQuotation();
};
var fixGodnamePaste = function() {
	ReplyForm.add_name = function(name) {
		try {
			var editor;
			if (document.getElementById('edit').style.display !== 'none' && document.getElementById('edit_body')) {
				editor = document.getElementById('edit_body');
			} else {
				editor = document.getElementById('post_body');
				if (document.getElementById('reply').style.display === 'none') {
					ReplyForm.init();
				}
			}
			initEditor(editor);
			var pos = editor.selectionDirection === 'backward' ? ss : se;
			editor.value = val.slice(0, pos) + '*' + name + '*, ' + val.slice(pos);
			putSelectionTo(editor, pos + name.length + 4, false);
		} catch(error) {
			console.error(error);
		}
	};
};

// topic other improvements
var pw, pw_pb_int;
var checkHash = function() {
	// scroll to a certain post #
	var guip_hash = location.hash.match(/#guip_(\d+)/);
	if (guip_hash) {
		var post = $C('spacer')[+guip_hash[1]];
		location.hash = post ? post.id : '';
	}
};
var highlightCurrentPost = function() {
	var highlighted = $C('highlighted');
	if (highlighted.length) {
		highlighted[0].classList.remove('highlighted');
	}

	var post_hash = location.hash.match(/#(post_\d+)/),
	    post = post_hash ? $id(post_hash[1] + '-row') : null;
	if (post) {
		post.classList.add('highlighted');
	}
};
var setPageWrapperPaddingBottom = function(el) {
	var form = document.getElementById(el) || el,
		old_height = parseFloat(getComputedStyle(form).height) || 0,
		step = 0;
	clearInterval(pw_pb_int);
	pw_pb_int = setInterval(function() {
		if (step++ >= 100) {
			clearInterval(pw_pb_int);
		} else {
			var diff = (parseFloat(getComputedStyle(form).height) || 0) - old_height;
			old_height += diff;
			pw.style.paddingBottom = ((parseFloat(pw.style.paddingBottom) || 0) + diff) + 'px';
			window.scrollTo(0, window.scrollY + diff);
		}
	}, 10);
};
var fixPageWrapperPadding = function() {
	pw = document.getElementById('page_wrapper');
	Effect.old_toggle = Effect.toggle;
	Effect.toggle = function(a, b) { setPageWrapperPaddingBottom(a); Effect.old_toggle(a, b); };
	Effect.old_BlindDown = Effect.BlindDown;
	Effect.BlindDown = function(a, b) { setPageWrapperPaddingBottom(a); Effect.old_BlindDown(a, b); };
	EditForm.old_hide = EditForm.hide;
	EditForm.hide = function() { pw.style.paddingBottom = '0px'; EditForm.old_hide(); };
	EditForm.old_setReplyId = EditForm.setReplyId;
	EditForm.setReplyId = function(a) { if (document.getElementById('reply').style.display !== 'none') { pw.style.paddingBottom = '0px'; } EditForm.old_setReplyId(a); };
	ReplyForm.old_init = ReplyForm.init;
	ReplyForm.init = function() { ReplyForm.old_init(); if (getSelection().isCollapsed) { setTimeout(function() { document.getElementById('post_body').focus(); }, 50); } };
};

var findPost = function(el) {
	do {
		el = el.parentNode;
	} while (!el.classList.contains('post'));
	return el;
};
var picturesAutoreplace = function() {
	if (!storage.get('Option:disableLinksAutoreplace')) {
		var links = document.querySelectorAll('.post .body a'),
			imgs = [],
			onerror = function(i) {
				links[i].removeChild(links[i].getElementsByTagName('img')[0]);
				imgs[i] = null;
			},
			onload = function(i) {
				var oldBottom, hash = location.hash.match(/\d+/),
					post = findPost(links[i]),
					linkBeforeCurrentPost = hash ? +post.id.match(/\d+/)[0] < +hash[0] : false;
				if (linkBeforeCurrentPost) {
					oldBottom = post.getBoundingClientRect().bottom;
				}
				links[i].removeChild(links[i].getElementsByTagName('img')[0]);
				var hint = links[i].innerHTML;
				links[i].outerHTML = '<div class="img_container"><a id="link' + i + '" href="' + links[i].href + '" target="_blank" alt="' + GUIp.i18n.open_in_a_new_tab + '"></a><div class="hint">' + hint + '</div></div>';
				imgs[i].alt = hint;
				var new_link = document.getElementById('link' + i),
					width = Math.min(imgs[i].width, 456),
					height = imgs[i].height*(imgs[i].width <= 456 ? 1 : 456/imgs[i].width);
				if (height < 1500) {
					new_link.insertAdjacentHTML('beforeend', '<div style="width: ' + width + 'px; height: ' + height + 'px; background-image: url(' + imgs[i].src + '); background-size: ' + width + 'px;"></div>');
				} else {
					new_link.insertAdjacentHTML('beforeend', '<div style="width: ' + width + 'px; height: 750px; background-image: url(' + imgs[i].src + '); background-size: ' + width + 'px;"></div>' +
															 '<div style="width: ' + width + 'px; height: ' + (342*width/456) + 'px; background-image: url(' + GUIp.getResource('images/crop.png') + '); background-size: ' + width + 'px; position: absolute; top: ' + (750 - 171*width/456) + 'px;"></div>' +
															 '<div style="width: ' + width + 'px; height: 750px; background-image: url(' + imgs[i].src + '); background-size: ' + width + 'px; background-position: 100% 100%;"></div>');
				}
				if (linkBeforeCurrentPost) {
					var diff = post.getBoundingClientRect().bottom - oldBottom;
					window.scrollTo(0, window.scrollY + diff);
				}
			};
		for (i = 0, len = links.length; i < len; i++) {
			if (links[i].href.match(/jpe?g|png|gif/i)) {
				links[i].insertAdjacentHTML('beforeend', '<img class="img_spinner" src="http://godville.net/images/spinner.gif">');
				imgs[i] = document.createElement('img');
				imgs[i].onerror = onerror.bind(null, i);
				imgs[i].onload = onload.bind(null, i);
				imgs[i].src = links[i].href;
			}
		}
	}
};
var updatePostsNumber = function() {
	if (topics[topic]) {
		var page = location.search.match(/page=(\d+)/);
		page = page ? +page[1] - 1 : 0;
		var posts = page*25 + document.getElementsByClassName('post').length;
		if (topics[topic].posts < posts) {
			topics[topic].posts = posts;
			var dates = document.getElementsByTagName('abbr');
			topics[topic].date = dates[dates.length - 1].title;
			storage.set(forum_no, JSON.stringify(topics));
		}
	}
};
var improveTopic = function() {
	checkHash();
	highlightCurrentPost();
	window.onhashchange = highlightCurrentPost;
	fixPageWrapperPadding();
	picturesAutoreplace();
	updatePostsNumber();
};

// main code
var i, len, topic, isTopic, forum_no, topics;
var setInitVariables = function() {
	isTopic = location.pathname.match(/topic/) !== null;
	forum_no = 'Forum' + (isTopic ? $q('.crumbs a:nth-child(3)').href.match(/forums\/show\/(\d+)/)[1]
									  : location.pathname.match(/forums\/show\/(\d+)/)[1]);
	var greetings = $id('menu_top').textContent;
	storage.god_name = greetings.match(localStorage.getItem('GUIp:lastGodname'))[0] ||
	                   greetings.match(localStorage.getItem('GUIp:godnames'))[0];
	topics = JSON.parse(storage.get(forum_no));
};
var GUIp_forum = function() {
	try {
		if (!GUIp.i18n || !GUIp.browser || !GUIp.addCSSFromURL) { return; }
		clearInterval(starter);

		setInitVariables();

		if (!isTopic) {
			addSmallElements();
		}

		addLinks();

		if (isTopic) {
			GUIp.addCSSFromURL(GUIp.getResource('forum.css'), 'forum_css');
			addFormattingButtonsAndCtrlEnter();
			fixGodnamePaste();
			improveTopic();
		}
	} catch(e) {
		console.error(e);
	}
};
var starter = setInterval(GUIp_forum, 100);


})();