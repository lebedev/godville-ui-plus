(function() {
	'use strict';
	window.so.a_notify = function() {};
})();